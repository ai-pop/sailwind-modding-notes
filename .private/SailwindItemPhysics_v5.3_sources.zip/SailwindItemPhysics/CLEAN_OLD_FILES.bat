@echo off
cd /d "%~dp0"

echo Cleaning old leftovers in %CD%

REM --- 1.x → 2.x ---
del /f /q "Api\IItemPhysicsService.cs" 2>nul
del /f /q "Runtime\*.cs" 2>nul
rmdir /s /q "Runtime" 2>nul
del /f /q "Bridge\ItemRigidbodyHarmony.cs" 2>nul
del /f /q "ItemPhysicsPlugin.cs" 2>nul

REM --- 4.5.x throw files → superseded by Correct\MomentumThrow.cs (4.7.0) ---
del /f /q "Correct\ImitationThrower.cs" 2>nul
if exist "Correct\ImitationThrower.cs" (echo [FAIL] ImitationThrower.cs still there!) else (echo [ok] no ImitationThrower.cs)
if exist "Correct\MomentumThrow.cs" (echo [ok] MomentumThrow.cs present ^(4.7.0^)) else (echo [INFO] MomentumThrow.cs missing — unpack the fresh bundle)

del /f /q "bin\Release\SailwindItemPhysics.dll" 2>nul
del /f /q "bin\Debug\SailwindItemPhysics.dll" 2>nul
del /f /q "obj\*.*" 2>nul
rmdir /s /q "obj" 2>nul

echo.
echo Remaining .cs files:
dir /s /b *.cs
echo.
echo Done. Now run BUILD.bat from ModSource root.
pause
