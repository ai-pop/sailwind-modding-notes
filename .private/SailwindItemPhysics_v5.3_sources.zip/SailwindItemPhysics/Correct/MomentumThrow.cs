using SailwindItemPhysics.Bridge;
using UnityEngine;

namespace SailwindItemPhysics.Correct
{
    /// <summary>
    /// v4.7.0 — the momentum throw, REBUILT on decompilation facts
    /// (notes 57–60; removed blind in 4.5.x, architecturally vindicated by
    /// the research and now provably aligned with vanilla):
    ///
    /// WHAT THE RESEARCH SETTLED
    ///  1. Vanilla releases on **GetKeyUp(InputName 10)** (or interact key with
    ///     autoThrow) and runs OnDrop() + DropItem(): sound, held=null,
    ///     **visual layer = 0** → the item stays a clickable world item.
    ///     The 4.5.x "non-clickable" bug was our manual held-break skipping
    ///     the layer restore (note 58) — with vanilla doing the release the
    ///     bug class cannot exist. WE TOUCH NOTHING in the grip.
    ///  2. While held!=null the twin is a POSITION SLAVE: ItemRigidbody.
    ///     FixedUpdate teleports it onto the visual every fixed frame, and the
    ///     teleport zeroes velocity — that was "падает камнем" (note 59).
    ///     ⇒ Velocity may only be applied AFTER the first FixedUpdate that saw
    ///     held==null (twin becomes the master, goes dynamic, solid). That is
    ///     exactly the frame ThrowImpulse waits for.
    ///  3. Vanilla's own charged throw is AddForce(...) at the next
    ///     WaitForFixedUpdate — a single fixed-frame application whose Δv tops
    ///     out ≈0.13 m/s (note 57 — mass cancels in its formula). Re-asserting
    ///     our measured hand velocity over a handful of fixed frames is not a
    ///     "fight", it simply wins the final value, like a real arm would.
    ///
    /// FLOW: the player releases the item with the game's own key (usually F,
    /// resolved live — DropKeyResolver) → vanilla does its drop → a frame or
    /// two later CorrectManager's watch sees held→free → if the drop key was
    /// within the pairing window we launch the twin with the hand's own
    /// measured velocity (raw-pose tracker). Stand nearly still + tap =
    /// plain vanilla drop at your feet (no inertia to preserve — none added).
    /// Twinless items (no ItemRigidbody at all) fly our own ballistic arc
    /// for consistency with what the user saw from food items.
    /// </summary>
    internal static class MomentumThrow
    {
        private const float KeyWindow = 0.5f;      // drop-key ↔ release pairing (s)
        private const float GentleFloor = 0.9f;    // m/s — below = plain vanilla drop

        private static float _nextAllowed;
        private static float _anyKeyEventT = -10f; // last GetKeyDown/Up of a drop key
        private static bool _keyHeld;

        /// <summary>Every CorrectManager.Update: stamp drop-key activity
        /// (throw key + interact key when autoThrow lets it drop too).</summary>
        internal static void TickInput()
        {
            float now = Time.unscaledTime;
            var kThrow = DropKeyResolver.ThrowKey;
            if (Input.GetKeyDown(kThrow) || Input.GetKeyUp(kThrow))
                _anyKeyEventT = now;
            _keyHeld = Input.GetKey(kThrow);

            if (DropKeyResolver.AutoThrowDrop)
            {
                var kI = DropKeyResolver.InteractKey;
                if (kI != kThrow)
                {
                    if (Input.GetKeyDown(kI) || Input.GetKeyUp(kI))
                        _anyKeyEventT = now;
                    _keyHeld = _keyHeld || Input.GetKey(kI);
                }
            }
        }

        private static bool KeyActive(float now)
        {
            return _keyHeld || now - _anyKeyEventT < KeyWindow;
        }

        /// <summary>The watched held item just stopped being held (vanilla's
        /// own release already ran its full cleanup). Pair with the drop key;
        /// if paired, re-launch with the measured hand velocity.</summary>
        internal static void NotifyReleased(ShipItem item)
        {
            float now = Time.unscaledTime;
            if (item == null) return;                 // eaten/destroyed: Unity-null
            // v4.7.4: stamp the release point — the driver frees bogus mid-air
            // nails (placement artifact) only near recently-seen release points
            Bridge.RecentReleases.Note(item.transform.position);
            if (!Cfg.HoldEnabled) return;
            if (now < _nextAllowed) return;
            if (!KeyActive(now))
            {
                Plugin.Log?.LogInfo("[Hold] '" + item.name +
                                    "' released without the drop key (placed/stowed/anchor) — vanilla");
                return;
            }

            // the hand's own velocity at the release instant (tracker feeds on
            // the RAW vanilla held pose — note 59: only GoPointer writes it)
            Vector3 hand;
            if (!GoPointerPatches.TryGetHandVelocity(item, out hand))
            {
                Plugin.Log?.LogInfo("[Hold] release '" + item.name +
                                    "' — no velocity track, vanilla drop");
                return;
            }

            float handSpeed = hand.magnitude;
            if (handSpeed < GentleFloor)
            {
                Plugin.Log?.LogInfo("[Hold] release '" + item.name +
                                    "' — hand nearly still (" + handSpeed.ToString("0.0") +
                                    " m/s), plain vanilla drop (swing it to throw)");
                return;
            }

            _nextAllowed = now + 0.3f;

            Vector3 launch = hand * Cfg.HoldThrowBoost;
            float mag = launch.magnitude;
            if (mag > Cfg.HoldThrowMaxSpeed)
                launch *= Cfg.HoldThrowMaxSpeed / mag;

            var rb = ItemAccess.GetRigidbody(item);
            if (rb == null)
            {
                // no ItemRigidbody at all (note 61: vanilla always has a twin —
                // this is a modded/disabled-twin item): OUR ballistic arc
                TwinlessFlight.Plant(item, launch);
                Plugin.Log?.LogInfo("[Hold] THROW (momentum, twinless) '" + item.name +
                                    "' hand=" + handSpeed.ToString("0.0") +
                                    " → " + launch.magnitude.ToString("0.0") +
                                    " m/s (key=" + DropKeyResolver.ThrowKey + ")");
                return;
            }

            ThrowImpulse.Plant(rb, launch);
            try { rb.WakeUp(); } catch { /* ok */ }

            // boat airspace rule for the flight: fall INTO holds, no dome
            if (Cfg.HoldVanillaOnBoat)
                BoatZoneGhost.Attach(rb);

            Plugin.Log?.LogInfo("[Hold] THROW (momentum) '" + item.name +
                                "' hand=" + handSpeed.ToString("0.0") +
                                " → launch=" + launch.magnitude.ToString("0.0") +
                                " m/s (key=" + DropKeyResolver.ThrowKey + ")");
        }
    }

    /// <summary>
    /// v4.7.0 — lives on the twin for ≤0.8 s after a momentum throw.
    /// THE ONE RULE FROM NOTE 59: apply velocity only once the twin is the
    /// position MASTER — i.e. inside a FixedUpdate where held==null has
    /// already been processed (twin dynamic, non-kinematic). We detect that
    /// state ourselves (free && !isKinematic) and re-assert the SAME measured
    /// launch velocity (absolute assignment, never additive) until 12 fixed
    /// frames landed or the FIRST real contact ends the flight assist —
    /// outliving vanilla's single-frame ThrowItemAfterDelay AddForce by
    /// construction. Never forces kinematic state: vanilla owns it.
    /// </summary>
    internal sealed class ThrowImpulse : MonoBehaviour
    {
        private Rigidbody _rb;
        private ShipItem _item;
        private Vector3 _vel;
        private float _dieAt;
        private int _applied;

        public static void Plant(Rigidbody rb, Vector3 vel)
        {
            if (rb == null) return;
            var ti = rb.GetComponent<ThrowImpulse>();
            if (ti == null) ti = rb.gameObject.AddComponent<ThrowImpulse>();
            ti._rb = rb;
            ti._vel = vel;
            ti._dieAt = Time.unscaledTime + 0.8f;
            ti._applied = 0;
            try { ti._item = ItemAccess.GetItem(rb); } catch { ti._item = null; }
        }

        private void FixedUpdate()
        {
            if (_rb == null || Time.unscaledTime > _dieAt) { Destroy(this); return; }

            bool free;
            try { free = _item == null || _item.held == null; }
            catch { free = true; }

            // note 59 phase rule: only a master (never-held) twin keeps velocity —
            // a still-slaved one would be teleported onto the visual and lose it
            if (free && !_rb.isKinematic)
            {
                try
                {
                    _rb.useGravity = true;
                    _rb.velocity = _vel;      // re-assert, never add
                    _applied++;
                }
                catch { /* ok */ }
                if (_applied >= 12) Destroy(this);
            }
        }

        private void OnCollisionEnter(Collision c)
        {
            Destroy(this);   // first real contact — the world owns the body now
        }
    }

    /// <summary>
    /// OUR ballistic flight for items whose rigidbody cannot be resolved
    /// (modded/disabled-twin items): moves the item's own transform along a
    /// gravity arc, raycasts each step against the world (rests on the surface
    /// it meets), water touch = splash + rest AT the waterline.
    /// Self-destructs on arrival or after 6 s.
    /// </summary>
    internal sealed class TwinlessFlight : MonoBehaviour
    {
        private Vector3 _vel;
        private float _dieAt;

        public static void Plant(ShipItem item, Vector3 vel)
        {
            if (item == null) return;
            var f = item.GetComponent<TwinlessFlight>();
            if (f == null) f = item.gameObject.AddComponent<TwinlessFlight>();
            f._vel = vel;
            f._dieAt = Time.unscaledTime + 6f;
        }

        private void FixedUpdate()
        {
            if (Time.unscaledTime > _dieAt) { Destroy(this); return; }

            float dt = Time.fixedDeltaTime;
            _vel += Physics.gravity * dt;
            Vector3 step = _vel * dt;

            var t = transform;

            // world hit along the step → park on the surface, done
            RaycastHit hit;
            if (step.sqrMagnitude > 1e-8f &&
                Physics.Raycast(t.position, _vel.normalized, out hit, step.magnitude + 0.05f))
            {
                t.position = hit.point + hit.normal * 0.02f;
                Destroy(this);
                return;
            }

            Vector3 next = t.position + step;

            // water touch → splash + rest at the waterline
            float seaY;
            if (Ocean.OceanSurface.TryGetY(next, out seaY) && next.y < seaY + 0.02f)
            {
                t.position = new Vector3(next.x, seaY, next.z);
                SplashDirector.At(t.position, Mathf.Clamp(_vel.magnitude * 0.4f, 0.5f, 6f));
                Destroy(this);
                return;
            }

            t.position = next;
        }
    }
}
