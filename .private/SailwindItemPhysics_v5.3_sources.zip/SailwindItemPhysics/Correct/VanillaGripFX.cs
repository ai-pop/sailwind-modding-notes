using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace SailwindItemPhysics.Correct
{
    /// <summary>
    /// v4.4.1 — grip IMITATION on boats (user: the vanilla grip on deck looks
    /// "clunky/stiff" next to the physics hold off-boat). Splits LOOK from
    /// PHYSICS: zero physics objects are involved — the twin stays the vanilla
    /// kinematic trigger-ghost, so contact with the boat collider stack is
    /// impossible by construction (the whole 4.2–4.3.4 saga is untouched).
    ///
    /// How: the GoPointer.LateUpdate postfix (same slot the physics hold's
    /// MirrorVisual uses off-boat) hands us the item right after vanilla wrote
    /// the raw held pose. We read that pose as the exact per-frame target —
    /// pointer motion, holdDistance/Height, vanilla wheel rotation, camera
    /// bob, ship rocking: all included for free — then replace the visual with
    /// an inertia-smoothed version before render. Same lag-vs-mass family as
    /// HoldDriver's spring so the feel carries over when stepping dock↔deck.
    ///
    /// Lifetime: created lazily per held item; self-destructs when the item is
    /// dropped, the player steps off the boat, or the feature is toggled off.
    /// Owns nothing but the visual write — vanilla reclaims it next frame.
    /// </summary>
    internal sealed class VanillaGripFX : MonoBehaviour
    {
        private ShipItem _item;
        private Vector3 _pos;
        private Vector3 _vel;
        private Vector3 _velEma;
        private Quaternion _rot = Quaternion.identity;
        private bool _init;
        private float _mass = 8f;
        private float _lastApply = -10f;

        // v4.7.1 — vanilla big-item DECOLLISION handshake (notes 54/57/60):
        // held BIG items keep their PickupableItemCollisionChecker ACTIVE while
        // held, and GoPointer limits/pushes the PLAYER when it reports contact.
        // Our smoothed pose may take a shortcut through a mast/furniture that
        // the vanilla decol path would never take → the player gets shoved /
        // backward-walk clamps. So: while the checker reports ANY contact we
        /// converge the smoothed pose onto the raw vanilla (decollided) pose
        // fast — inertia stays where there is space, yields inside obstacles.
        private object _colChecker;
        private FieldInfo _collisionsF;
        private bool _colProbeDone;

        // -1 = unknown (no checker on this item — small items; don't tighten)
        private int CollisionsNow(ShipItem item)
        {
            if (!_colProbeDone)
            {
                _colProbeDone = true;
                try
                {
                    var f = AccessTools.Field(item.GetType(), "colChecker");
                    _colChecker = f != null ? f.GetValue(item) : null;
                    if (_colChecker != null)
                        _collisionsF = AccessTools.Field(_colChecker.GetType(), "collisions");
                }
                catch { _colChecker = null; _collisionsF = null; }
            }
            if (_colChecker == null || _collisionsF == null) return -1;
            try { return (int)(_collisionsF.GetValue(_colChecker) ?? 0); }
            catch { return -1; }
        }

        /// <summary>Every LateUpdate from the GoPointer postfix, only while the
        /// player is on a boat holding this item in vanilla grip mode.</summary>
        public static void ApplyTo(ShipItem item)
        {
            if (item == null) return;
            var fx = item.GetComponent<VanillaGripFX>();
            if (fx == null)
            {
                fx = item.gameObject.AddComponent<VanillaGripFX>();
                fx._item = item;
                try { if (item.mass > 0.3f) fx._mass = item.mass; } catch { /* ok */ }
                Plugin.Log?.LogInfo("[FX] grip imitation on '" + item.name +
                                    "' (visual inertia only — no physics on board)");
            }
            fx._lastApply = Time.unscaledTime;
            fx.Apply();
        }

        private void Apply()
        {
            if (_item == null) { Destroy(this); return; }
            var t = _item.transform;

            // raw = the exact pose vanilla wants this frame (wheel rotation and
            // all vanilla offsets are already baked into it)
            Vector3 rawPos = t.position;
            Quaternion rawRot = t.rotation;

            float dt = Time.deltaTime;
            if (dt <= 0f) return;            // paused — don't integrate

            if (!_init)
            {
                _init = true;
                _pos = rawPos;
                _rot = rawRot;
                _vel = Vector3.zero;
                _velEma = Vector3.zero;
                return;                      // first frame: leave vanilla pose as-is
            }

            // teleport snap-guard: fresh grab / seating / reactivation
            if ((rawPos - _pos).sqrMagnitude > 4f)
            {
                _pos = rawPos;
                _rot = rawRot;
                _vel = Vector3.zero;
                _velEma = Vector3.zero;
            }

            float mass = Mathf.Max(_mass, 0.5f);
            // same family as HoldDriver: lag ~ clamp(22/mass, .4, 1.6)
            float lag = Mathf.Clamp(22f / mass, 0.4f, 1.6f) * Cfg.HoldImitationStrength;

            // position: semi-implicit spring (stable for any frame rate)
            Vector3 acc = (rawPos - _pos) * (34f * lag) - _vel * (9f * Mathf.Sqrt(0.5f + lag));
            _vel += acc * dt;
            float sp = _vel.magnitude;
            if (sp > 9f) _vel *= 9f / sp;
            _pos += _vel * dt;

            // v4.5.3 readout kept for debugging only: EMA of the smoothed
            // pose velocity (no consumers since 4.6.0 — throw system removed)
            _velEma = Vector3.Lerp(_velEma, _vel, 1f - Mathf.Exp(-6f * dt));

            // never drift absurdly far from the vanilla anchor (0.75 m bubble) —
            // pure cosmetics, the visual must stay believable
            Vector3 off = _pos - rawPos;
            if (off.sqrMagnitude > 0.75f * 0.75f)
                _pos = rawPos + off.normalized * 0.75f;

            // v4.7.1: inside obstacles (vanilla decol reports contact on the
            // held item) converge fast onto the raw decollided pose — the
            // smoothed pose must never linger inside the boat/furniture,
            // or the game's own decollision shoves the player about
            if (Cfg.HoldImitationCollisionYield && CollisionsNow(_item) > 0)
            {
                float yieldK = 1f - Mathf.Exp(-30f * dt);
                _pos = Vector3.Lerp(_pos, rawPos, yieldK);
                _vel = Vector3.Lerp(_vel, Vector3.zero, yieldK);
            }

            // rotation: exponential approach — vanilla wheel-rotate still works,
            // it just gains a touch of inertia
            float rf = 1f - Mathf.Exp(-(10f * (0.6f + 0.4f * lag)) * dt);
            _rot = Quaternion.Slerp(_rot, rawRot, rf);

            t.position = _pos;
            t.rotation = _rot;
        }

        private void Update()
        {
            // self-cleanup: dropped / mode/flavour flip / postfix went stale.
            // v4.5.0: imitation applies everywhere by default; in the legacy
            // physics mode (HoldPhysicsInHands) it applies on boats only.
            bool alive = false;
            try
            {
                bool context = Cfg.HoldPhysicsInHands
                    ? (Cfg.HoldVanillaOnBoat && BoatGate.PlayerOnBoat)
                    : true;
                alive = _item != null && _item.held != null &&
                        Cfg.HoldEnabled && Cfg.HoldImitationOnBoat && context &&
                        Time.unscaledTime - _lastApply < 0.6f;
            }
            catch { /* ok */ }
            if (!alive) Destroy(this);
        }

        private void OnDestroy()
        {
            if (Cfg.Verbose && _item != null)
                Plugin.Log?.LogInfo("[FX] grip imitation off '" + _item.name + "'");
        }
    }
}
