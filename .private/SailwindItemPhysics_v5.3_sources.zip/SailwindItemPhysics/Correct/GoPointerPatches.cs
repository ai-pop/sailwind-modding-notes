using System;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace SailwindItemPhysics.Correct
{
    /// <summary>
    /// GoPointer hooks (note 47 — the class that owns pickup/hold in vanilla):
    ///
    ///  1. PickUpItem postfix → mark the freshly grabbed item so the vanilla
    ///     ItemRigidbody.FixedUpdate is skipped starting from the very NEXT fixed
    ///     frame — before our hold engages (CorrectManager tick is 0.1 s, during
    ///     which vanilla could otherwise run MoveRigidbodyToWalkCol with a stale
    ///     walkCol pair and park the twin ~462 m away; the observed 462 m class).
    ///
    ///  2. LateUpdate postfix → GoPointer moves the held VISUAL every LateUpdate
    ///     (world-space write). Right after it ran, we re-mirror the physical
    ///     twin pose onto the visual, so the LAST write of the frame before
    ///     render is always the physics pose. This replaces the 4.1.1
    ///     WaitForEndOfFrame mirror, which fired AFTER render and could never
    ///     affect a single displayed frame.
    ///
    /// GoPointer lives in Assembly-CSharp under the plain name "GoPointer".
    /// Unknown members are resolved with AccessTools and fail soft.
    /// </summary>
    internal static class GoPointerPatches
    {
        private static FieldInfo _heldItemF;

        public static void Apply(Harmony harmony)
        {
            int patched = 0;
            try
            {
                var gp = AccessTools.TypeByName("GoPointer");
                if (gp == null)
                {
                    Plugin.Log?.LogWarning("[Boot] GoPointer type not found — pickup marking + final mirror disabled");
                    return;
                }

                _heldItemF = AccessTools.Field(gp, "heldItem");
                if (_heldItemF == null)
                    Plugin.Log?.LogWarning("[Boot] GoPointer.heldItem field missing — final mirror will idle");

                var pick = AccessTools.Method(gp, "PickUpItem");
                if (pick != null)
                {
                    harmony.Patch(pick,
                        postfix: new HarmonyMethod(typeof(GoPointerPatches), nameof(OnPickup)));
                    patched++;
                }
                else Plugin.Log?.LogWarning("[Boot] GoPointer.PickUpItem not found — fresh-pickup marking off");

                var late = AccessTools.Method(gp, "LateUpdate");
                if (late != null)
                {
                    harmony.Patch(late,
                        postfix: new HarmonyMethod(typeof(GoPointerPatches), nameof(OnPointerLateUpdate)));
                    patched++;
                }
                else Plugin.Log?.LogWarning("[Boot] GoPointer.LateUpdate not found — final mirror off");

                Plugin.Log?.LogInfo("[Boot] GoPointer patches applied: " + patched + "/2");
            }
            catch (Exception ex)
            {
                Plugin.Log?.LogError("[Boot] GoPointer patch failed: " + ex);
            }
        }

        // PickUpItem(PickupableItem) — postfix: freshly grabbed item enters the
        // pre-activation safety window. PHYSICS-HOLD ONLY: in the v4.5.0 default
        // (imitation everywhere) nothing physics-related ever arms at pickup, so
        // the game's item flows (eating, using) are left 100% vanilla from frame 0.
        private static void OnPickup(Component __0)
        {
            try
            {
                if (!Cfg.HoldPhysicsInHands) return;
                var item = __0 as ShipItem;
                if (item == null) return;
                if (Cfg.HoldVanillaOnBoat && BoatGate.RawPlayerOnBoat) return;
                HoldRegistry.MarkFreshPickup(item);
            }
            catch { /* never break the vanilla pickup */ }
        }

        // --- last-seen held item (cheap cache for the release watch + overlay) ---
        private static ShipItem _lastHeld;
        private static float _lastHeldT = -10f;

        internal static ShipItem LastHeldItem
        {
            get { return UnityEngine.Time.unscaledTime - _lastHeldT < 0.5f ? _lastHeld : null; }
        }

        /// <summary>v4.7.0: is anything held RIGHT NOW (stamp updated by this
        /// postfix every frame while held — goes stale ~3 frames after the
        /// vanilla release). Drives MomentumThrow's held→free detection.</summary>
        internal static ShipItem HeldNow
        {
            get { return UnityEngine.Time.unscaledTime - _lastHeldT < 0.12f ? _lastHeld : null; }
        }

        // --- v4.7.0 raw hand-velocity tracker (momentum throw readout) ---
        // Feeds on the RAW vanilla held pose this postfix sees every frame —
        // vanilla already wrote it for THIS frame before running us (note 47/59:
        // GoPointer.LateUpdate is the ONLY writer of the held pose, world-space,
        // no parenting), and our own FX/mirror writes of the previous frame were
        // overwritten by it. The EMA measures the true motion of the player's
        // hand: arm swing, walking, camera bob, ship rock — independent of the
        // imitation toggle.
        private static ShipItem _trackItem;
        private static Vector3 _trackPrevPos;
        private static float _trackPrevT = -10f;
        private static Vector3 _trackVelEma;

        private static void TrackHand(ShipItem item, Vector3 rawPos)
        {
            float dt = Time.deltaTime;               // postfix: once per frame
            if (item != _trackItem || dt <= 0f || dt > 0.25f ||
                (rawPos - _trackPrevPos).sqrMagnitude > 16f)   // fresh grab / snap
            {
                _trackItem = item;
                _trackPrevPos = rawPos;
                _trackPrevT = UnityEngine.Time.unscaledTime;
                _trackVelEma = Vector3.zero;
                return;
            }
            Vector3 v = (rawPos - _trackPrevPos) / dt;
            _trackVelEma = Vector3.Lerp(_trackVelEma, v, 1f - Mathf.Exp(-8f * dt));
            _trackPrevPos = rawPos;
            _trackPrevT = UnityEngine.Time.unscaledTime;
        }

        /// <summary>EMA'd velocity of the RAW vanilla held pose (m/s, world).
        /// False without a fresh track for this item.</summary>
        internal static bool TryGetHandVelocity(ShipItem item, out Vector3 vel)
        {
            vel = Vector3.zero;
            if (item == null || item != _trackItem) return false;
            if (UnityEngine.Time.unscaledTime - _trackPrevT > 0.25f) return false;
            vel = _trackVelEma;
            return true;
        }

        // LateUpdate() — postfix: GoPointer just wrote the held visual. Two masters:
        //  - physics hold active (PhysicsInHands=true, off boats): physical pose;
        //  - imitation — inertia-smoothed pose. v4.5.0 default: EVERYWHERE (that
        //    is the eating fix — nothing physical ever exists in hands); with
        //    PhysicsInHands=true it applies on boats only (4.4.1 layout).
        private static void OnPointerLateUpdate(object __instance)
        {
            try
            {
                if (_heldItemF == null) return;
                var item = _heldItemF.GetValue(__instance) as ShipItem;
                if (item == null) return;

                _lastHeld = item;
                _lastHeldT = UnityEngine.Time.unscaledTime;

                // v4.7.0: measure the RAW vanilla hand pose BEFORE any of our
                // own visual writes (mirror/FX) — momentum throw readout
                TrackHand(item, item.transform.position);

                if (HoldRegistry.Contains(item))
                {
                    var hd = HoldDriver.Get(item);
                    if (hd != null && hd.IsActive) hd.MirrorVisual();
                    return;
                }

                if (!Cfg.HoldEnabled || !Cfg.HoldImitationOnBoat) return;
                if (Cfg.HoldPhysicsInHands)
                {
                    // legacy layout: real physics off boats → imitation on boats only
                    if (Cfg.HoldVanillaOnBoat && BoatGate.PlayerOnBoat)
                        VanillaGripFX.ApplyTo(item);
                }
                else
                {
                    VanillaGripFX.ApplyTo(item);   // v4.5.0: pretty grip everywhere
                }
            }
            catch { /* never break the pointer */ }
        }
    }
}
