using System;
using HarmonyLib;
using UnityEngine;

namespace SailwindItemPhysics.Correct
{
    /// <summary>
    /// Hull-damage firewall for the physics hold (note 55):
    /// BoatImpactSoundsCollider.OnCollisionEnter → BoatImpactSounds.Impact →
    /// BoatDamage.Impact. The last one refuses colliders tagged "ShipItem" —
    /// but item twins are plain Untagged GameObjects, so a physics-held item
    /// grinding against the hull would tick 0.15 hull damage every second and
    /// eventually sink the boat. Layer-based pairwise ignore (HoldDriver)
    /// already prevents contact with the player's own boat; this prefix is the
    /// belt-and-suspenders for anything that still slips through:
    /// while an item is physics-held, its twin may NEVER trigger a boat impact.
    /// </summary>
    internal static class BoatImpactPatches
    {
        public static void Apply(Harmony harmony)
        {
            try
            {
                var t = AccessTools.TypeByName("BoatImpactSoundsCollider");
                if (t == null)
                {
                    Plugin.Log?.LogWarning("[Boot] BoatImpactSoundsCollider not found — hull damage firewall off");
                    return;
                }
                var m = AccessTools.Method(t, "OnCollisionEnter");
                if (m == null)
                {
                    Plugin.Log?.LogWarning("[Boot] BoatImpactSoundsCollider.OnCollisionEnter missing — firewall off");
                    return;
                }
                harmony.Patch(m, prefix: new HarmonyMethod(typeof(BoatImpactPatches), nameof(SkipHeldImpacts)));
                Plugin.Log?.LogInfo("[Boot] BoatImpactSoundsCollider firewall applied");
            }
            catch (Exception ex)
            {
                Plugin.Log?.LogError("[Boot] BoatImpact patch failed: " + ex);
            }
        }

        // OnCollisionEnter(Collision) — return false ⇒ vanilla Impact() never runs
        private static bool SkipHeldImpacts(Collision collision)
        {
            if (HoldRegistry.Count == 0) return true;
            try
            {
                var c = collision != null ? collision.collider : null;
                if (c == null) return true;
                return !HoldRegistry.ContainsTwin(c);
            }
            catch
            {
                return true; // never break vanilla on error
            }
        }
    }
}
