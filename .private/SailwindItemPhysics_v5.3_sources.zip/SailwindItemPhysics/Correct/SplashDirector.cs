using System;
using System.Collections.Generic;
using System.IO;
using SailwindItemPhysics.Api;
using SailwindItemPhysics.Ocean;
using SailwindItemPhysics.Sim;
using UnityEngine;
using Random = UnityEngine.Random;

namespace SailwindItemPhysics.Correct
{
    /// <summary>
    /// Splash visuals for bodies hitting water with speed.
    ///
    /// Rendering strategy (honest): Unity cannot compile ShaderLab at runtime,
    /// so out of the box we use procedural meshes + BUILT-IN particle shaders.
    /// If <c>splash.bundle</c> (AssetBundle built in Unity Editor ≥2019.1)
    /// sits next to SailwindItemPhysics.dll, materials
    /// "SplashDrop"/"SplashRing"/"SplashColumn" are taken from it —
    /// that's the supported door for real custom shaders.
    /// </summary>
    internal sealed class SplashDirector : MonoBehaviour
    {
        private SurfaceBodyService _service;
        private bool _assetsReady;
        private bool _bundleTried;

        /// <summary>Live instance for ad-hoc splashes (custom throw water landings).</summary>
        internal static SplashDirector Live { get; private set; }

        private void Awake() { Live = this; }

        /// <summary>Fire-and-forget splash at a world position (config-gated).</summary>
        internal static void At(Vector3 pos, float impact)
        {
            if (!Cfg.SplashEnabled || Live == null) return;
            Live.Spawn(pos, impact);
        }

        private Texture2D _foamTex;
        private Mesh _quadMesh;
        private Mesh _ringMesh;
        private Mesh _columnMesh;
        private Material _dropMat;
        private Material _ringMat;
        private Material _columnMat;
        private bool _customMats;

        // droplet pool knobs
        private const int SegmentsRing = 24;
        private const int ColumnSides = 10;

        public void Bind(SurfaceBodyService service)
        {
            _service = service;
            if (_service != null)
                _service.BodySplashedEx += OnSplash;
        }

        private void OnDestroy()
        {
            if (_service != null) _service.BodySplashedEx -= OnSplash;
        }

        // ---------------- events ----------------

        private void OnSplash(ShipItem item, float impact, Vector3 pos)
        {
            if (!Cfg.SplashEnabled) return;
            Spawn(pos, impact);
        }

        /// <summary>Manual splash (mods, tests).</summary>
        public void Spawn(Vector3 pos, float impact)
        {
            if (!Cfg.SplashEnabled) return;
            EnsureAssets();

            float surface = OceanSurface.SpawnHintY(pos);
            Vector3 at = new Vector3(pos.x, surface, pos.z);
            float strength = Mathf.Clamp(impact * Cfg.SplashIntensity, 0.6f, 10f);

            try
            {
                SpawnDroplets(at, strength);
                SpawnRing(at, strength);
                if (strength >= 3.4f) SpawnColumn(at, strength);

                if (Cfg.Verbose)
                    Plugin.Log?.LogInfo("[Splash] impact=" + impact.ToString("0.0") +
                                        " str=" + strength.ToString("0.0") +
                                        (_customMats ? " (bundle mats)" : " (builtin mats)"));
            }
            catch (Exception ex)
            {
                Plugin.Log?.LogWarning("[Splash] spawn failed: " + ex.Message);
            }
        }

        /// <summary>Reserved hook (whoosh on grab) — currently a no-op marker.</summary>
        public void NotifyHoldStart(ShipItem item) { }

        // ---------------- spawners ----------------

        private void SpawnDroplets(Vector3 at, float strength)
        {
            int n = Mathf.Clamp(Mathf.RoundToInt(6 + strength * 2.2f), 6, 26);
            for (int i = 0; i < n; i++)
            {
                var go = NewFxObject("SplashDrop", _quadMesh, _dropMat);
                float ang = Mathf.PI * 2f * i / n + Random.Range(-0.25f, 0.25f);
                float r = Random.Range(0.5f, 1.1f) * (1f + strength * 0.08f);
                go.transform.position = at + new Vector3(Mathf.Cos(ang) * 0.15f, 0.1f, Mathf.Sin(ang) * 0.15f);
                float s = Random.Range(0.14f, 0.34f) * (1f + strength * 0.05f);
                go.transform.localScale = new Vector3(s, s * 1.35f, s);

                var d = go.AddComponent<SplashDroplet>();
                d.Vel = new Vector3(Mathf.Cos(ang) * r, strength * Random.Range(0.45f, 0.85f), Mathf.Sin(ang) * r);
                d.Life = Random.Range(0.7f, 1.25f);
                d.SurfaceY = at.y;
                d.Mat = FirstMaterial(go);
            }
        }

        private void SpawnRing(Vector3 at, float strength)
        {
            var go = NewFxObject("SplashRing", _ringMesh, _ringMat);
            go.transform.position = at + Vector3.up * 0.04f;

            var r = go.AddComponent<SplashRingFx>();
            r.MaxRadius = 1.1f + strength * 0.85f;
            r.Life = 1.25f;
            r.Mat = FirstMaterial(go);
        }

        private void SpawnColumn(Vector3 at, float strength)
        {
            var go = NewFxObject("SplashColumn", _columnMesh, _columnMat);
            go.transform.position = at;
            float baseScale = 0.8f + strength * 0.14f;
            go.transform.localScale = new Vector3(baseScale, 0.01f, baseScale);

            var c = go.AddComponent<SplashColumnFx>();
            c.Height = Mathf.Clamp(1.1f + strength * 0.45f, 1.2f, 5.2f);
            c.Life = 0.95f;
            c.BaseScale = baseScale;
            c.Mat = FirstMaterial(go);
        }

        // ---------------- assets ----------------

        private void EnsureAssets()
        {
            if (_assetsReady) return;
            _assetsReady = true;

            TryBundleMaterials();

            if (_foamTex == null) _foamTex = BuildFoamTexture(96);
            _quadMesh = BuildQuad();
            _ringMesh = BuildRing(SegmentsRing);
            _columnMesh = BuildColumn(ColumnSides);

            if (_dropMat == null) _dropMat = MakeMaterial(new Color(0.92f, 0.97f, 1f, 0.85f), _foamTex);
            if (_ringMat == null) _ringMat = MakeMaterial(new Color(0.85f, 0.95f, 1f, 0.75f), _foamTex);
            if (_columnMat == null) _columnMat = MakeMaterial(new Color(0.8f, 0.92f, 1f, 0.6f), null);
        }

        /// <summary>Optional custom materials from splash.bundle next to the dll.</summary>
        private void TryBundleMaterials()
        {
            if (_bundleTried) return;
            _bundleTried = true;
            try
            {
                string dir = Path.GetDirectoryName(typeof(Plugin).Assembly.Location);
                if (string.IsNullOrEmpty(dir)) return;
                string path = Path.Combine(dir, "splash.bundle");
                if (!File.Exists(path)) return;

                var bundle = AssetBundle.LoadFromFile(path);
                if (bundle == null) return;

                var drop = bundle.LoadAsset<Material>("SplashDrop");
                var ring = bundle.LoadAsset<Material>("SplashRing");
                var col = bundle.LoadAsset<Material>("SplashColumn");
                if (drop != null) _dropMat = drop;
                if (ring != null) _ringMat = ring;
                if (col != null) _columnMat = col;
                _customMats = drop != null || ring != null || col != null;

                Plugin.Log?.LogInfo("[Splash] splash.bundle loaded, custom mats=" + _customMats);
                // keep bundle alive — materials need their shaders; do NOT unload
            }
            catch (Exception ex)
            {
                Plugin.Log?.LogWarning("[Splash] bundle load failed: " + ex.Message);
            }
        }

        private static Material FirstMaterial(GameObject go)
        {
            try
            {
                var r = go.GetComponent<MeshRenderer>();
                // Unity auto-instantiates on .material access → per-effect fade
                if (r != null && r.sharedMaterial != null) return r.material;
            }
            catch { /* ok */ }
            return null;
        }

        private GameObject NewFxObject(string name, Mesh mesh, Material mat)
        {
            var go = new GameObject(name);
            var mf = go.AddComponent<MeshFilter>();
            mf.mesh = mesh;
            var mr = go.AddComponent<MeshRenderer>();
            if (mat != null) mr.sharedMaterial = mat;
            return go;
        }

        private static Material MakeMaterial(Color tint, Texture2D tex)
        {
            // built-in particle-capable shaders; first found wins
            string[] names =
            {
                "Legacy Shaders/Particles/Alpha Blended",
                "Particles/Alpha Blended",
                "Legacy Shaders/Particles/Additive",
                "Sprites/Default",
                "Unlit/Transparent"
            };
            Shader sh = null;
            foreach (var n in names)
            {
                sh = Shader.Find(n);
                if (sh != null) break;
            }
            if (sh == null) return null;

            var m = new Material(sh);
            try
            {
                m.color = tint;
                if (tex != null && m.HasProperty("_MainTex"))
                    m.SetTexture("_MainTex", tex);
                else if (tex != null && m.HasProperty("_BaseColorMap"))
                    m.SetTexture("_BaseColorMap", tex);
            }
            catch { /* ok */ }
            return m;
        }

        // ---------------- procedural geometry/texture ----------------

        private static Mesh BuildQuad()
        {
            var m = new Mesh();
            m.vertices = new[]
            {
                new Vector3(-0.5f, 0f, -0.5f), new Vector3(0.5f, 0f, -0.5f),
                new Vector3(0.5f, 0f, 0.5f), new Vector3(-0.5f, 0f, 0.5f)
            };
            m.uv = new[]
            {
                new Vector2(0f, 0f), new Vector2(1f, 0f),
                new Vector2(1f, 1f), new Vector2(0f, 1f)
            };
            m.triangles = new[] { 0, 2, 1, 0, 3, 2 };
            m.RecalculateNormals();
            m.RecalculateBounds();
            return m;
        }

        private static Mesh BuildRing(int seg)
        {
            var verts = new List<Vector3>();
            var uvs = new List<Vector2>();
            var tris = new List<int>();
            for (int i = 0; i <= seg; i++)
            {
                float a = Mathf.PI * 2f * i / seg;
                float cx = Mathf.Cos(a), sz = Mathf.Sin(a);
                verts.Add(new Vector3(cx * 0.55f, 0f, sz * 0.55f));
                verts.Add(new Vector3(cx * 1.0f, 0f, sz * 1.0f));
                uvs.Add(new Vector2((float)i / seg, 0f));
                uvs.Add(new Vector2((float)i / seg, 1f));
                if (i < seg)
                {
                    int b = i * 2;
                    tris.Add(b); tris.Add(b + 1); tris.Add(b + 2);
                    tris.Add(b + 2); tris.Add(b + 1); tris.Add(b + 3);
                }
            }
            var m = new Mesh();
            m.vertices = verts.ToArray();
            m.uv = uvs.ToArray();
            m.triangles = tris.ToArray();
            m.RecalculateNormals();
            m.RecalculateBounds();
            return m;
        }

        private static Mesh BuildColumn(int sides)
        {
            // open truncated cone around +Y (unit height, radii 0.16 bottom / 0.3 top)
            var verts = new List<Vector3>();
            var uvs = new List<Vector2>();
            var tris = new List<int>();
            for (int i = 0; i <= sides; i++)
            {
                float a = Mathf.PI * 2f * i / sides;
                float cx = Mathf.Cos(a), sz = Mathf.Sin(a);
                verts.Add(new Vector3(cx * 0.16f, 0f, sz * 0.16f));
                verts.Add(new Vector3(cx * 0.30f, 1f, sz * 0.30f));
                uvs.Add(new Vector2((float)i / sides, 0f));
                uvs.Add(new Vector2((float)i / sides, 1f));
                if (i < sides)
                {
                    int b = i * 2;
                    tris.Add(b); tris.Add(b + 1); tris.Add(b + 2);
                    tris.Add(b + 2); tris.Add(b + 1); tris.Add(b + 3);
                }
            }
            var m = new Mesh();
            m.vertices = verts.ToArray();
            m.uv = uvs.ToArray();
            m.triangles = tris.ToArray();
            m.RecalculateNormals();
            m.RecalculateBounds();
            return m;
        }

        /// <summary>Soft foam puff: radial falloff + speckle noise, RGBA32.</summary>
        private static Texture2D BuildFoamTexture(int size)
        {
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            float half = size * 0.5f;
            var rng = new System.Random(1337);
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dx = (x - half) / half, dy = (y - half) / half;
                    float r = Mathf.Sqrt(dx * dx + dy * dy);
                    float a = Mathf.Clamp01(1.15f - r * 1.35f);
                    a = a * a; // soft edge
                    // speckle — looks like foam instead of a plain disc
                    float n = (float)(rng.NextDouble() * 0.5 + 0.5);
                    a *= Mathf.Lerp(0.65f, 1f, n);
                    tex.SetPixel(x, y, new Color(1f, 1f, 1f, Mathf.Clamp01(a)));
                }
            }
            tex.Apply(false, false);
            return tex;
        }
    }

    // ==================================================================
    //  short-lived effect components (self-destroying, GC-cheap by rarity)
    // ==================================================================

    internal sealed class SplashDroplet : MonoBehaviour
    {
        public Vector3 Vel;
        public float Life = 1f;
        public float SurfaceY;
        public Material Mat;
        private float _t;

        private void Update()
        {
            float dt = Time.deltaTime;
            _t += dt;
            Vel += Vector3.down * (9.81f * 0.85f) * dt;
            Vel.x *= 1f - Mathf.Clamp01(1.6f * dt);
            Vel.z *= 1f - Mathf.Clamp01(1.6f * dt);
            transform.position += Vel * dt;
            transform.Rotate(0f, 90f * dt, 0f);

            Fade(1f - _t / Life);
            if (_t > Life || transform.position.y < SurfaceY - 0.25f)
                Destroy(gameObject);
        }

        private void Fade(float a)
        {
            if (Mat == null) return;
            try
            {
                var c = Mat.color;
                c.a = Mathf.Clamp01(a) * 0.85f;
                Mat.color = c;
            }
            catch { /* ok */ }
        }
    }

    internal sealed class SplashRingFx : MonoBehaviour
    {
        public float MaxRadius = 2f;
        public float Life = 1.2f;
        public Material Mat;
        private float _t;

        private void Update()
        {
            float dt = Time.deltaTime;
            _t += dt;
            float k = Mathf.Clamp01(_t / Life);
            float radius = Mathf.Lerp(0.5f, MaxRadius, 1f - (1f - k) * (1f - k)); // ease-out
            transform.localScale = new Vector3(radius, 1f, radius);

            // ride the waves
            float y;
            Vector3 p = transform.position;
            if (SailwindItemPhysics.Ocean.OceanSurface.TryGetY(p, out y))
                transform.position = new Vector3(p.x, y + 0.04f, p.z);

            Fade(1f - k);
            if (k >= 1f) Destroy(gameObject);
        }

        private void Fade(float a)
        {
            if (Mat == null) return;
            try
            {
                var c = Mat.color;
                c.a = Mathf.Clamp01(a) * 0.75f;
                Mat.color = c;
            }
            catch { /* ok */ }
        }
    }

    internal sealed class SplashColumnFx : MonoBehaviour
    {
        public float Height = 2f;
        public float Life = 0.9f;
        public float BaseScale = 1f;
        public Material Mat;
        private float _t;

        private void Update()
        {
            float dt = Time.deltaTime;
            _t += dt;
            float k = Mathf.Clamp01(_t / Life);
            // fast rise, ease-out fall
            float h = k < 0.35f
                ? Mathf.Lerp(0.01f, Height, k / 0.35f)
                : Mathf.Lerp(Height, Height * 0.35f, (k - 0.35f) / 0.65f);
            float w = BaseScale * Mathf.Lerp(1f, 0.55f, k);
            transform.localScale = new Vector3(w, h, w);

            Fade(1f - k);
            if (k >= 1f) Destroy(gameObject);
        }

        private void Fade(float a)
        {
            if (Mat == null) return;
            try
            {
                var c = Mat.color;
                c.a = Mathf.Clamp01(a) * 0.6f;
                Mat.color = c;
            }
            catch { /* ok */ }
        }
    }
}
