using SailwindItemPhysics.Bridge;
using UnityEngine;

namespace SailwindItemPhysics.Correct
{
    /// <summary>
    /// v4.4.0 — the boat half of the split-world rule for FREE bodies.
    /// Attached to the twin right after a G-throw (thrown bodies stay solid —
    /// that's the off-boat rule). While the body crosses a boat's airspace
    /// (BoatZone) it switches to the vanilla drop flow instead:
    /// colliders go isTrigger so the body falls THROUGH the buoyancy capsule
    /// high above the deck and vanilla's EnterBoat seats it in the hold
    /// (notes 51/56 — exactly how vanilla drops items into holds).
    ///
    /// Lifetime guards, each restoring solidity and self-destructing:
    ///  - vanilla seated the body (IsOnBoat) — boat owns it now;
    ///  - the body left the zone for good (3 clear checks ≈ 0.36 s);
    ///  - a 15 s timeout (bodies thrown into open sea do nothing and die).
    /// OnDestroy double-checks the restore so a destroyed body is never left
    /// ghosted by accident.
    /// </summary>
    internal sealed class BoatZoneGhost : MonoBehaviour
    {
        private Rigidbody _rb;
        private Collider[] _cols;
        private bool[] _wasTrigger;
        private bool _ghosted;
        private float _dieAt = -1f;
        private float _nextCheck;
        private int _outsideChecks;

        public static void Attach(Rigidbody rb)
        {
            if (rb == null) return;
            var g = rb.GetComponent<BoatZoneGhost>();
            if (g == null) g = rb.gameObject.AddComponent<BoatZoneGhost>();
            g.Arm(rb);
        }

        private void Arm(Rigidbody rb)
        {
            _rb = rb;
            _dieAt = Time.unscaledTime + 15f;
            _outsideChecks = 0;
        }

        private void Update()
        {
            if (Time.unscaledTime < _nextCheck) return;
            _nextCheck = Time.unscaledTime + 0.12f;

            if (_rb == null) { Restore(); Destroy(this); return; }

            // vanilla's EnterBoat ran — the item is seated in the hold/on deck,
            // the boat rule owns it now; hand colliders back solid and leave
            if (ItemAccess.IsOnBoat(_rb)) { Restore(); Destroy(this); return; }

            // timeout — thrown over open sea, never met a boat
            if (Time.unscaledTime > _dieAt) { Restore(); Destroy(this); return; }

            if (BoatZone.Contains(_rb.position))
            {
                _outsideChecks = 0;
                if (!_ghosted) SetGhost(true);
            }
            else if (_ghosted)
            {
                // zone edges are fuzzy (moving boats, 3 s rescan) — require
                // 3 consecutive clear checks before re-arming solidity
                if (++_outsideChecks >= 3) { Restore(); Destroy(this); return; }
            }
        }

        private void SetGhost(bool on)
        {
            if (!on) return;
            try
            {
                _cols = _rb.GetComponentsInChildren<Collider>(true);
                if (_cols == null || _cols.Length == 0) { _cols = null; return; }
                _wasTrigger = new bool[_cols.Length];
                for (int i = 0; i < _cols.Length; i++)
                {
                    var c = _cols[i];
                    if (c == null) continue;
                    _wasTrigger[i] = c.isTrigger;
                    c.isTrigger = true;   // through the invisible dome
                }
                _ghosted = true;
                Plugin.Log?.LogInfo("[Ghost] '" + name +
                                    "' — inside boat airspace, vanilla drop flow (through the capsule)");
            }
            catch { _cols = null; _wasTrigger = null; }
        }

        private void Restore()
        {
            try
            {
                if (_ghosted && _cols != null)
                {
                    for (int i = 0; i < _cols.Length; i++)
                    {
                        var c = _cols[i];
                        if (c == null || _wasTrigger == null || i >= _wasTrigger.Length) continue;
                        c.isTrigger = _wasTrigger[i];
                    }
                    if (Cfg.Verbose)
                        Plugin.Log?.LogInfo("[Ghost] '" + name + "' — out of boat airspace, solid again");
                }
            }
            catch { /* ok */ }
            _ghosted = false;
            _cols = null;
            _wasTrigger = null;
        }

        private void OnDestroy()
        {
            Restore();   // never leave a ghost behind, whatever killed us
        }
    }
}
