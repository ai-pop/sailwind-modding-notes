using UnityEngine;

namespace SailwindItemPhysics.Correct
{
    /// <summary>
    /// Reactive boat-ghosting + forensics for the hold. Lives on the held twin
    /// for the duration of the hold.
    ///
    /// Why reactive: the collected ignore set (BoatColliderCache) demonstrably
    /// missed a boat-root collider — the log showed a post-ignore contact vs a
    /// GO literally tagged 'Boat' (spy v4.3.3). So instead of relying on
    /// collection timing/hierarchies, EVERY contact during the hold is checked:
    /// anything boat-ish (tag 'Boat', layer 12 = walk decks, layer 13 = boat
    /// layer per note 52) gets pairwise-ignored ON THE SPOT and is restored
    /// when the component dies (drop / throw — the launched body then hits
    /// boats normally).
    ///
    /// It also logs contact summaries so the next log, if anything still
    /// blocks the item, names the offender verbatim (GO/layer/tag/parent).
    /// Rate-limited ~4 lines/sec, repeat offenders muted for 3 s.
    /// </summary>
    internal sealed class HoldCollisionSpy : MonoBehaviour
    {
        public string ItemName = "?";
        public Collider[] OwnCols;   // twin colliders (from HoldDriver)

        private readonly System.Collections.Generic.Dictionary<int, float> _seen =
            new System.Collections.Generic.Dictionary<int, float>(16);
        private readonly System.Collections.Generic.List<Collider> _ghosted =
            new System.Collections.Generic.List<Collider>(16);
        private float _budget;

        private void OnCollisionEnter(Collision collision) { Handle(collision, "hit"); }
        private void OnCollisionStay(Collision collision) { Handle(collision, "grind"); }

        private void Handle(Collision collision, string kind)
        {
            try
            {
                var c = collision != null ? collision.collider : null;
                if (c == null || OwnCols == null) return;

                bool boatish = IsBoatish(c);
                if (boatish) Ghost(c);

                if (Time.unscaledTime < _budget) return;
                int id = c.GetInstanceID();
                float last;
                if (_seen.TryGetValue(id, out last) && Time.unscaledTime - last < 3f) return;
                _seen[id] = Time.unscaledTime;
                _budget = Time.unscaledTime + 0.25f;

                string go = c.gameObject != null ? c.gameObject.name : "?";
                string tag = "?";
                try { tag = c.tag; } catch { /* ok */ }
                int layer = c.gameObject != null ? c.gameObject.layer : -1;
                string parent = "?";
                try
                {
                    var p = c.transform.parent;
                    string root = p != null ? (p.parent != null ? p.parent.name : "-") : "-";
                    parent = (p != null ? p.name : "-") + " ← " + root;
                }
                catch { /* ok */ }

                Plugin.Log?.LogWarning("[Hold] contact '" + ItemName + "' " + kind + " '" + go +
                                       "' layer=" + layer + " tag='" + tag +
                                       "' parent=" + parent +
                                       (boatish ? " → ghosted" : " (kept solid)"));
            }
            catch { /* must never crash the hold */ }
        }

        private static bool IsBoatish(Collider c)
        {
            try
            {
                if (c.gameObject != null)
                {
                    if (c.gameObject.layer == 12 || c.gameObject.layer == 13) return true;
                }
                if (c.CompareTag("Boat")) return true;
                // boats are easy to spot by name — root GOs are named "BOAT ..." (log proof)
                var t = c.transform;
                for (int i = 0; i < 6 && t != null; i++, t = t.parent)
                {
                    string n = t.name;
                    if (!string.IsNullOrEmpty(n) && n.StartsWith("BOAT", System.StringComparison.Ordinal))
                        return true;
                }
            }
            catch { /* ok */ }
            return false;
        }

        private void Ghost(Collider b)
        {
            for (int i = 0; i < _ghosted.Count; i++)
                if (ReferenceEquals(_ghosted[i], b)) return;

            for (int k = 0; k < OwnCols.Length; k++)
            {
                var a = OwnCols[k];
                if (a == null || a == b) continue;
                try { Physics.IgnoreCollision(a, b, true); } catch { /* ok */ }
            }
            _ghosted.Add(b);
        }

        private void OnDestroy()
        {
            // held item released (or thrown): the boat world is solid again
            for (int i = 0; i < _ghosted.Count; i++)
            {
                var b = _ghosted[i];
                if (b == null || OwnCols == null) continue;
                for (int k = 0; k < OwnCols.Length; k++)
                {
                    var a = OwnCols[k];
                    if (a == null) continue;
                    try { Physics.IgnoreCollision(a, b, false); } catch { /* ok */ }
                }
            }
            _ghosted.Clear();
        }
    }
}
