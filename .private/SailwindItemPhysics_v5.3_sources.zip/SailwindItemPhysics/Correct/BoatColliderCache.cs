using UnityEngine;

namespace SailwindItemPhysics.Correct
{
    /// <summary>
    /// Colliders of the player boat (the one you stand on). Note 51: the boat
    /// ROOT carries a big buoyancy CapsuleCollider whose surface sits high above
    /// the deck. The player ignores it (walks on the layer-12 walk collider),
    /// but a physics item twin (layer 2) collides with it. Vanilla never sees
    /// this because held twins are isTrigger. Our physics hold makes the twin
    /// solid, so while held we pairwise-ignore the boat's colliders — the held
    /// body can still hit the world, other boats, other items, just not the
    /// deck under your feet.
    ///
    /// v4.3.1: the walk-deck mesh is a PARENTLESS GO (HullPlayerCollider dup,
    /// note 51) — NOT a child of the boat transform, so boat.GetComponentsInChildren
    /// missed it, and solid held items kept clanging on the hatch/deck rim instead
    /// of following into the hold. We now also collect every walkCollider transform
    /// referenced by BoatEmbarkCollider components (and may hand the item's own
    /// boat in via Extra).
    /// </summary>
    internal static class BoatColliderCache
    {
        private static Collider[] _cols;
        private static float _nextRefresh;
        private static Transform _boat;

        public static void Invalidate()
        {
            _nextRefresh = 0f;
        }

        /// <summary>Ignore/unignore every collider pair (twin col × boat col).</summary>
        public static void SetIgnore(Collider[] twinCols, bool ignore, Transform extraBoat)
        {
            EnsureFresh(extraBoat);
            if (twinCols == null || _cols == null) return;
            for (int i = 0; i < twinCols.Length; i++)
            {
                var a = twinCols[i];
                if (a == null) continue;
                for (int j = 0; j < _cols.Length; j++)
                {
                    var b = _cols[j];
                    if (b == null || b == a) continue;
                    try { Physics.IgnoreCollision(a, b, ignore); } catch { /* ok */ }
                }
            }
        }

        private static void EnsureFresh(Transform extraBoat)
        {
            Transform boat = null;
            try { boat = GameState.currentBoat; } catch { /* ok */ }
            if (boat == null) boat = extraBoat;
            if (extraBoat != null && extraBoat != boat) boat = extraBoat;

            if (Time.unscaledTime < _nextRefresh && boat == _boat && _cols != null) return;
            _nextRefresh = Time.unscaledTime + 5f;
            _boat = boat;
            Rebuild(boat);
        }

        private static void Rebuild(Transform boat)
        {
            var list = new System.Collections.Generic.List<Collider>(96);
            int fromRoot = 0, fromWalk = 0, fromLayer12 = 0, fromTag = 0;

            if (boat != null)
            {
                try
                {
                    var own = boat.GetComponentsInChildren<Collider>(true);
                    if (own != null) { list.AddRange(own); fromRoot = own.Length; }
                }
                catch { /* ok */ }

                // parentless walk-collider dups (note 51): reachable ONLY through
                // BoatEmbarkCollider.walkCollider — collect those transforms
                try
                {
                    var becType = FindType("BoatEmbarkCollider");
                    if (becType != null)
                    {
                        var comps = boat.GetComponentsInChildren(becType, true);
                        if (comps != null)
                        {
                            var walkF = becType.GetField("walkCollider",
                                System.Reflection.BindingFlags.Instance |
                                System.Reflection.BindingFlags.Public |
                                System.Reflection.BindingFlags.NonPublic);
                            foreach (var comp in comps)
                            {
                                if (comp == null || walkF == null) continue;
                                var wt = walkF.GetValue(comp) as Transform;
                                if (wt == null) continue;
                                var wc = wt.GetComponentsInChildren<Collider>(true);
                                if (wc != null) { list.AddRange(wc); fromWalk += wc.Length; }
                            }
                        }
                    }
                }
                catch { /* ok */ }

                // v4.3.3: note 51 admits uncertainty — the walk surface seen by the
                // player is the LAYER-12 "hull player collider" GO (parentless dup).
                // The walkCollider field chase above may point elsewhere entirely,
                // so just take every layer-12 collider in the scene: those are
                // walk decks by definition, and the ignore lasts only for the hold.
                try
                {
                    var all = Object.FindObjectsOfType<Collider>();
                    if (all != null)
                    {
                        for (int i = 0; i < all.Length; i++)
                        {
                            var c = all[i];
                            if (c != null && c.gameObject.layer == 12)
                            {
                                list.Add(c);
                                fromLayer12++;
                            }
                        }
                    }
                }
                catch { /* ok */ }

                // and every collider under anything tagged "Boat" (belt & braces —
                // catches boat colliders that are not under GameState.currentBoat)
                try
                {
                    var boats = GameObject.FindGameObjectsWithTag("Boat");
                    if (boats != null)
                    {
                        for (int i = 0; i < boats.Length; i++)
                        {
                            var g = boats[i];
                            if (g == null) continue;
                            var cs = g.GetComponentsInChildren<Collider>(true);
                            if (cs != null) { list.AddRange(cs); fromTag += cs.Length; }
                        }
                    }
                }
                catch { /* undefined tag on some builds — fine */ }
            }

            _cols = list.Count == 0 ? null : Distinct(list);
            string sig = (_cols != null ? _cols.Length : 0) + "/" + fromRoot + "/" + fromWalk +
                         "/" + fromLayer12 + "/" + fromTag;
            if (sig != _lastSig)
            {
                _lastSig = sig;
                Plugin.Log?.LogInfo("[Hold] boat ignore set: " +
                                    (_cols != null ? _cols.Length : 0) +
                                    " colliders (root=" + fromRoot + " walk=" + fromWalk +
                                    " layer12=" + fromLayer12 + " tag=" + fromTag + ")");
            }
        }

        private static string _lastSig;

        private static Collider[] Distinct(System.Collections.Generic.List<Collider> list)
        {
            var seen = new System.Collections.Generic.HashSet<int>();
            var outp = new System.Collections.Generic.List<Collider>(list.Count);
            foreach (var c in list)
            {
                if (c == null) continue;
                if (seen.Add(c.GetInstanceID())) outp.Add(c);
            }
            return outp.ToArray();
        }

        private static System.Type FindType(string name)
        {
            foreach (var a in System.AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    foreach (var t in a.GetTypes())
                        if (t.Name == name) return t;
                }
                catch { /* skip */ }
            }
            return null;
        }
    }
}
