using System;
using HarmonyLib;
using UnityEngine;

namespace SailwindItemPhysics.Correct
{
    /// <summary>
    /// Bootstrap hooks for the correctness layer:
    ///  1. ShipItem.Awake postfix → register every item in CorrectRegistry
    ///     (so "every item in the game has Triggered+Grabbed by default" is literal).
    ///  2. ItemRigidbody.FixedUpdate prefix → while an item is physics-held,
    ///     skip vanilla twin sync (physics becomes the master; visual follows twin).
    /// </summary>
    internal static class ItemBootPatches
    {
        public static void Apply(Harmony harmony)
        {
            int patched = 0;
            try
            {
                // 1) ShipItem.Awake — direct reference (ShipItem is in Assembly-CSharp)
                var awake = AccessTools.Method(typeof(ShipItem), "Awake");
                if (awake != null)
                {
                    harmony.Patch(awake,
                        postfix: new HarmonyMethod(typeof(ItemBootPatches), nameof(OnItemAwake)));
                    patched++;
                }
                else
                {
                    Plugin.Log?.LogWarning("[Boot] ShipItem.Awake not found — items will only register via sweep");
                }

                // 2) ItemRigidbody.FixedUpdate — suppress vanilla sync while physics-held
                var ir = AccessTools.TypeByName("ItemRigidbody");
                if (ir != null)
                {
                    var fixedUp = AccessTools.Method(ir, "FixedUpdate");
                    if (fixedUp != null)
                    {
                        harmony.Patch(fixedUp,
                            prefix: new HarmonyMethod(typeof(ItemBootPatches), nameof(SkipVanillaWhileHeld)));
                        patched++;
                    }
                }

                // 3) ShipItem.ExtraFixedUpdate — the boat state machine (note 53:
                // EnterBoat reparents + reseats the twin through the walkCol
                // roundtrip, which fired in the middle of our hold: the 2.3 m
                // "external teleports" and one stray 462 m. Suspend it while held
                // or fresh-picked; it resumes on its own after release.
                var extra = AccessTools.Method(typeof(ShipItem), "ExtraFixedUpdate");
                if (extra != null)
                {
                    harmony.Patch(extra,
                        prefix: new HarmonyMethod(typeof(ItemBootPatches), nameof(SkipBoatStateWhileHeld)));
                    patched++;
                }
                else Plugin.Log?.LogWarning("[Boot] ShipItem.ExtraFixedUpdate not found — boat state churn possible");

                Plugin.Log?.LogInfo("[Boot] correctness patches applied: " + patched + "/3");
            }
            catch (Exception ex)
            {
                Plugin.Log?.LogError("[Boot] patch failed: " + ex);
            }
        }

        private static void OnItemAwake(object __instance)
        {
            try
            {
                var item = __instance as ShipItem;
                if (item != null) CorrectManager.NotifyItemSpawned(item);
            }
            catch { /* registration must never break item boot */ }
        }

        /// <summary>Prefix: return false → vanilla ItemRigidbody.FixedUpdate skipped this frame.
        /// Hot path: two integer checks when nothing is held (the common case).
        /// v4.2.0: also skips twins of FRESHLY picked items (GoPointer.PickUpItem
        /// postfix window) — vanilla must not run MoveRigidbodyToWalkCol on them
        /// before the hold engages (the ~462 m teleport class).</summary>
        private static bool SkipVanillaWhileHeld(object __instance)
        {
            if (HoldRegistry.Count == 0) return true;
            try
            {
                var c = __instance as Component;
                if (c == null) return true;
                return !HoldRegistry.SkipFor(c);
            }
            catch
            {
                return true; // never break vanilla on error
            }
        }

        /// <summary>Prefix: return false → ShipItem.ExtraFixedUpdate skipped this
        /// frame while the item is physics-held (or just picked up) — no EnterBoat
        /// reparent/reseat churn underneath the spring.</summary>
        private static bool SkipBoatStateWhileHeld(object __instance)
        {
            if (HoldRegistry.Count == 0) return true;
            try
            {
                var item = __instance as ShipItem;
                if (item == null) return true;
                return !HoldRegistry.SkipForItem(item);
            }
            catch
            {
                return true; // never break vanilla on error
            }
        }
    }
}
