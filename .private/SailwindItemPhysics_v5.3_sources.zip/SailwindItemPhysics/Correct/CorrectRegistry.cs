using System;
using System.Collections.Generic;
using System.Text;
using SailwindItemPhysics.Api;
using UnityEngine;

namespace SailwindItemPhysics.Correct
{
    /// <summary>Runtime record of one item in the correctness layer.</summary>
    internal sealed class CorrectState
    {
        public ShipItem Item;              // may become fake-null — purge defensively
        public int RuntimeId;              // item.GetInstanceID()
        public bool HasSaveId;
        public int SaveId;                 // SaveablePrefab.instanceId
        public ItemPhysicsAssignment Assignment;
        public bool Corrected;             // became physically correct (sticky)
        public bool TriggerActiveNow;      // live trigger evaluation
        public bool HoldActive;
        public int ReleasedTicks;          // consecutive ticks with held==null (hysteresis)
        public bool FloatAttachedByUs;

        public bool CorrectActive
        {
            get { return Corrected || (Assignment.Sticky ? Corrected : TriggerActiveNow); }
        }
    }

    /// <summary>
    /// Central registry of item correctness: assignments (priority-resolved),
    /// sticky "corrected" flags, save/load persistence via GameState.modData.
    ///
    /// Missing record == built-in default (Triggered+Grabbed, prio 0) — so every
    /// item in the game has "physically correct when picked up" out of the box,
    /// and only diverging entries are persisted.
    /// </summary>
    internal static class CorrectRegistry
    {
        private const string ModDataKey = "itemphysics.correctness";
        private const int FormatVersion = 1;

        private static readonly Dictionary<int, CorrectState> ByRuntime =
            new Dictionary<int, CorrectState>(128);

        // persisted non-default assignments + corrected flags, by SaveablePrefab.instanceId
        private static readonly Dictionary<int, ItemPhysicsAssignment> SaveAssignments =
            new Dictionary<int, ItemPhysicsAssignment>(64);
        private static readonly HashSet<int> SaveCorrected = new HashSet<int>();

        private static bool _dirty;
        private static bool _savesLoaded;

        // ---------------- registration ----------------

        public static CorrectState Register(ShipItem item)
        {
            if (item == null) return null;
            int rid = item.GetInstanceID();

            CorrectState st;
            if (ByRuntime.TryGetValue(rid, out st) && st != null && st.Item != null)
                return st;

            // same runtime id can be recycled; build fresh
            st = new CorrectState { Item = item, RuntimeId = rid };

            try
            {
                var sp = item.GetComponent<SaveablePrefab>();
                if (sp != null)
                {
                    st.HasSaveId = true;
                    st.SaveId = sp.instanceId;
                }
            }
            catch { /* ok */ }

            st.Assignment = ResolveAssignment(st.SaveId, st.HasSaveId);
            st.Corrected = st.HasSaveId && SaveCorrected.Contains(st.SaveId);

            if (st.Assignment.Module == PhysicsModuleKind.Always && !st.Corrected)
            {
                st.Corrected = true;
                MarkDirty();
            }

            ByRuntime[rid] = st;
            return st;
        }

        public static CorrectState Get(ShipItem item)
        {
            if (item == null) return null;
            CorrectState st;
            return ByRuntime.TryGetValue(item.GetInstanceID(), out st) && st != null &&
                   st.Item != null
                ? st
                : null;
        }

        /// <summary>Drop references to destroyed items (fake-null safe).</summary>
        public static int PurgeDead()
        {
            var dead = new List<int>(8);
            foreach (var kv in ByRuntime)
                if (kv.Value == null || kv.Value.Item == null)
                    dead.Add(kv.Key);
            for (int i = 0; i < dead.Count; i++) ByRuntime.Remove(dead[i]);
            return dead.Count;
        }

        public static List<CorrectState> Snapshot()
        {
            var list = new List<CorrectState>(ByRuntime.Count);
            foreach (var kv in ByRuntime)
                if (kv.Value != null && kv.Value.Item != null)
                    list.Add(kv.Value);
            return list;
        }

        public static int TrackedCount
        {
            get { return ByRuntime.Count; }
        }

        // ---------------- assignment / priority ----------------

        private static ItemPhysicsAssignment ResolveAssignment(int saveId, bool hasSave)
        {
            if (hasSave)
            {
                ItemPhysicsAssignment a;
                if (SaveAssignments.TryGetValue(saveId, out a))
                    return a;
            }
            return BuiltinDefault();
        }

        /// <summary>The out-of-the-box default; configurable via config.</summary>
        public static ItemPhysicsAssignment BuiltinDefault()
        {
            var a = ItemPhysicsAssignment.Default();
            a.Module = Cfg.DefaultModule;
            a.Trigger = Cfg.DefaultTrigger;
            a.Sticky = Cfg.DefaultSticky;
            return a;
        }

        /// <summary>
        /// Priority-resolved set. Wins strictly when priority >= current priority
        /// (ties: last writer wins). Returns effective assignment.
        /// </summary>
        public static ItemPhysicsAssignment Assign(ShipItem item, ItemPhysicsAssignment incoming)
        {
            var st = Register(item);
            if (st == null) return incoming;

            if (incoming.Priority < st.Assignment.Priority)
            {
                if (Cfg.Verbose)
                    Plugin.Log?.LogInfo(
                        "[Correct] assign rejected (prio " + incoming.Priority + " < " +
                        st.Assignment.Priority + ") for '" + item.name + "'");
                return st.Assignment;
            }

            incoming.IsDefault = false;
            if (string.IsNullOrEmpty(incoming.Source)) incoming.Source = "unknown";

            st.Assignment = incoming;
            if (incoming.Module == PhysicsModuleKind.Always && !st.Corrected)
                st.Corrected = true;

            if (st.HasSaveId)
            {
                SaveAssignments[st.SaveId] = incoming;
                if (st.Corrected) SaveCorrected.Add(st.SaveId);
            }
            MarkDirty();
            return incoming;
        }

        /// <summary>Remove an explicit record if the caller out-ranks its priority.</summary>
        public static bool Clear(ShipItem item, int priority)
        {
            var st = Get(item);
            if (st == null || st.Assignment.IsDefault) return true;
            if (priority < st.Assignment.Priority) return false;

            st.Assignment = BuiltinDefault();
            if (st.HasSaveId) SaveAssignments.Remove(st.SaveId);
            MarkDirty();
            return true;
        }

        /// <summary>Sticky correction latch (module fired).</summary>
        public static void MarkCorrected(CorrectState st)
        {
            if (st == null || st.Corrected) return;
            st.Corrected = true;
            if (st.HasSaveId)
            {
                SaveCorrected.Add(st.SaveId);
                MarkDirty();
            }
            else MarkDirty(); // session-only correctness still worth a dirty write note
        }

        // ---------------- persistence ----------------

        public static void MarkDirty()
        {
            _dirty = true;
        }

        /// <summary>Write pending changes into GameState.modData (game saves it).</summary>
        public static void FlushIfDirty()
        {
            if (!_dirty) return;
            _dirty = false;
            try
            {
                var sb = new StringBuilder(256);
                sb.Append("v").Append(FormatVersion).Append('|');

                foreach (var kv in SaveAssignments)
                {
                    var a = kv.Value;
                    sb.Append(kv.Key).Append(':')
                      .Append((int)a.Module).Append(':')
                      .Append((int)a.Trigger).Append(':')
                      .Append(a.Priority).Append(':')
                      .Append(a.Sticky ? 1 : 0).Append(':')
                      .Append(Sanitize(a.Source)).Append(';');
                }
                sb.Append('#');
                foreach (var id in SaveCorrected)
                    sb.Append(id).Append(';');

                GameState.modData[ModDataKey] = sb.ToString();

                if (Cfg.Verbose)
                    Plugin.Log?.LogInfo(
                        "[Correct] persisted: " + SaveAssignments.Count +
                        " assignments, " + SaveCorrected.Count + " corrected");
            }
            catch (Exception ex)
            {
                Plugin.Log?.LogWarning("[Correct] persist failed: " + ex.Message);
            }
        }

        /// <summary>(Re)read persisted state from GameState.modData (after world load).</summary>
        public static void LoadFromSaves()
        {
            try
            {
                SaveAssignments.Clear();
                SaveCorrected.Clear();
                _savesLoaded = true;

                string blob;
                if (!GameState.modData.TryGetValue(ModDataKey, out blob) ||
                    string.IsNullOrEmpty(blob))
                {
                    Plugin.Log?.LogInfo("[Correct] no persisted state (fresh)");
                    return;
                }

                string payload = blob.StartsWith("v1|") ? blob.Substring(3) : blob;
                int hashIdx = payload.IndexOf('#');
                string assignPart = hashIdx >= 0 ? payload.Substring(0, hashIdx) : payload;
                string corrPart = hashIdx >= 0 ? payload.Substring(hashIdx + 1) : "";

                foreach (var rec in assignPart.Split(';'))
                {
                    if (string.IsNullOrEmpty(rec)) continue;
                    var f = rec.Split(':');
                    if (f.Length < 6) continue;
                    int saveId, mod, trig, prio, sticky;
                    if (!int.TryParse(f[0], out saveId)) continue;
                    if (!int.TryParse(f[1], out mod)) continue;
                    if (!int.TryParse(f[2], out trig)) continue;
                    if (!int.TryParse(f[3], out prio)) continue;
                    if (!int.TryParse(f[4], out sticky)) continue;

                    SaveAssignments[saveId] = new ItemPhysicsAssignment
                    {
                        Module = (PhysicsModuleKind)mod,
                        Trigger = (PhysicsTrigger)trig,
                        Priority = prio,
                        Sticky = sticky != 0,
                        Source = f[5],
                        IsDefault = false
                    };
                }

                foreach (var rec in corrPart.Split(';'))
                {
                    if (string.IsNullOrEmpty(rec)) continue;
                    int id;
                    if (int.TryParse(rec, out id)) SaveCorrected.Add(id);
                }

                // re-apply to already-registered items
                foreach (var kv in ByRuntime)
                {
                    var st = kv.Value;
                    if (st == null || st.Item == null) continue;
                    if (st.HasSaveId)
                    {
                        st.Assignment = ResolveAssignment(st.SaveId, true);
                        if (SaveCorrected.Contains(st.SaveId)) st.Corrected = true;
                    }
                }

                Plugin.Log?.LogInfo(
                    "[Correct] loaded: " + SaveAssignments.Count + " assignments, " +
                    SaveCorrected.Count + " corrected");
            }
            catch (Exception ex)
            {
                Plugin.Log?.LogWarning("[Correct] load failed: " + ex.Message);
            }
        }

        public static bool SavesLoaded
        {
            get { return _savesLoaded; }
        }

        private static string Sanitize(string s)
        {
            if (string.IsNullOrEmpty(s)) return "?";
            return s.Replace(":", "_").Replace(";", "_").Replace("#", "_").Replace("|", "_");
        }
    }
}
