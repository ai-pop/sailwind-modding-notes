using System;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace SailwindItemPhysics.Correct
{
    /// <summary>
    /// v4.7.0 — resolves the GAME'S OWN throw/drop bindings from research facts
    /// (notes 57/60, verbatim from the v0.38 decompilation):
    ///
    ///   - Vanilla drops/throws on **GetKeyUp(InputName 10)** — the dedicated
    ///     desktop throw key; its default KeyCode is not visible in the
    ///     decompilation → probed at runtime via GameInput.GetKeyCode.
    ///   - With **Settings.autoThrow = true**, GetKeyUp(InputName 8) — the
    ///     interact key (build default "f") — drops/throws the same way.
    ///   - OnDrop() + DropItem() then run fully (sound, held=null,
    ///     **visual layer = 0** → the item stays clickable — note 58).
    ///
    /// The momentum throw just rides those transitions (never calls anything:
    /// user law — we write our own physics, vanilla owns the release).
    /// [Hold] ThrowKey is only the fallback when the probe is unavailable.
    /// Re-probed every 5 s — mid-game rebinds are picked up.
    /// </summary>
    internal static class DropKeyResolver
    {
        private static MethodInfo _getKeyCode;     // static GameInput.GetKeyCode
        private static Type _inputNameT;           // enum InputName
        private static FieldInfo _autoThrowF;      // static bool Settings.autoThrow
        private static float _nextProbe;

        private static KeyCode _throw = KeyCode.F;
        private static KeyCode _interact = KeyCode.F;
        private static bool _autoThrow;
        private static string _source = "boot";

        /// <summary>The dedicated Throw/drop key (InputName 10).</summary>
        internal static KeyCode ThrowKey { get { Tick(); return _throw; } }
        /// <summary>The interact key (InputName 8) — drops too when autoThrow.</summary>
        internal static KeyCode InteractKey { get { Tick(); return _interact; } }
        /// <summary>Settings.autoThrow as probed (false when unknown).</summary>
        internal static bool AutoThrowDrop { get { Tick(); return _autoThrow; } }

        private static void Tick()
        {
            float now = Time.unscaledTime;
            if (now < _nextProbe) return;
            _nextProbe = now + 5f;

            if (!Cfg.HoldDropKeyAuto)
            {
                Apply(Cfg.HoldThrowKey, Cfg.HoldThrowKey, false, "config");
                return;
            }

            try
            {
                if (_getKeyCode == null || _inputNameT == null)
                {
                    var gi = AccessTools.TypeByName("GameInput");
                    _inputNameT = AccessTools.TypeByName("InputName");
                    if (gi == null || _inputNameT == null)
                    {
                        Apply(Cfg.HoldThrowKey, Cfg.HoldThrowKey, false,
                              "config (GameInput/InputName not found)");
                        return;
                    }
                    var ms = gi.GetMethods(BindingFlags.Static |
                                           BindingFlags.Public | BindingFlags.NonPublic);
                    for (int i = 0; i < ms.Length; i++)
                    {
                        if (ms[i].Name != "GetKeyCode") continue;
                        var p = ms[i].GetParameters();
                        if (p.Length == 3 && p[0].ParameterType == _inputNameT &&
                            p[1].ParameterType == typeof(bool) &&
                            p[2].ParameterType == typeof(bool) &&
                            ms[i].ReturnType == typeof(KeyCode))
                        {
                            _getKeyCode = ms[i];
                            break;
                        }
                    }
                    if (_getKeyCode == null)
                    {
                        Apply(Cfg.HoldThrowKey, Cfg.HoldThrowKey, false,
                              "config (GameInput.GetKeyCode not found)");
                        return;
                    }

                    var st = AccessTools.TypeByName("Settings");
                    if (st != null)
                        _autoThrowF = st.GetField("autoThrow",
                            BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
                }

                object k10 = _getKeyCode.Invoke(null,
                    new[] { Enum.ToObject(_inputNameT, 10), false, false });   // Throw/drop
                object k8 = _getKeyCode.Invoke(null,
                    new[] { Enum.ToObject(_inputNameT, 8), false, false });    // interact

                KeyCode throwK = k10 is KeyCode && (KeyCode)k10 != KeyCode.None
                    ? (KeyCode)k10 : KeyCode.None;
                KeyCode interactK = k8 is KeyCode && (KeyCode)k8 != KeyCode.None
                    ? (KeyCode)k8 : KeyCode.None;

                bool autoThrow = false;
                if (_autoThrowF != null)
                {
                    try { autoThrow = (bool)(_autoThrowF.GetValue(null) ?? false); }
                    catch { autoThrow = false; }
                }

                if (throwK == KeyCode.None && interactK == KeyCode.None)
                {
                    Apply(Cfg.HoldThrowKey, Cfg.HoldThrowKey, autoThrow,
                          "config (bindings probe returned None)");
                    return;
                }
                if (throwK == KeyCode.None) throwK = interactK;   // autoThrow world
                if (interactK == KeyCode.None) interactK = throwK;

                Apply(throwK, interactK, autoThrow, "game binding");
            }
            catch
            {
                Apply(Cfg.HoldThrowKey, Cfg.HoldThrowKey, false, "config (probe failed)");
            }
        }

        private static void Apply(KeyCode throwK, KeyCode interactK, bool autoThrow, string source)
        {
            if (throwK == _throw && interactK == _interact &&
                autoThrow == _autoThrow && source == _source) return;
            _throw = throwK;
            _interact = interactK;
            _autoThrow = autoThrow;
            _source = source;
            Plugin.Log?.LogInfo(
                "[Hold] throw key = " + _throw + ", interact = " + _interact +
                ", autoThrow = " + _autoThrow + " (" + source + ") — releasing with" +
                " these lets go WITH the hand's momentum");
        }
    }
}
