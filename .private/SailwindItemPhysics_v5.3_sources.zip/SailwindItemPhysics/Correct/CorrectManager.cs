using System.Collections;
using SailwindItemPhysics.Api;
using SailwindItemPhysics.Bridge;
using SailwindItemPhysics.Ocean;
using SailwindItemPhysics.Sim;
using UnityEngine;

namespace SailwindItemPhysics.Correct
{
    /// <summary>
    /// Correctness layer engine:
    ///  - tracks every ShipItem in the world (Awake postfix + periodic sweep);
    ///  - evaluates module triggers (default: Grabbed) and latches sticky correction;
    ///  - drives the physics hold while a corrected item is in hands
    ///    (wheel = rotate like vanilla; v4.7.0: the game's own drop key
    ///    releases with measured hand momentum — note-57-aligned MomentumThrow);
    ///  - auto-attaches the surface float when a corrected free item meets water,
    ///    with an auto-profile measured from renderer bounds;
    ///  - persists state (debounced), reloads it after world (re)loads.
    /// </summary>
    internal sealed class CorrectManager : MonoBehaviour
    {
        private SurfaceBodyService _service;
        private SplashDirector _splash;

        private float _nextTick;        // 0.25 s cadence — cheap flag evaluation
        private float _nextFlush;       // 3 s cadence — persistence
        private float _nextSweep;       // 20 s cadence — find unregistered items
        private float _nextPurge;       // 30 s cadence — drop dead refs
        private bool _sweepAfterLoad = true;
        private float _loadGraceUntil;

        private HoldDriver _currentHold;
        private ShipItem _watchHeld;     // release-watch for the momentum throw

        public void Bind(SurfaceBodyService service, SplashDirector splash)
        {
            _service = service;
            _splash = splash;
        }

        public int TrackedCount { get { return CorrectRegistry.TrackedCount; } }

        public ShipItem CurrentHeldItem
        {
            get
            {
                return _currentHold != null && _currentHold.IsActive
                    ? _currentHold.GetComponent<ShipItem>()
                    : null;
            }
        }

        // ---------------- immune entry points ----------------

        /// <summary>Called by ItemBootPatches (ShipItem.Awake postfix) and the sweep.</summary>
        public static void NotifyItemSpawned(ShipItem item)
        {
            CorrectRegistry.Register(item);
        }

        /// <summary>Throw the currently held item; returns launch speed (0 = nothing held).</summary>
        public float ThrowHeld(float speed)
        {
            if (_currentHold == null || !_currentHold.IsActive) return 0f;
            return _currentHold.Throw(speed);
        }

        // ---------------- per-frame ----------------

        private void Update()
        {
            float now = Time.unscaledTime;

            // v4.4.0 split-world gate: one stabilized on/off-boat flag per frame
            BoatGate.Tick(now);

            // v4.7.0 momentum throw — pure RELEASE DETECTION (facts settled by
            // research notes 57–60): the game's own Throw/drop key (KeyUp,
            /// resolved live) makes vanilla release the item with its full
            // cleanup (layer=0 → clickable), then MomentumThrow re-launches
            // the twin with the hand's measured velocity at the first master
            // fixed frame — no grip-touching, no velocity-killing slave sync.
            MomentumThrow.TickInput();
            var heldNow = GoPointerPatches.HeldNow;
            if (_watchHeld != null && heldNow != _watchHeld)
                MomentumThrow.NotifyReleased(_watchHeld);
            _watchHeld = heldNow;

            if (now >= _nextTick)
            {
                _nextTick = now + 0.10f;   // v4.0.2: snappier hold pickup (cheap O(N) tick)
                TickCorrectness();
            }

            if (now >= _nextFlush)
            {
                _nextFlush = now + 3f;
                CorrectRegistry.FlushIfDirty();
            }

            if (now >= _nextPurge)
            {
                _nextPurge = now + 30f;
                CorrectRegistry.PurgeDead();
            }

            if (now >= _nextSweep)
            {
                _nextSweep = now + 20f;
                if (_sweepAfterLoad && Time.unscaledTime < _loadGraceUntil) SweepWorld();
                else if (Cfg.AutoSweepEvery20s) SweepWorld();
            }
        }

        /// <summary>World finished (re)loading — resync everything.</summary>
        public void NotifyWorldLoaded()
        {
            CorrectRegistry.LoadFromSaves();
            CorrectRegistry.PurgeDead();
            _sweepAfterLoad = true;
            _loadGraceUntil = Time.unscaledTime + 10f;
            if (_service != null) _service.ForceOceanRebind();
            SailwindItemPhysics.Sim.ItemDb.EnsureBuilt("worldload");   // v5.0.0: own item DB
            if (Cfg.DumpItemCatalog)
                DebugTools.ItemCatalogDumper.MaybeDump("worldload");
        }

        private void SweepWorld()
        {
            _sweepAfterLoad = false;
            try
            {
                var all = Object.FindObjectsOfType<ShipItem>();
                int newCount = 0;
                foreach (var item in all)
                {
                    if (item == null) continue;
                    if (CorrectRegistry.Get(item) == null)
                    {
                        CorrectRegistry.Register(item);
                        newCount++;
                    }
                }
                if (Cfg.Verbose)
                    Plugin.Log?.LogInfo("[Correct] sweep: tracked=" + CorrectRegistry.TrackedCount +
                                        " new=" + newCount);
            }
            catch { /* ok */ }
        }

        // ---------------- core evaluation ----------------

        private void TickCorrectness()
        {
            if (!Cfg.AutoCorrectEnabled) return;

            var states = CorrectRegistry.Snapshot();
            for (int i = 0; i < states.Count; i++)
            {
                var st = states[i];
                var item = st.Item;
                if (item == null) continue;

                bool held;
                try { held = item.held != null; }
                catch { continue; }

                // --- trigger evaluation (sticky latch) ---
                st.TriggerActiveNow = EvaluateTrigger(st, item, held);
                if (st.TriggerActiveNow && !st.Corrected)
                {
                    CorrectRegistry.MarkCorrected(st);
                    if (Cfg.Verbose)
                        Plugin.Log?.LogInfo("[Correct] '" + item.name + "' became physically correct (" +
                                            st.Assignment.Module + "/" + st.Assignment.Trigger +
                                            ", src=" + st.Assignment.Source + ")");
                }

                bool corr = st.CorrectActive;

                // --- physics hold coordination ---
                // v4.5.0: [Hold] PhysicsInHands=false (DEFAULT) — no physical body
                // in hands at all (eating/item-use broke on real bodies); the grip
                // is vanilla + visual imitation everywhere. The full physics-hold
                // machinery stays behind the flag (off boats, 4.4.1 semantics).
                if (corr && held && Cfg.HoldEnabled && Cfg.HoldPhysicsInHands &&
                    !(Cfg.HoldVanillaOnBoat && BoatGate.PlayerOnBoat))
                {
                    st.ReleasedTicks = 0;
                    var hd = HoldDriver.Get(item);
                    if (hd == null) hd = item.gameObject.AddComponent<HoldDriver>();
                    if (!hd.IsActive && !HoldRegistry.IsBlacklisted(item))
                    {
                        hd.Activate();
                        st.HoldActive = true;
                        _currentHold = hd;
                        if (_splash != null) _splash.NotifyHoldStart(item);
                    }
                }
                else if (st.HoldActive)
                {
                    // v4.0.1 hysteresis: a flickering 'held' flag (single lost frame)
                    // must NOT tear the hold down — require 2 clean ticks of release
                    // (or the config kill-switch, which acts immediately)
                    if (!Cfg.HoldEnabled) st.ReleasedTicks = 99;
                    else if (!held) st.ReleasedTicks++;
                    else { st.ReleasedTicks = 0; continue; }

                    if (st.ReleasedTicks >= 2)
                    {
                        var hd = HoldDriver.Get(item);
                        if (hd != null && hd.IsActive) hd.Deactivate(true);
                        st.HoldActive = false;
                        st.ReleasedTicks = 0;
                        if (_currentHold == hd) _currentHold = null;
                    }
                }

                // --- auto surface-float for corrected free items in water ---
                if (corr && !held && !st.FloatAttachedByUs && !st.HoldActive)
                {
                    if (IsFreeInWater(item))
                    {
                        if (_service != null && _service.Attach(item, AutoProfile(item)))
                        {
                            st.FloatAttachedByUs = true;
                            if (Cfg.Verbose)
                                Plugin.Log?.LogInfo("[Correct] auto-float '" + item.name + "'");
                        }
                    }
                }

                // consumed by the game (sold/eaten/…) — DropExtra will purge later anyway
                if (!corr && !held && st.HoldActive) st.HoldActive = false;
            }
        }

        private bool EvaluateTrigger(CorrectState st, ShipItem item, bool held)
        {
            var a = st.Assignment;
            if (a.Module == PhysicsModuleKind.Always) return true;
            switch (a.Trigger)
            {
                case PhysicsTrigger.Grabbed:
                    return held;
                case PhysicsTrigger.InWorld:
                    return !held && IsFreeOfContainers(item);
                case PhysicsTrigger.Submerged:
                    return !held && IsFreeInWater(item);
                default:
                    return false;
            }
        }

        private static bool IsFreeOfContainers(ShipItem item)
        {
            try
            {
                var twin = ItemAccess.GetTwin(item);
                if (twin != null && (ItemAccess.IsContained(twin) || ItemAccess.IsOnBoat(twin)))
                    return false;
            }
            catch { /* ok */ }
            return true;
        }

        private static bool IsFreeInWater(ShipItem item)
        {
            if (!IsFreeOfContainers(item)) return false;
            try
            {
                float y;
                if (!OceanSurface.TryGetY(item.transform.position, out y)) return false;
                // in/near water: pivot at or below 0.6 m over the surface
                return item.transform.position.y < y + 0.6f;
            }
            catch { return false; }
        }

        // ---------------- auto profile ----------------

        /// <summary>Float profile measured from renderer bounds + item mass.</summary>
        internal static Api.FloatProfile AutoProfile(ShipItem item)
        {
            var p = Api.FloatProfile.Crate();
            try
            {
                Vector3 e = new Vector3(0.4f, 0.4f, 0.4f);
                var rend = item.GetComponentInChildren<Renderer>();
                if (rend != null)
                {
                    e = rend.bounds.extents;
                    e.x = Mathf.Clamp(e.x, 0.05f, 1.6f);
                    e.y = Mathf.Clamp(e.y, 0.05f, 1.6f);
                    e.z = Mathf.Clamp(e.z, 0.05f, 1.6f);
                }

                float mass = Bridge.ItemAccess.EffectiveMass(item, 10f);

                p.Name = "auto";
                p.HalfExtents = e;
                p.Freeboard = Mathf.Clamp(e.y * 0.35f, 0.05f, 0.6f);
                // v4.6.0 Archimedes: water displaced by the whole bounds hull —
                // the driver settles the body at submerged fraction mass/this,
                // so weight decides draft (heavy → deep, dense → sinks)
                p.NeutralBuoyancyMass = Mathf.Clamp(
                    8f * e.x * e.y * e.z * Cfg.FloatHullDensity, 2f, 2000f);
                p.MassMin = Mathf.Max(0.5f, mass * 0.5f);
                p.MassMax = Mathf.Max(p.MassMin + 1f, mass * 2f);
                p.BuoyancyAccel = Mathf.Clamp(24f - mass * 0.06f, 12f, 24f);
                p.ComDown = Mathf.Clamp(e.y * 0.35f, 0.04f, 0.4f);

                // dense cargo drowns if it stays under (auto SinkStartDepth too:
                // the driver disarms recovery for honestly-dense bodies)
                if (mass > Mathf.Max(55f, p.NeutralBuoyancyMass * 1.05f))
                {
                    p.CanSink = true;
                    p.SinkStartDepth = Mathf.Max(0.6f + e.y, 1.2f);
                }

                // light debris drifts harder
                if (mass < 5f)
                {
                    p.WindAccel = 0.8f;
                    p.HeaveCoupling = 1.1f;
                }

                return p.Validate();
            }
            catch
            {
                return Api.FloatProfile.Crate();
            }
        }

        // ---------------- helpers for manager wiring ----------------

        public HoldDriver CurrentHold
        {
            get { return _currentHold; }
        }
    }
}
