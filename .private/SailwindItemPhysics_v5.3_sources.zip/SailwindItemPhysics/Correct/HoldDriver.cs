using System.Collections;
using SailwindItemPhysics.Bridge;
using UnityEngine;

namespace SailwindItemPhysics.Correct
{
    /// <summary>
    /// Physics hold — the held item is a real dynamic body that lags behind the
    /// aim point, bumps into walls/deck, and can be launched (G). v4.2.0:
    ///
    ///  - wheel=distance REMOVED (user: wheel belongs to vanilla item rotation);
    ///    the wheel now ROTATES the body around the view axis like vanilla does.
    ///  - twin colliders become SOLID while held (vanilla parks them isTrigger);
    ///    previous versions left them trigger, so held items ghosted through
    ///    geometry — that was the missing "physics in hands".
    ///  - activation ALWAYS kinematic-resnaps the twin onto the visual
    ///    (vanilla contract is twin=visual anyway). No more 462 m aborts and
    ///    no blackout-blacklisting of vanilla items picked up on the boat.
    ///  - floater is force-disabled for the duration of the hold (it would
    ///    otherwise fight the spring whenever the hand crosses water).
    ///  - collisions with the player capsule are ignored while held.
    ///  - MirrorLoop (WaitForEndOfFrame) removed: it fired AFTER render,
    ///    so it could never win the frame. The final visual word is now the
    ///    GoPointer.LateUpdate postfix (GoPointerPatches) + this script's
    ///    LateUpdate at order 600.
    /// </summary>
    [DefaultExecutionOrder(600)]
    public sealed class HoldDriver : MonoBehaviour
    {
        private ShipItem _item;
        private Component _twin;
        private Rigidbody _rb;
        private bool _active;
        private bool _launched;      // true after Throw — keep the body dynamic
        private Camera _cam;

        // aim/leash
        private float _holdDist = 1.7f;
        private Quaternion _grabLocalRot = Quaternion.identity; // rb rot relative to the pointer at grab
        private float _grabPitch;                               // wheel rotation (vanilla style), degrees

        // restored state
        private bool _prevKinematic;
        private bool _prevGravity;
        private float _prevAngDrag;
        private float _prevDrag;
        private float _prevMaxAngVel;
        private CollisionDetectionMode _prevCDM;

        // collider state (solid while held, restored on release)
        private Collider[] _cols;
        private bool[] _wasTrigger;

        // v4.3.2: other items' twins are SOLID free bodies — lifting a crate out
        // of a crowded hold bounced it off the neighbors (vanilla held items are
        // trigger-ghosts and glide out of any stack). While held, ignore other
        // item-twins pairwise; the set refreshes (streaming) every few seconds.
        private Collider[] _itemTwinCols;
        private float _nextItemColsScan;
        private readonly System.Collections.Generic.List<Collider> _ignoredItemCols =
            new System.Collections.Generic.List<Collider>(32);

        // smoothing of the aim point (kills camera micro-jitter)
        private Vector3 _aimPoint;
        private bool _hasAim;

        // guard rails
        private const float AbortDrift = 20f;      // twin further than this from the eye = bail
        private const float SpeedCap = 9f;
        private const int ReleaseFrames = 6;       // held==null must persist ~0.12 s (anti-flicker)
        private const int NoCamFrames = 30;        // camera loss tolerated ~0.6 s

        private int _releaseFrames;
        private int _noCamFrames;
        private int _reclaims;
        private float _reclaimWindowT;
        private Vector3 _lastRbPos;
        private bool _hasLastPos;

        // vanilla anchor (note 47): ShipItem.held IS the GoPointer; the visual is
        // placed at ptr.pos + ptr.fwd*holdDistance + ptr.up*holdHeight each LateUpdate
        private float _anchorDist = 1.15f;   // vanilla default
        private float _anchorHeight = 0f;    // vanilla default

        // player collider cache (ignored while held so the body can't shove the player)
        private static Collider[] _playerCols;
        private static float _playerColsT;

        private string TwinParentName()
        {
            try
            {
                var p = _twin != null ? _twin.transform.parent : null;
                return p != null ? p.name : "-";
            }
            catch { return "?"; }
        }

        // camera is shared and cached — re-resolving every frame is what made
        // brief camera hiccups tear the hold down (vanilla fight oscillation)
        private static Camera _sharedCam;
        private static float _sharedCamT;

        private HoldCollisionSpy _spy;

        public bool IsActive { get { return _active; } }
        public float HoldDistance { get { return _holdDist; } set { _holdDist = Mathf.Clamp(value, 0.8f, 6.5f); } }

        public static HoldDriver Get(ShipItem item)
        {
            return item != null ? item.GetComponent<HoldDriver>() : null;
        }

        // ---------------- lifecycle ----------------

        public void Activate()
        {
            if (_active) return;
            if (_item == null) _item = GetComponent<ShipItem>();
            StopAllCoroutines();
            StartCoroutine(ActivateRoutine());
        }

        /// <summary>
        /// restore=true: give the full original state back (normal release).
        /// After Throw we pass false for the kinematic/gravity part via _launched,
        /// so the launched body stays dynamic and flies.
        /// </summary>
        public void Deactivate(bool restore)
        {
            StopAllCoroutines();
            if (_active && _rb != null && restore)
            {
                try
                {
                    if (!_launched)
                    {
                        _rb.isKinematic = _prevKinematic;
                        _rb.useGravity = _prevGravity;
                        // vanilla contract while held: twin follows visual — hand back clean
                        if (_item != null)
                        {
                            _rb.transform.position = _item.transform.position;
                            _rb.transform.rotation = _item.transform.rotation;
                        }
                        _rb.velocity = Vector3.zero;
                        _rb.angularVelocity = Vector3.zero;
                    }
                    else
                    {
                        _rb.useGravity = true;
                        _rb.isKinematic = false;
                    }
                    _rb.drag = _prevDrag;
                    _rb.angularDrag = _prevAngDrag;
                    _rb.maxAngularVelocity = _prevMaxAngVel;
                    _rb.collisionDetectionMode = _prevCDM;
                }
                catch { /* ok */ }
            }
            // un-ignore BEFORE RestoreColliders wipes _cols, else the pair stays ignored
            SetPlayerCollisionIgnore(false);
            if (_cols != null) BoatColliderCache.SetIgnore(_cols, false, ItemBoatTransform());
            SetItemCollidersIgnore(false);
            RestoreColliders();
            if (_spy != null)
            {
                try { Object.Destroy(_spy); } catch { /* ok */ }
                _spy = null;
            }
            _active = false;
            _hasAim = false;
            _launched = false;
            _cam = null;
            HoldRegistry.Remove(_item);
        }

        private void OnDisable() { Deactivate(true); }
        private void OnDestroy() { Deactivate(true); }

        private IEnumerator ActivateRoutine()
        {
            // twin may need a frame (note 44) while hands are involved
            for (int i = 0; i < 90; i++)
            {
                if (_item == null) yield break;
                if (_item.held == null) yield break;    // dropped before we even started
                _twin = ItemAccess.GetTwin(_item);
                _rb = ItemAccess.GetRigidbody(_item);
                if (_rb != null && _twin != null) break;
                yield return null;
            }
            if (_rb == null || _twin == null || _item == null) yield break;

            // body must live on the twin's own GameObject. Exotic prefabs
            // (composite bodies) can answer GetBody() with a foreign rigidbody —
            // drive only the twin-local one, else refuse the hold.
            if (_rb.gameObject != _twin.gameObject)
            {
                var local = _twin.GetComponent<Rigidbody>();
                if (local != null) _rb = local;
            }
            if (_rb.gameObject != _twin.gameObject)
            {
                Plugin.Log?.LogWarning("[Hold] '" + name + "' — rigidbody not on twin GO ('" +
                                       _rb.gameObject.name + "' vs '" + _twin.gameObject.name +
                                       "'), hold aborted, blacklisted 60 s");
                HoldRegistry.Blacklist(_item, 60f);
                yield break;
            }

            // REQUIRE an aim anchor: the holding pointer OR a gameplay camera
            _cam = SharedCamera();
            if (_cam == null && PointerTransform() == null)
            {
                Plugin.Log?.LogWarning("[Hold] '" + name + "' — no aim anchor (camera & pointer), hold aborted (vanilla grip)");
                yield break;
            }

            // v4.2.0: twin state at grab is IRRELEVANT — vanilla's own contract
            // while held is twin=visual (note 47/A5), so the resnap is always legal.
            // Between pickup and this activation vanilla could have reseated the twin
            // through MoveRigidbodyToWalkCol with a stale walkCol pair (~462 m away);
            // we simply bring it back instead of aborting + blacklisting.
            float staleGap = Vector3.Distance(_rb.transform.position, _item.transform.position);
            if (staleGap > 5f)
            {
                Plugin.Log?.LogWarning("[Hold] '" + name + "' — twin " + staleGap.ToString("0") +
                                       " m from the visual (parent='" + TwinParentName() +
                                       "' onBoat=" + ItemAccess.IsOnBoat(_twin) +
                                       "), snapping it back into the hand");
            }

            try
            {
                _prevKinematic = _rb.isKinematic;
                _prevGravity = _rb.useGravity;
                _prevDrag = _rb.drag;
                _prevAngDrag = _rb.angularDrag;
                _prevMaxAngVel = _rb.maxAngularVelocity;
                _prevCDM = _rb.collisionDetectionMode;
            }
            catch { /* ok */ }

            // resnap ALWAYS (any gap): the hand is the only truth here
            try
            {
                _rb.isKinematic = true;
                _rb.transform.position = _item.transform.position;
                _rb.transform.rotation = _item.transform.rotation;
                _rb.velocity = Vector3.zero;
                _rb.angularVelocity = Vector3.zero;
            }
            catch { /* ok */ }

            // kinematic bodies don't take forces — force dynamic for the hold
            ItemAccess.PrepareForWorldFloat(_item);
            ItemAccess.ForceDynamic(_rb);
            ItemAccess.SetFloaterEnabled(_twin, false);   // floater would fight the spring

            try
            {
                _rb.useGravity = false;
                _rb.drag = 0.4f;
                _rb.angularDrag = 3f;
                _rb.maxAngularVelocity = 6f;
                _rb.detectCollisions = true;
                // v4.2.1: Discrete while held. Items carry Continuous/ContinuousDynamic
                // from vanilla (note 47/A5); a solid body with CCD stuck INSIDE the
                // boat's big mesh collider is Unity's classic hard-freeze/CTD class,
                // and that is exactly the "crashes when it touches the ship" report.
                _rb.collisionDetectionMode = CollisionDetectionMode.Discrete;
                _rb.WakeUp();
            }
            catch { /* ok */ }

            SniffVanillaAnchor();
            NeutralizeStaleBoatAnchor();
            GrabSetup();
            MakeCollidersSolid();          // THE physics in hands: bump into walls/deck
            SetPlayerCollisionIgnore(true);
            // note 51/52: the boat root carries a buoyancy CapsuleCollider towering
            // above the deck; the player walks through it (layer 12 walkCol) but a
            // solid twin (layer 2) would stand "in mid-air" on it AND fight the
            // solver (the ship-touch CTD) AND spam BoatDamage (note 55: twins are
            // Untagged, Impact doesn't filter them → 0.15 hull damage/sec).
            // v4.3.1: also the parentless deck mesh (HullPlayerCollider dup) — it
            // kept the solid twin clanging on the hatch rim so items refused to
            // follow into the hold. Pairwise-ignore the whole boat while held.
            if (_cols != null) BoatColliderCache.SetIgnore(_cols, true, ItemBoatTransform());
            ScanItemColliders();
            SetItemCollidersIgnore(true);

            _active = true;
            _reclaims = 0;
            _reclaimWindowT = 0f;
            HoldRegistry.Add(_item, _twin);

            // forensics: name the collider class if the item still hits anything
            try
            {
                var spy = _twin.gameObject.AddComponent<HoldCollisionSpy>();
                spy.ItemName = name;
                spy.OwnCols = _cols;
                _spy = spy;
            }
            catch { /* ok */ }

            Plugin.Log?.LogInfo("[Hold] active '" + name + "' mass=" +
                                _rb.mass.ToString("0.0") + " dist=" + _holdDist.ToString("0.0") +
                                " gap=" + staleGap.ToString("0.00") +
                                " cols=" + (_cols != null ? _cols.Length : 0) +
                                (Cfg.HoldSolidColliders ? "(solid)" : "(trigger-cfg)") +
                                " cdm=" + _rb.collisionDetectionMode);
        }

        private void GrabSetup()
        {
            var anchorT = PointerTransform();
            Quaternion anchorRot = anchorT != null
                ? anchorT.rotation
                : (_cam != null ? _cam.transform.rotation : _rb.rotation);
            _grabLocalRot = Quaternion.Inverse(anchorRot) * _rb.rotation;
            _grabPitch = 0f;

            var e = EstimateExtents();
            // vanilla-respecting base (holdDistance) + a bit of room for big items
            _holdDist = Mathf.Clamp(_anchorDist + e.magnitude * 0.25f,
                                    Mathf.Max(1.0f, _anchorDist), 3.2f);
        }

        /// <summary>The GoPointer transform holding this item (note 47: held IS the pointer).</summary>
        private Transform PointerTransform()
        {
            try
            {
                var c = _item != null ? _item.held as Component : null;
                return c != null ? c.transform : null;
            }
            catch { return null; }
        }

        /// <summary>Vanilla hold anchor offsets (holdDistance/holdHeight) off the item.</summary>
        private void SniffVanillaAnchor()
        {
            try
            {
                if (_item == null) return;
                var f1 = FindInHierarchy(_item.GetType(), "holdDistance");
                if (f1 != null)
                {
                    object v = f1.GetValue(_item);
                    if (v is float) _anchorDist = Mathf.Clamp((float)v, 0.8f, 3.2f);
                }
                var f2 = FindInHierarchy(_item.GetType(), "holdHeight");
                if (f2 != null)
                {
                    object v = f2.GetValue(_item);
                    if (v is float) _anchorHeight = (float)v;
                }
            }
            catch { /* defaults are fine */ }
        }

        /// <summary>
        /// Note 47/A5: while held on a boat, vanilla seats the twin via
        /// MoveRigidbodyToWalkCol ≈ walkCol.TransformPoint(actualBoat.InverseTransformPoint(visual)).
        /// When the boat/walkCol reference pair is stale (origin shift, despawned boat),
        /// that roundtrip lands hundreds of meters away. Predict the roundtrip; on a
        /// proven misfit clear the stale reference so the vanilla fallback becomes
        /// the harmless twin=visual path.
        /// </summary>
        private void NeutralizeStaleBoatAnchor()
        {
            Transform walk = null;
            System.Reflection.FieldInfo walkF = null;
            try
            {
                if (_item == null) return;
                walkF = FindInHierarchy(_item.GetType(), "currentWalkCol")
                        ?? FindInHierarchy(_item.GetType(), "walkCol");
                if (walkF == null) return;
                walk = walkF.GetValue(_item) as Transform;
                if (walk == null) return;

                var boatF = FindInHierarchy(_item.GetType(), "currentActualBoat")
                            ?? FindInHierarchy(_item.GetType(), "actualBoat");
                var boat = boatF != null ? boatF.GetValue(_item) as Transform : null;
                if (boat == null) return;

                Vector3 predicted =
                    walk.TransformPoint(boat.InverseTransformPoint(_item.transform.position));
                float misfit = Vector3.Distance(predicted, _item.transform.position);
                if (misfit > 40f)
                {
                    Plugin.Log?.LogWarning("[Hold] '" + name + "' — boat anchor stale (walkCol='" +
                                           walk.name + "' boat='" + boat.name + "', misfit " +
                                           misfit.ToString("0") +
                                           " m), clearing currentWalkCol so vanilla cannot teleport the twin");
                    walkF.SetValue(_item, null);
                }
            }
            catch { /* never block a pickup on this probe */ }
        }

        /// <summary>The boat THIS item belongs to (currentActualBoat), if any —
        /// lets the ignore set cover the item's own boat even when the player
        /// stands elsewhere (dockside unloading).</summary>
        private Transform ItemBoatTransform()
        {
            try
            {
                if (_item == null) return null;
                var f = FindInHierarchy(_item.GetType(), "currentActualBoat");
                return f != null ? f.GetValue(_item) as Transform : null;
            }
            catch { return null; }
        }

        private static System.Reflection.FieldInfo FindInHierarchy(System.Type t, string name)
        {
            for (var c = t; c != null && c != typeof(object); c = c.BaseType)
            {
                var f = c.GetField(name,
                        System.Reflection.BindingFlags.Instance |
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.NonPublic |
                        System.Reflection.BindingFlags.DeclaredOnly);
                if (f != null) return f;
            }
            return null;
        }

        // ---------------- colliders ----------------

        /// <summary>
        /// Vanilla parks held items with isTrigger colliders — a held body ghosts
        /// through walls. For a REAL physics hold the body must collide, so we
        /// flip every twin collider to solid for the duration of the hold and
        /// remember what to restore.
        /// </summary>
        private void MakeCollidersSolid()
        {
            // v4.2.1 kill-switch: if solid-in-hand ever misbehaves on some boat,
            // [Hold] SolidCollidersInHand=false returns vanilla ghosting instantly
            if (!Cfg.HoldSolidColliders) return;
            try
            {
                _cols = _twin.GetComponentsInChildren<Collider>(true);
                if (_cols == null || _cols.Length == 0) { _cols = null; return; }
                _wasTrigger = new bool[_cols.Length];
                for (int i = 0; i < _cols.Length; i++)
                {
                    var c = _cols[i];
                    if (c == null) continue;
                    _wasTrigger[i] = c.isTrigger;
                    c.isTrigger = false;
                    c.enabled = true;
                }
            }
            catch { _cols = null; _wasTrigger = null; }
        }

        private void RestoreColliders()
        {
            if (_cols == null) return;
            try
            {
                // A launched (thrown) body stays solid — vanilla flips
                // isTrigger=false itself on the next FixedUpdate once held==null.
                if (!_launched)
                {
                    for (int i = 0; i < _cols.Length; i++)
                    {
                        var c = _cols[i];
                        if (c == null || _wasTrigger == null || i >= _wasTrigger.Length) continue;
                        c.isTrigger = _wasTrigger[i];
                    }
                }
            }
            catch { /* ok */ }
            _cols = null;
            _wasTrigger = null;
        }

        private static Collider[] PlayerColliders()
        {
            if (_playerCols != null && Time.unscaledTime < _playerColsT) return _playerCols;
            _playerColsT = Time.unscaledTime + 10f;
            _playerCols = null;
            try
            {
                Component root = null;
                if (Refs.charController != null) root = Refs.charController;
                else if (Refs.observerMirror != null) root = Refs.observerMirror;
                if (root != null)
                    _playerCols = root.GetComponentsInChildren<Collider>(true);
            }
            catch { /* ok */ }
            return _playerCols;
        }

        private void SetPlayerCollisionIgnore(bool ignore)
        {
            var pcs = PlayerColliders();
            if (pcs == null || _cols == null) return;
            for (int i = 0; i < _cols.Length; i++)
            {
                var a = _cols[i];
                if (a == null) continue;
                for (int j = 0; j < pcs.Length; j++)
                {
                    var b = pcs[j];
                    if (b == null || b == a) continue;
                    try { Physics.IgnoreCollision(a, b, ignore); } catch { /* ok */ }
                }
            }
        }

        /// <summary>Collect colliders of every other item's twin (correctness
        /// registry = all tracked ShipItems, no world scan).</summary>
        private void ScanItemColliders()
        {
            _nextItemColsScan = Time.unscaledTime + 3f;
            try
            {
                var snap = CorrectRegistry.Snapshot();
                if (snap == null) return;
                var list = new System.Collections.Generic.List<Collider>(snap.Count * 2);
                for (int i = 0; i < snap.Count; i++)
                {
                    var st = snap[i];
                    var it = st != null ? st.Item : null;
                    if (it == null || it == _item) continue;
                    var twin = ItemAccess.GetTwin(it);
                    if (twin == null) continue;
                    var cs = twin.GetComponentsInChildren<Collider>(true);
                    if (cs != null) list.AddRange(cs);
                }
                _itemTwinCols = list.ToArray();
            }
            catch { /* keep the previous set */ }
        }

        private void SetItemCollidersIgnore(bool ignore)
        {
            if (_cols == null) return;

            if (!ignore)
            {
                for (int i = 0; i < _ignoredItemCols.Count; i++)
                {
                    var b = _ignoredItemCols[i];
                    if (b == null) continue;
                    for (int k = 0; k < _cols.Length; k++)
                    {
                        var a = _cols[k];
                        if (a == null) continue;
                        try { Physics.IgnoreCollision(a, b, false); } catch { /* ok */ }
                    }
                }
                _ignoredItemCols.Clear();
                return;
            }

            if (_itemTwinCols == null) return;
            for (int j = 0; j < _itemTwinCols.Length; j++)
            {
                var b = _itemTwinCols[j];
                if (b == null) continue;
                bool already = false;
                for (int i = 0; i < _ignoredItemCols.Count; i++)
                    if (ReferenceEquals(_ignoredItemCols[i], b)) { already = true; break; }
                if (already) continue;

                for (int k = 0; k < _cols.Length; k++)
                {
                    var a = _cols[k];
                    if (a == null || a == b) continue;
                    try { Physics.IgnoreCollision(a, b, true); } catch { /* ok */ }
                }
                _ignoredItemCols.Add(b);
            }
        }

        // ---------------- input ----------------

        /// <summary>
        /// Wheel ROTATES the held body — same binding vanilla uses for rotation,
        /// just applied to the physics body instead of the visual (v4.2.0: the
        /// old wheel=distance GMod-ism is gone).
        /// </summary>
        private void Update()
        {
            if (!_active) return;
            float wheel = Input.mouseScrollDelta.y;
            if (Mathf.Abs(wheel) > 0.01f)
                _grabPitch -= wheel * 15f;   // ~15° per notch around the view-right axis
        }

        // ---------------- simulation ----------------

        private void FixedUpdate()
        {
            if (!_active || _rb == null) return;
            if (_item == null) { Deactivate(true); return; }

            // v4.4.0 split-world rule: the player stepped ONTO a boat while
            // holding this item — the whole point of the boat saga was that our
            // solid body can never win against the boat's collider stack
            // (capsule dome / walkCol / layer-12 mesh). So on a boat the grip
            // is 100% VANILLA: hand the body back clean (restore path snaps it
            // to the visual, restores trigger-state, un-ignores the world);
            // CorrectManager re-activates the physics hold automatically the
            // moment the player steps back off the boat.
            if (Cfg.HoldVanillaOnBoat && BoatGate.PlayerOnBoat)
            {
                Plugin.Log?.LogInfo("[Hold] '" + name +
                                    "' — player on boat: grip handed back to vanilla " +
                                    "(physics returns when you step off)");
                Deactivate(true);
                return;
            }

            // note 47: 'held' is stable from PickUpItem to DropItem — but keep the
            // short hysteresis anyway (harmless, guards modded DropItem patches)
            if (_item.held == null)
            {
                if (++_releaseFrames >= ReleaseFrames) Deactivate(true);
                return;   // no forces this frame — spring resumes seamlessly if it was a flicker
            }
            _releaseFrames = 0;

            // aim anchor is ultimately the pointer; camera only backstops it
            if (PointerTransform() == null)
            {
                if (_cam == null || !_cam.isActiveAndEnabled)
                    _cam = SharedCamera();
                if (_cam == null)
                {
                    if (++_noCamFrames >= NoCamFrames)
                    {
                        Plugin.Log?.LogWarning("[Hold] '" + name + "' — no aim anchor, releasing to vanilla");
                        Deactivate(true);
                    }
                    return;
                }
            }
            _noCamFrames = 0;

            // anchor: prefer the holding GoPointer itself (note 47) — camera is only
            // the fallback so the physics aim lives where vanilla would hold the item
            var anchorT = PointerTransform();
            Vector3 eye = anchorT != null ? anchorT.position : _cam.transform.position;
            Vector3 fwd = anchorT != null ? anchorT.forward : _cam.transform.forward;

            // guards: finite + near. Anything else = give vanilla its item back.
            Vector3 rbPos = _rb.position;
            if (!Finite(rbPos) || !Finite(_rb.velocity))
            {
                Plugin.Log?.LogWarning("[Hold] '" + name + "' — non-finite body state, aborting hold");
                Deactivate(true);
                return;
            }
            bool teleported = (rbPos - eye).sqrMagnitude > AbortDrift * AbortDrift;
            // v4.2.1 per-frame watchdog: 9 m/s cap moves ≤0.18 m per fixed frame —
            // anything beyond 2.5 m in one tick is an external reseat, not physics
            if (!teleported && _hasLastPos &&
                (rbPos - _lastRbPos).sqrMagnitude > 2.5f * 2.5f)
                teleported = true;
            if (teleported)
            {
                // this is NOT physics drift (speed cap is 9 m/s) — an external
                // vanilla system teleported the twin. Reclaim the body; if the war
                // repeats, blacklist the item and leave it to vanilla.
                if (Time.unscaledTime < _reclaimWindowT) _reclaims++;
                else { _reclaimWindowT = Time.unscaledTime + 5f; _reclaims = 1; }

                if (_reclaims <= 3)
                {
                    Plugin.Log?.LogInfo("[Hold] '" + name + "' — twin teleported " +
                                        Vector3.Distance(rbPos, eye).ToString("0.0") +
                                        " m externally (parent='" + TwinParentName() +
                                        "' onBoat=" + ItemAccess.IsOnBoat(_twin) +
                                        "), reclaiming " + _reclaims + "/3");
                    try
                    {
                        _rb.isKinematic = true;
                        _rb.transform.position = eye + fwd * _holdDist;
                        _rb.velocity = Vector3.zero;
                        _rb.angularVelocity = Vector3.zero;
                        _rb.isKinematic = false;
                    }
                    catch { /* ok */ }
                    _hasAim = false;
                    _hasLastPos = false;   // the snap itself is big — don't flag it next tick
                    return;
                }

                Plugin.Log?.LogWarning("[Hold] '" + name + "' — teleport war lost, blacklisted 10 s (vanilla grip)");
                HoldRegistry.Blacklist(_item, 10f);
                Deactivate(true);
                return;
            }
            _lastRbPos = rbPos;
            _hasLastPos = true;

            // streamed-in crates/etc. join the ignore set every few seconds
            if (_cols != null && Time.unscaledTime >= _nextItemColsScan)
            {
                ScanItemColliders();
                SetItemCollidersIgnore(true);
            }

            // aim point anchored like vanilla does (holdHeight offset included)
            Vector3 target = anchorT != null
                ? eye + fwd * _holdDist + anchorT.up * _anchorHeight
                : eye + fwd * _holdDist;
            float dt = Time.fixedDeltaTime;
            if (!_hasAim) { _aimPoint = target; _hasAim = true; }
            else _aimPoint = Vector3.Lerp(_aimPoint, target, 1f - Mathf.Exp(-18f * dt));
            target = _aimPoint;

            Vector3 err = target - rbPos;
            // clamp the error so a re-seated twin cannot rocket across the room
            if (err.sqrMagnitude > 16f) err = err.normalized * 4f;

            // Mass-aware damped spring — ForceMode.Force so Unity divides by mass:
            // heavy items resist the spring naturally, light ones snap to the hand.
            float mass = Mathf.Max(_rb.mass, 0.5f);
            float stiffness = 40f;   // spring stiffness scaled by mass
            float damping = 15f;     // velocity damping scaled by mass
            Vector3 springForce = err * (stiffness * mass);
            Vector3 dampForce = -_rb.velocity * (damping * mass);
            Vector3 totalForce = springForce + dampForce;
            float maxSpringForce = 3200f;   // safety cap ~65 kg crate at 5g
            if (totalForce.sqrMagnitude > maxSpringForce * maxSpringForce)
                totalForce = totalForce.normalized * maxSpringForce;
            _rb.AddForce(totalForce, ForceMode.Force);

            // orientation: keep the grabbed pose relative to the pointer +
            // wheel pitch — one quaternion PD instead of separate yaw/level hacks
            Quaternion baseRot = anchorT != null
                ? anchorT.rotation
                : (_cam != null ? _cam.transform.rotation : _rb.rotation);
            Quaternion targetRot = baseRot * Quaternion.Euler(_grabPitch, 0f, 0f) * _grabLocalRot;
            Quaternion dq = targetRot * Quaternion.Inverse(_rb.rotation);
            float ang;
            Vector3 axis;
            dq.ToAngleAxis(out ang, out axis);
            if (ang > 180f) ang -= 360f;
            if (axis.sqrMagnitude > 1e-8f && !float.IsNaN(ang) && Finite(axis))
            {
                float mass = Mathf.Max(_rb.mass, 0.5f);
                // Angular spring: torque = I * (kp*angle - kd*omega) → ForceMode.Force
                // Inertia ~ mass * r², approximate r ≈ 1 for simplicity
                float rotStiffness = 8f;
                float rotDamping = 2.5f;
                Vector3 springTorque = axis.normalized * (ang * Mathf.Deg2Rad * rotStiffness * mass);
                Vector3 dampTorque = -_rb.angularVelocity * (rotDamping * mass);
                Vector3 totalTorque = springTorque + dampTorque;
                float maxTorque = 800f;
                if (totalTorque.sqrMagnitude > maxTorque * maxTorque)
                    totalTorque = totalTorque.normalized * maxTorque;
                _rb.AddTorque(totalTorque, ForceMode.Force);
            }
            // Gentle angular velocity decay (air friction), mass-independent
            float angDecay = 1f - Mathf.Clamp01(3f * dt);
            _rb.angularVelocity *= angDecay;

            // speed cap so flailing cannot whip the item through geometry
            Vector3 v = _rb.velocity;
            float sp = v.magnitude;
            if (sp > SpeedCap) _rb.velocity = v * (SpeedCap / sp);
        }

        // visual follows physics (after game scripts moved it — execution order 600)
        private void LateUpdate() { MirrorVisual(); }

        /// <summary>
        /// Copy the physical twin pose onto the visual. The last word of the frame
        /// is ours: this runs from LateUpdate at order 600 AND from the
        /// GoPointer.LateUpdate postfix (GoPointerPatches) — i.e. strictly after
        /// vanilla's own visual placement, still before render.
        /// </summary>
        public void MirrorVisual()
        {
            if (!_active || _rb == null || _item == null) return;
            try
            {
                var t = _item.transform;
                var tt = _rb.transform;
                Vector3 p = tt.position;
                if (!Finite(p)) return;    // never write garbage into the visual
                // if the eye is known, double-check the mirror target isn't absurd
                if (_cam != null)
                {
                    float d2 = (p - _cam.transform.position).sqrMagnitude;
                    if (d2 > 30f * 30f) return;
                }
                t.position = p;
                t.rotation = tt.rotation;
            }
            catch { /* ok */ }
        }

        // ---------------- throw ----------------

        /// <summary>
        /// Release with a shove along the camera direction.
        /// Returns estimated launch speed (0 when not holding).
        /// </summary>
        public float Throw(float speed)
        {
            if (!_active || _rb == null) return 0f;

            var anchorT2 = PointerTransform();
            if (anchorT2 == null && _cam == null) _cam = SharedCamera();
            Vector3 dir = anchorT2 != null
                ? anchorT2.forward
                : (_cam != null ? _cam.transform.forward : Vector3.forward);

            float mass = Mathf.Max(_rb.mass, 0.5f);
            // heavy items throw slower — tuned curve: 10 kg ≈ full speed, 60 kg ≈ 45%
            float massCurve = Mathf.Clamp(11f / Mathf.Sqrt(mass), 0.45f, 1.75f);
            Vector3 launch = (dir + Vector3.up * 0.18f).normalized * (speed * massCurve);

            try
            {
                _rb.useGravity = true;
                _rb.isKinematic = false;
                _rb.velocity = launch;
                _rb.angularVelocity = Vector3.zero;
            }
            catch { /* ok */ }

            float actual = launch.magnitude;
            Plugin.Log?.LogInfo("[Hold] THROW '" + name + "' speed=" + actual.ToString("0.0") +
                                " mass=" + mass.ToString("0.0"));

            _launched = true;      // keep dynamic + gravity in Deactivate

            // v4.4.0 split-world rule: the thrown body is OURS off boats (solid,
            // bounces, splashes) but must rejoin the vanilla drop flow while
            // crossing a boat's airspace, else it lands on the invisible
            // buoyancy-capsule dome above the hold instead of falling inside.
            // (Kill-switch: VanillaOnBoat=false = exact 4.3.4 behaviour.)
            if (Cfg.HoldVanillaOnBoat)
                BoatZoneGhost.Attach(_rb);

            Deactivate(true);
            return actual;
        }

        // ---------------- helpers ----------------

        private Vector3 EstimateExtents()
        {
            try
            {
                var rend = _item != null ? _item.GetComponentInChildren<Renderer>() : null;
                if (rend != null) return rend.bounds.extents;
            }
            catch { /* ok */ }
            return new Vector3(0.4f, 0.4f, 0.4f);
        }

        private static bool Finite(Vector3 v)
        {
            return !(float.IsNaN(v.x) || float.IsNaN(v.y) || float.IsNaN(v.z) ||
                     float.IsInfinity(v.x) || float.IsInfinity(v.y) || float.IsInfinity(v.z));
        }

        /// <summary>
        /// Cached gameplay camera (2 s revalidation) — the whole reason the hold
        /// used to flicker on and off was per-frame re-resolution picking
        /// different answers across frames.
        /// </summary>
        private static Camera SharedCamera()
        {
            if (_sharedCam != null && _sharedCam.isActiveAndEnabled &&
                Time.unscaledTime < _sharedCamT)
                return _sharedCam;

            var c = ResolvePlayerCamera();
            if (c != null && c.isActiveAndEnabled)
            {
                _sharedCam = c;
                _sharedCamT = Time.unscaledTime + 2f;
            }
            return _sharedCam != null && _sharedCam.isActiveAndEnabled ? _sharedCam : null;
        }

        /// <summary>
        /// The gameplay eye. Camera.main can point at a static/inactive camera in
        /// some builds — prefer whatever sits at the player mirror (note 43:
        /// Refs.observerMirror = player position), fall back to Camera.main,
        /// then to the single enabled camera in scene.
        /// </summary>
        internal static Camera ResolvePlayerCamera()
        {
            try
            {
                Transform player = null;
                if (Refs.observerMirror != null)
                    player = Refs.observerMirror.transform;

                Camera main = null;
                try { main = Camera.main; } catch { /* ok */ }

                if (player != null)
                {
                    // camera under the player rig
                    var under = player.GetComponentInChildren<Camera>(true);
                    if (under != null && under.isActiveAndEnabled) return under;

                    // main camera that actually sits at the player is trustworthy
                    if (main != null && main.isActiveAndEnabled &&
                        Vector3.Distance(main.transform.position, player.position) < 6f)
                        return main;

                    // otherwise: nearest enabled camera to the player
                    Camera best = null;
                    float bestD = float.MaxValue;
                    var all = Object.FindObjectsOfType<Camera>();
                    for (int i = 0; i < all.Length; i++)
                    {
                        var c = all[i];
                        if (c == null || !c.isActiveAndEnabled) continue;
                        float d = Vector3.Distance(c.transform.position, player.position);
                        if (d < bestD) { bestD = d; best = c; }
                    }
                    if (best != null && bestD < 60f) return best;
                }

                if (main != null && main.isActiveAndEnabled) return main;

                // last resort: the single enabled camera of the scene
                var cams = Object.FindObjectsOfType<Camera>();
                Camera one = null;
                int count = 0;
                for (int i = 0; i < cams.Length; i++)
                {
                    if (cams[i] != null && cams[i].isActiveAndEnabled) { one = cams[i]; count++; }
                }
                return count == 1 ? one : null;
            }
            catch
            {
                try { return Camera.main; } catch { return null; }
            }
        }
    }

    /// <summary>O(1) sets for Harmony hot paths: held items and their twins.</summary>
    internal static class HoldRegistry
    {
        private static readonly System.Collections.Generic.HashSet<int> Items =
            new System.Collections.Generic.HashSet<int>();
        private static readonly System.Collections.Generic.HashSet<int> Twins =
            new System.Collections.Generic.HashSet<int>();

        public static void Add(ShipItem item, Component twin)
        {
            if (item != null) Items.Add(item.GetInstanceID());
            if (twin != null) Twins.Add(twin.GetInstanceID());
        }

        public static void Remove(ShipItem item)
        {
            if (item == null) return;
            Items.Remove(item.GetInstanceID());
            ClearFresh(item);
            if (Twins.Count == 0) return;
            var twin = ItemAccess.GetTwin(item);
            if (twin != null) Twins.Remove(twin.GetInstanceID());
        }

        /// <summary>Cheap hot-path check by twin GameObject (no reflection).</summary>
        public static bool ContainsTwin(Component twin)
        {
            return twin != null && Twins.Count > 0 && Twins.Contains(twin.GetInstanceID());
        }

        public static bool Contains(ShipItem item)
        {
            return item != null && Items.Count > 0 && Items.Contains(item.GetInstanceID());
        }

        /// <summary>
        /// One check for the ItemRigidbody.FixedUpdate prefix: vanilla sync is
        /// skipped for twins of physics-held items AND for twins of FRESHLY picked
        /// items whose hold hasn't engaged yet (that pre-activation window is
        /// exactly where the stale-walkCol ~462 m reseat used to fire).
        /// </summary>
        public static bool SkipFor(Component twin)
        {
            if (twin == null) return false;
            if (ContainsTwin(twin)) return true;
            if (Fresh.Count == 0) return false;

            var item = ItemAccess.GetItem(twin);
            if (item == null) return false;

            float t0;
            if (!Fresh.TryGetValue(item.GetInstanceID(), out t0)) return false;

            // stale marks must hand the item back to vanilla:
            // dropped again, or the hold never engaged (blacklist/failure)
            if (item.held == null || UnityEngine.Time.unscaledTime - t0 > 2.5f)
            {
                Fresh.Remove(item.GetInstanceID());
                return false;
            }
            return true;
        }

        /// <summary>Same question asked by ITEM (ShipItem.ExtraFixedUpdate path —
        /// v4.3.1): hold active or just picked up.</summary>
        public static bool SkipForItem(ShipItem item)
        {
            if (item == null) return false;
            if (Contains(item)) return true;
            if (Fresh.Count == 0) return false;

            int id = item.GetInstanceID();
            float t0;
            if (!Fresh.TryGetValue(id, out t0)) return false;

            if (item.held == null || UnityEngine.Time.unscaledTime - t0 > 2.5f)
            {
                Fresh.Remove(id);
                return false;
            }
            return true;
        }

        // ---- v4.2.0: fresh-pickup marks (from the GoPointer.PickUpItem postfix) ----

        private static readonly System.Collections.Generic.Dictionary<int, float> Fresh =
            new System.Collections.Generic.Dictionary<int, float>(8);

        public static void MarkFreshPickup(ShipItem item)
        {
            if (item == null) return;
            if (IsBlacklisted(item)) return;   // blacklisted → vanilla owns the pickup fully
            if (Fresh.Count > 64) Fresh.Clear();
            Fresh[item.GetInstanceID()] = UnityEngine.Time.unscaledTime;
        }

        public static void ClearFresh(ShipItem item)
        {
            if (item != null) Fresh.Remove(item.GetInstanceID());
        }

        // ---- abort blacklist — stops the "aborted → retried 10×/s" flapping ----

        private static readonly System.Collections.Generic.Dictionary<int, float> Black =
            new System.Collections.Generic.Dictionary<int, float>(32);

        public static void Blacklist(ShipItem item, float seconds)
        {
            if (item == null) return;
            if (Black.Count > 512) Black.Clear();
            Black[item.GetInstanceID()] = UnityEngine.Time.unscaledTime + seconds;
        }

        public static bool IsBlacklisted(ShipItem item)
        {
            if (item == null) return false;
            float until;
            if (!Black.TryGetValue(item.GetInstanceID(), out until)) return false;
            if (UnityEngine.Time.unscaledTime >= until)
            {
                Black.Remove(item.GetInstanceID());
                return false;
            }
            return true;
        }

        public static int Count { get { return Items.Count + Fresh.Count; } }
    }
}
