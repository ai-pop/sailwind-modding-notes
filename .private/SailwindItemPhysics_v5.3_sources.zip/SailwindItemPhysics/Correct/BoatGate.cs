using UnityEngine;

namespace SailwindItemPhysics.Correct
{
    /// <summary>
    /// v4.4.0 — the user's split-world rule:
    ///   ON a boat  → 100% VANILLA physics (grip, colliders, seating, drop flow);
    ///   OFF a boat → OUR physics (hold spring, solid colliders, throws, float).
    ///
    /// GameState.currentBoat is the ground truth for "the player is embarked".
    /// The raw flag is stabilized with a short hysteresis (0.25 s) so a
    /// flickering embark trigger on a gangplank can't flap the hold on/off
    /// every fixed frame.
    /// </summary>
    internal static class BoatGate
    {
        private static bool _raw;
        private static bool _stable;
        private static float _rawSince = -10f;
        private static bool _everLogged;

        /// <summary>Stabilized flag — the one all consumers must use.</summary>
        public static bool PlayerOnBoat { get { return _stable; } }

        /// <summary>Unstabilized flag — for one-shot checks at the pickup moment.</summary>
        public static bool RawPlayerOnBoat { get { return _raw; } }

        /// <summary>Called every frame from CorrectManager.Update (O(1)).</summary>
        public static void Tick(float now)
        {
            bool raw;
            try { raw = GameState.currentBoat != null; }
            catch { raw = _raw; }   // transient failure — keep last known state

            if (raw != _raw) { _raw = raw; _rawSince = now; }

            if (_stable != raw && now - _rawSince >= 0.25f)
            {
                _stable = raw;
                if (!_everLogged || Cfg.Verbose)
                {
                    _everLogged = true;
                    Plugin.Log?.LogInfo("[Gate] player on boat = " + raw + " — " +
                                        (raw ? "VANILLA physics on board (hold/solids off)"
                                             : "our physics active (hold/solids on)"));
                }
            }
        }
    }

    /// <summary>
    /// Approximate boat airspace as ONE sphere per boat: the largest solid child
    /// collider's world bounds, inflated. Note 51: that largest collider is the
    /// buoyancy capsule towering above the deck — exactly the invisible dome
    /// solid thrown bodies kept landing on ("crate on the dome", 4.3.x).
    ///
    /// Used by BoatZoneGhost to hand FREE thrown bodies back to the vanilla
    /// drop flow (ghost through the capsule → EnterBoat seats them in the hold)
    /// only while they cross a boat's volume. Rescanned every few seconds —
    /// boats move slowly compared to the +2 m margin.
    /// (Player-side gating lives in BoatGate; this class knows nothing about it.)
    /// </summary>
    internal static class BoatZone
    {
        private sealed class B
        {
            public Vector3 C;
            public float R;
        }

        private static readonly System.Collections.Generic.List<B> Boats =
            new System.Collections.Generic.List<B>(8);

        private static float _nextScan;

        private const float Margin = 2.0f;    // covers drift between rescans + fuzzy edges
        private const float RescanEvery = 3f;

        /// <summary>Is the point inside ANY boat's (inflated) airspace?</summary>
        public static bool Contains(Vector3 pos)
        {
            EnsureFresh();
            for (int i = 0; i < Boats.Count; i++)
            {
                var b = Boats[i];
                float r = b.R + Margin;
                if ((pos - b.C).sqrMagnitude <= r * r) return true;
            }
            return false;
        }

        private static void EnsureFresh()
        {
            if (Time.unscaledTime < _nextScan) return;
            _nextScan = Time.unscaledTime + RescanEvery;
            Boats.Clear();
            try
            {
                var gos = GameObject.FindGameObjectsWithTag("Boat");
                if (gos == null) return;
                for (int i = 0; i < gos.Length; i++)
                {
                    var g = gos[i];
                    if (g == null) continue;

                    var cols = g.GetComponentsInChildren<Collider>(true);
                    if (cols == null || cols.Length == 0) continue;

                    // pick the single biggest SOLID collider — the buoyancy capsule
                    Collider big = null;
                    float bestV = -1f;
                    for (int k = 0; k < cols.Length; k++)
                    {
                        var c = cols[k];
                        if (c == null || c.isTrigger) continue;
                        var e = c.bounds.extents;
                        float v = e.x * e.y * e.z;
                        if (v > bestV) { bestV = v; big = c; }
                    }
                    if (big == null) continue;

                    var bd = big.bounds;
                    Boats.Add(new B
                    {
                        C = bd.center,
                        R = Mathf.Max(1.5f, bd.extents.magnitude * 1.05f)
                    });
                }
            }
            catch { /* tag undefined on some builds — zone stays empty, ghosting off */ }
        }
    }
}
