using UnityEngine;

namespace SailwindItemPhysics.Api
{
    /// <summary>
    /// v5.1.0 — how the item should carry itself while afloat
    /// (user design: "a crate maybe rights itself, but a barrel would lie
    /// down and roll with the waves"). Auto = no opinion; the DB auto-
    /// heuristic fills it at build time, the driver treats Auto as Upright.
    /// </summary>
    public enum FloatPosture
    {
        /// <summary>No opinion — auto heuristic / Upright default decides.</summary>
        Auto = 0,
        /// <summary>Stands up, leaning with the swells (crates, boxes, furniture).</summary>
        Upright = 1,
        /// <summary>Lies on its side with the round axis horizontal and rolls
        /// with the waves (barrels, kegs, drums — tall near-cylinders).</summary>
        Lying = 2,
        /// <summary>No self-righting at all — tumbles honestly (debris).</summary>
        Free = 3
    }

    /// <summary>
    /// v5.0.0 — one row of the mod's OWN item database: the physical identity
    /// of a game item prefab. Layer 0 = live auto-extract from
    /// PrefabsDirectory at world load (always matches the running game —
    /// note 61: this data exists ONLY at runtime). Layer 1 = curated
    /// overrides via <see cref="ItemPhysicsAPI.RegisterItemOverride"/> or the
    /// optional itemdb-overrides csv next to the BepInEx config.
    ///
    /// The DB never hardcodes behaviour per name: the surface driver still
    /// MEASURES every spawned body's colliders; the spec layer adds identity
    /// (what it is, what vanilla thinks of it) and the few hard vetoes a
    /// curator can express.
    /// </summary>
    public sealed class ItemSpec
    {
        /// <summary>SaveablePrefab.prefabIndex (== PrefabsDirectory order).</summary>
        public int PrefabIndex = -1;

        /// <summary>item.name without the "(Clone)" suffix.</summary>
        public string Name = "";

        /// <summary>Runtime class: ShipItemCrate / ShipItemBottle / ShipItemFood / …</summary>
        public string ClassName = "";

        /// <summary>Shell mass (ShipItem.mass), kg.</summary>
        public float Mass;

        /// <summary>Sealed-pack contents estimate at extract time, kg
        /// (amount × containedPrefab.mass on crates; 0 for loose items).</summary>
        public float ContentsEstimate;

        /// <summary>ShipItem.floaterHeight as shipped (vanilla's broken-by-
        /// design "target height above water" — recorded for reference only,
        /// our sim never uses it).</summary>
        public float FloaterHeight = 1.6f;

        /// <summary>ShipItem.wallAttachment (can wall-snap on drop).</summary>
        public bool WallAttachment;

        /// <summary>TransactionCategory / cargo label as string.</summary>
        public string Category = "";

        /// <summary>Renderer-bounds size of the prefab at extract (m).
        /// The driver re-measures live colliders per body — this is a
        /// fallback and a calibration artifact, not the draft source.</summary>
        public Vector3 Size;

        // ---------------- curated knobs (override layer) ----------------

        /// <summary>How much of the AABB is solid matter, 0..1 (wheel/cylinder
        /// ≈ 0.78, box = 1). 0 = "no opinion" → treated as 1.</summary>
        public float FillFactor;

        /// <summary>Hard veto: true = never sinks (awash at worst), false =
        /// always sinks regardless of computed density. null = physics
        /// decides (default).</summary>
        public bool? ForceFloats;

        /// <summary>v5.1.0: preferred carry on the surface (upright crate vs
        /// rolling barrel vs free tumble). Auto = the DB heuristic decides
        /// (name/bounds: tall near-cylinders → Lying, the rest → Upright).</summary>
        public FloatPosture Posture = FloatPosture.Auto;

        /// <summary>Where this row came from: auto | csv | api.</summary>
        public string Source = "auto";

        public override string ToString()
        {
            return "#" + PrefabIndex + " '" + Name + "' (" + ClassName + ", " +
                   Mass.ToString("0.0#") + " kg, " + Source + ")";
        }
    }
}
