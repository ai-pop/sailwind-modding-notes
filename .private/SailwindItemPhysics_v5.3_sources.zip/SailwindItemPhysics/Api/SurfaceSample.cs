using UnityEngine;

namespace SailwindItemPhysics.Api
{
    /// <summary>Which provider produced the surface height (diagnostics/fallback visibility).</summary>
    public enum OceanSourceKind
    {
        None = 0,
        /// <summary>Game Ocean (Crest fork): GetWaterHeightAtLocation2 — exact waves.</summary>
        GameOcean = 1,
        /// <summary>Game wrapper OceanHeight + SampleHeightHelper.</summary>
        OceanHeightHelper = 2,
        /// <summary>UnderwaterEffect.cameraWaterHeight — what the player swim system uses.</summary>
        UnderwaterEffect = 3,
        /// <summary>Hull of the player boat (coarse flat estimate).</summary>
        BoatLevel = 4,
        /// <summary>Manual override from config.</summary>
        Manual = 5
    }

    /// <summary>
    /// One smoothed water-surface reading in scene coordinates.
    /// </summary>
    public struct SurfaceSample
    {
        /// <summary>False when nothing is known about the surface at all.</summary>
        public bool Valid;

        /// <summary>True when the height is an approximation (not the exact wave field).</summary>
        public bool IsEstimate;

        public OceanSourceKind Source;

        /// <summary>Surface height Y in scene space (smoothed).</summary>
        public float Y;

        /// <summary>Estimated vertical velocity of the surface (m/s, clamped, smoothed).</summary>
        public float VelY;

        /// <summary>Approximate surface normal (up when unknown).</summary>
        public Vector3 Normal;

        public static SurfaceSample Invalid()
        {
            return new SurfaceSample { Valid = false, Source = OceanSourceKind.None, Normal = Vector3.up };
        }
    }
}
