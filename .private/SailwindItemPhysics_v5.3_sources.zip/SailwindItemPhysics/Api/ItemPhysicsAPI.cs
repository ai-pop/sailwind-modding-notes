using UnityEngine;

namespace SailwindItemPhysics.Api
{
    /// <summary>
    /// Back-compat facade from the v2 README ("ItemPhysicsAPI.Service.Register").
    /// Real implementation now; simply forwards to <see cref="SurfaceBodyAPI"/>.
    /// New code should use <see cref="SurfaceBodyAPI"/> directly.
    /// </summary>
    public static class ItemPhysicsAPI
    {
        public static bool Available
        {
            get { return SurfaceBodyAPI.Available; }
        }

        public static string Version
        {
            get { return SurfaceBodyAPI.Available ? SurfaceBodyAPI.Service.Version : "unavailable"; }
        }

        /// <summary>Alias for Attach(profile=null).</summary>
        public static bool Register(ShipItem item)
        {
            return SurfaceBodyAPI.Available && SurfaceBodyAPI.Service.Attach(item, null);
        }

        /// <summary>Alias for Attach(profile).</summary>
        public static bool Register(ShipItem item, FloatProfile profile)
        {
            return SurfaceBodyAPI.Available && SurfaceBodyAPI.Service.Attach(item, profile);
        }

        /// <summary>Alias for Detach.</summary>
        public static void Unregister(ShipItem item)
        {
            if (SurfaceBodyAPI.Available) SurfaceBodyAPI.Service.Detach(item);
        }

        /// <summary>Alias for IsAttached.</summary>
        public static bool IsRegistered(ShipItem item)
        {
            return SurfaceBodyAPI.Available && SurfaceBodyAPI.Service.IsAttached(item);
        }

        public static bool TryGetSurfaceY(Vector3 scenePosition, out float surfaceY)
        {
            surfaceY = scenePosition.y;
            return SurfaceBodyAPI.Available &&
                   SurfaceBodyAPI.Service.TryGetSurfaceY(scenePosition, out surfaceY);
        }

        // ---------------- v5.0.0: the item database ----------------

        /// <summary>How many item specs the database holds (0 until the first
        /// world load finishes the live extract from PrefabsDirectory).</summary>
        public static int ItemSpecCount
        {
            get { return SailwindItemPhysics.Sim.ItemDb.Count; }
        }

        /// <summary>Physical identity of a prefab (mass, class, sealed
        /// contents estimate, bounds, curated flags) by PrefabsDirectory
        /// index. False only before the DB is built.</summary>
        public static bool TryGetItemSpec(int prefabIndex, out ItemSpec spec)
        {
            return SailwindItemPhysics.Sim.ItemDb.TryGetByIndex(prefabIndex, out spec);
        }

        /// <summary>Resolve a live item to its spec (SaveablePrefab index
        /// first, name fallback for odd spawns).</summary>
        public static bool TryGetItemSpec(ShipItem item, out ItemSpec spec)
        {
            return SailwindItemPhysics.Sim.ItemDb.TryResolve(item, out spec);
        }

        /// <summary>Curate physics flags for a prefab (FillFactor,
        /// ForceFloats). Identity fields are taken from the extracted row —
        /// you override behaviour, not identity. Anchor by PrefabIndex, or by
        /// Name when the index is unknown.</summary>
        public static void RegisterItemOverride(ItemSpec spec)
        {
            SailwindItemPhysics.Sim.ItemDb.RegisterOverride(spec);
        }
    }
}
