using UnityEngine;

namespace SailwindItemPhysics.Api
{
    /// <summary>
    /// Which physical-correctness module owns an item.
    /// </summary>
    public enum PhysicsModuleKind
    {
        /// <summary>
        /// "Physically correct on activation" — item is vanilla until its trigger fires.
        /// Once activated, the item becomes (and by default stays) physically correct.
        /// </summary>
        Triggered = 0,

        /// <summary>
        /// "Physically correct by default" — no trigger needed, correct from the start.
        /// </summary>
        Always = 1
    }

    /// <summary>
    /// Activation condition for <see cref="PhysicsModuleKind.Triggered"/>.
    /// Default for every item in the game: <see cref="Grabbed"/> — the first time
    /// the player picks an item up, it becomes physically correct.
    /// </summary>
    public enum PhysicsTrigger
    {
        /// <summary>Activates while/when held in hands (sticky afterwards).</summary>
        Grabbed = 0,

        /// <summary>Activates when free in the open world (not on boat / not in box).</summary>
        InWorld = 1,

        /// <summary>Activates when touching water.</summary>
        Submerged = 2
    }

    /// <summary>
    /// Priority ladder for assignments. Higher wins; ties are last-writer-wins.
    /// Everything this mod ships out of the box uses <see cref="Builtin"/> (0) —
    /// an external mod that sets anything higher always takes over.
    /// </summary>
    public static class PhysicsPriority
    {
        /// <summary>Built-in default ("Triggered + Grabbed" for every item).</summary>
        public const int Builtin = 0;

        /// <summary>Intended baseline for external mods.</summary>
        public const int External = 100;

        /// <summary>For mods that must win against other mods.</summary>
        public const int Override = 1000;
    }

    /// <summary>
    /// Full assignment record of one item (module + trigger + priority + source).
    /// Absence of a record == built-in default: Triggered/Grabbed/Builtin.
    /// </summary>
    public struct ItemPhysicsAssignment
    {
        public PhysicsModuleKind Module;
        public PhysicsTrigger Trigger;

        /// <summary>Higher wins. See <see cref="PhysicsPriority"/>.</summary>
        public int Priority;

        /// <summary>Who set this ("builtin", your mod guid, …).</summary>
        public string Source;

        /// <summary>
        /// Sticky = stay physically correct after the trigger releases
        /// (e.g. after the first grab the item keeps swimming/holding physically forever).
        /// </summary>
        public bool Sticky;

        /// <summary>True when this is only the implicit built-in default (no explicit record).</summary>
        public bool IsDefault;

        public static ItemPhysicsAssignment Default()
        {
            return new ItemPhysicsAssignment
            {
                Module = PhysicsModuleKind.Triggered,
                Trigger = PhysicsTrigger.Grabbed,
                Priority = PhysicsPriority.Builtin,
                Source = "builtin",
                Sticky = true,
                IsDefault = true
            };
        }
    }

    /// <summary>
    /// Snapshot of the correctness layer for one item (F10 overlay / mods).
    /// </summary>
    public struct ItemCorrectnessInfo
    {
        public ShipItem Item;
        public ItemPhysicsAssignment Assignment;
        /// <summary>Item has become physically correct (module fired).</summary>
        public bool IsCorrected;
        /// <summary>Physics hold is controlling it right now.</summary>
        public bool HoldActive;
        /// <summary>Surface float is attached right now.</summary>
        public bool FloatAttached;
        /// <summary>Save identity known (SaveablePrefab.instanceId) → state persists.</summary>
        public bool HasSaveId;
        public int SaveId;
    }
}
