using System;
using System.Collections.Generic;
using UnityEngine;

namespace SailwindItemPhysics.Api
{
    /// <summary>Lifecycle state of a simulated body.</summary>
    public enum SurfaceBodyState
    {
        /// <summary>Waiting for the ItemRigidbody twin / rigidbody.</summary>
        Booting = 0,
        /// <summary>Full simulation on live ocean data.</summary>
        Floating = 1,
        /// <summary>Simulation on an estimated surface (fallback provider).</summary>
        Estimated = 2,
        /// <summary>Sim paused: held / on boat / in box / nailed / not sold.</summary>
        Suspended = 3,
        /// <summary>Profile.CanSink and fully drowned.</summary>
        Sunk = 4
    }

    /// <summary>Point-in-time snapshot of a simulated body.</summary>
    public struct SurfaceBodyInfo
    {
        public ShipItem Item;
        public SurfaceBodyState State;
        /// <summary>Why suspended: "held" / "onBoat" / "box" / "nailed" / "notSold" / "boot" / "".</summary>
        public string Reason;
        public Vector3 Position;
        public Vector3 Velocity;
        /// <summary>Surface height used by the sim right now.</summary>
        public float SurfaceY;
        /// <summary>EMA 0..1 of wet blob fraction.</summary>
        public float Wetness;
        /// <summary>Current center depth under the surface (may be negative).</summary>
        public float Submersion;
        public float Mass;
        /// <summary>True when the surface source is a fallback estimate.</summary>
        public bool OceanEstimate;
        public float DistanceToPlayer;
    }

    /// <summary>
    /// Public service for consumer mods.
    /// Sailwind has no volumetric water — boat-class surface forces on item twins.
    /// v3 adds body introspection, events, impulses, ocean diagnostics.
    /// All v2 members unchanged (binary compatible).
    /// </summary>
    public interface ISurfaceBodyService
    {
        // ---------- v2 surface (unchanged) ----------

        string Version { get; }

        int ActiveCount { get; }

        /// <summary>
        /// Begin boat-lite surface simulation for a ShipItem.
        /// Safe to call repeatedly; updates profile. Ensures sold=true.
        /// </summary>
        bool Attach(ShipItem item, FloatProfile profile = null);

        /// <summary>Stop simulation and remove runtime driver.</summary>
        void Detach(ShipItem item);

        bool IsAttached(ShipItem item);

        /// <summary>
        /// Sample water surface Y in scene coordinates (gate + choppy).
        /// Always tries to return a usable estimate.
        /// </summary>
        bool TryGetSurfaceY(Vector3 scenePosition, out float surfaceY);

        // ---------- v3 additions ----------

        /// <summary>Replace the profile of an attached body (validated + applied live).</summary>
        bool SetProfile(ShipItem item, FloatProfile profile);

        /// <summary>Snapshot of one body; false when not attached.</summary>
        bool TryGetInfo(ShipItem item, out SurfaceBodyInfo info);

        /// <summary>One instant acceleration kick (m/s) applied on the next sim step.</summary>
        void Pulse(ShipItem item, Vector3 acceleration);

        /// <summary>Copy of currently attached items (null-purged).</summary>
        List<ShipItem> GetAttachedSnapshot();

        /// <summary>Raised once when a body finished booting and is registered.</summary>
        event Action<ShipItem> BodyAttached;

        /// <summary>Raised when a body leaves the simulation (detach/destroy).</summary>
        event Action<ShipItem> BodyDetached;

        /// <summary>Raised when a dry body hits water fast enough (see FloatProfile.SplashMinImpactVel).</summary>
        event Action<ShipItem> BodySplashed;

        /// <summary>Raised on every state transition (Floating/Estimated/Suspended/...).</summary>
        event Action<ShipItem, SurfaceBodyState> BodyStateChanged;

        /// <summary>Smoothed surface sample incl. source + heave velocity.</summary>
        bool TryGetSample(Vector3 scenePosition, out SurfaceSample sample);

        /// <summary>Approximate surface normal via stencil difference.</summary>
        bool TryGetNormal(Vector3 scenePosition, float stencil, out Vector3 normal);

        /// <summary>Human-readable name of the active ocean provider.</summary>
        string OceanSourceName { get; }

        /// <summary>True when the exact game ocean is bound and answering.</summary>
        bool OceanIsLive { get; }

        /// <summary>Rough global mean sea level (EMA of recent samples), scene space.</summary>
        float SeaLevelNow { get; }

        /// <summary>Drop all provider bindings and re-probe (e.g. after scene change).</summary>
        void ForceOceanRebind();

        // ---------- v4: correctness modules & priorities ----------

        /// <summary>Effective assignment of an item (built-in default when nothing set).</summary>
        ItemPhysicsAssignment GetAssignment(ShipItem item);

        /// <summary>
        /// Set module/trigger with priority. Wins when Priority >= current priority
        /// (ties: last writer wins). Built-in stuff uses 0 — mods should use 100+.
        /// Returns the effective assignment after resolution.
        /// </summary>
        ItemPhysicsAssignment SetAssignment(ShipItem item, ItemPhysicsAssignment assignment);

        /// <summary>Remove explicit record if <paramref name="priority"/> out-ranks it.</summary>
        bool ClearAssignment(ShipItem item, int priority);

        /// <summary>Item has become physically correct (module fired / Always).</summary>
        bool IsPhysicallyCorrect(ShipItem item);

        /// <summary>Full correctness snapshot (assignment, flags, hold/float state).</summary>
        bool TryGetCorrectnessInfo(ShipItem item, out ItemCorrectnessInfo info);

        /// <summary>How many items the correctness layer currently tracks.</summary>
        int TrackedItemCount { get; }

        // ---------- v4: physics hold ("gravity gun") ----------

        bool IsHoldActive(ShipItem item);

        /// <summary>Item currently controlled by the physics hold (null when none).</summary>
        ShipItem CurrentHeldItem { get; }

        /// <summary>Launch the held item along the camera; returns launch speed, 0 = nothing held.</summary>
        float ThrowHeld(float speed);

        // ---------- v4: splash ----------

        /// <summary>Like <see cref="BodySplashed"/> but carries impact speed + world position.</summary>
        event Action<ShipItem, float, Vector3> BodySplashedEx;

        /// <summary>Spawn a splash visual manually (strength ≈ impact m/s).</summary>
        void SpawnSplash(Vector3 scenePosition, float strength);
    }

    /// <summary>
    /// Static entry point. Null if plugin not loaded.
    /// </summary>
    public static class SurfaceBodyAPI
    {
        public static ISurfaceBodyService Service { get; internal set; }

        public static bool Available
        {
            get { return Service != null; }
        }
    }
}
