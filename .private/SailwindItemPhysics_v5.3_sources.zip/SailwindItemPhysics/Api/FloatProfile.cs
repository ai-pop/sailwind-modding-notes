using System.Collections.Generic;
using UnityEngine;

namespace SailwindItemPhysics.Api
{
    /// <summary>
    /// v5.3 physics-first buoyancy profile. Removed: all Acceleration-mode artifacts
    /// (BuoyancyAccel, VerticalDamp, HeaveCoupling, FreeboardAssist, LiftCapG, WetUpCap,
    /// SpinDamp, MaxTiltDeg, FullSubmergeDepth, Freeboard, RecoveryDepth, RecoveryAccel).
    /// Added: FillFactor — controls displaced water volume directly.
    /// All forces applied as ForceMode.Force — mass works natively through Unity.
    /// </summary>
    public sealed class FloatProfile
    {
        /// <summary>Preset/display name.</summary>
        public string Name = "crate";

        // ---- core hull shape ----

        public Vector3 HalfExtents = new Vector3(0.48f, 0.38f, 0.58f);
        public int RingSamples = 4;

        /// <summary>0..1 how much of the bounding-box is solid matter.
        /// Wooden crate ≈ 0.7, barrel ≈ 0.6, solid log ≈ 0.95, empty bottle ≈ 0.15.</summary>
        public float FillFactor = 0.7f;

        // ---- drag (ForceMode.Force — mass-aware via Unity) ----

        public float WaterLinearDrag = 3.0f;
        public float WaterAngularDrag = 4.0f;

        // ---- attitude ----

        public float ComDown = 0.14f;
        public float AlignTorque = 3.0f;
        public float SlopeSlide = 2.0f;

        // ---- environment ----

        public float WindAccel = 0.25f;

        // ---- limits ----

        public bool CanSink = false;
        public float SinkStartDepth = 2.2f;
        public float SplashMinImpactVel = 1.4f;

        // ---- LOD ----

        public int FixedStride = 1;
        public float NearDistance = 80f;
        public float MidDistance = 300f;
        public int MidStride = 2;
        public int FarStride = 4;

        // ============ API compat stubs (no-op, kept for binary compat) ============

        public float BuoyancyAccel { get; set; }
        public float VerticalDamp { get; set; }
        public float HeaveCoupling { get; set; }
        public float FullSubmergeDepth { get; set; }
        public float Freeboard { get; set; }
        public float RecoveryDepth { get; set; }
        public float RecoveryAccel { get; set; }
        public float MassMin { get; set; }
        public float MassMax { get; set; }
        public float MassOverride { get; set; }
        public float NeutralBuoyancyMass { get; set; }
        public bool UseBlobForces { get { return true; } set { } }
        public float FreeboardAssist { get; set; }
        public float BobResponsiveness { get; set; }
        public float SpinDamp { get; set; }
        public float MaxTiltDeg { get; set; }
        public float MaxWaterSpeed { get; set; }
        public float SinkAccel { get; set; }

        // ============ methods ============

        public FloatProfile Clone()
        {
            return (FloatProfile)MemberwiseClone();
        }

        public FloatProfile Validate()
        {
            RingSamples = Mathf.Clamp(RingSamples, 3, 8);
            FillFactor = Mathf.Clamp(FillFactor, 0.05f, 1.5f);
            WaterLinearDrag = Mathf.Clamp(WaterLinearDrag, 0f, 20f);
            WaterAngularDrag = Mathf.Clamp(WaterAngularDrag, 0f, 20f);
            ComDown = Mathf.Clamp(ComDown, -0.5f, 0.5f);
            AlignTorque = Mathf.Clamp(AlignTorque, 0f, 15f);
            SlopeSlide = Mathf.Clamp(SlopeSlide, 0f, 8f);
            WindAccel = Mathf.Clamp(WindAccel, 0f, 3f);
            FixedStride = Mathf.Clamp(FixedStride, 1, 8);
            NearDistance = Mathf.Clamp(NearDistance, 10f, 600f);
            MidDistance = Mathf.Clamp(MidDistance, NearDistance + 5f, 1200f);
            MidStride = Mathf.Clamp(MidStride, 1, 8);
            FarStride = Mathf.Clamp(FarStride, 1, 12);
            if (string.IsNullOrEmpty(Name)) Name = "custom";
            return this;
        }

        // ============ presets ============

        public static FloatProfile Crate()
        {
            return new FloatProfile { Name = "crate", FillFactor = 0.7f };
        }

        public static FloatProfile Barrel()
        {
            return new FloatProfile
            {
                Name = "barrel",
                HalfExtents = new Vector3(0.38f, 0.55f, 0.38f),
                RingSamples = 5,
                FillFactor = 0.55f,
                ComDown = 0.18f
            };
        }

        public static FloatProfile Debris()
        {
            return new FloatProfile
            {
                Name = "debris",
                HalfExtents = new Vector3(0.22f, 0.18f, 0.28f),
                RingSamples = 3,
                FillFactor = 0.9f,
                WindAccel = 0.7f,
                WaterLinearDrag = 4.5f
            };
        }

        public static FloatProfile HeavyCrate()
        {
            return new FloatProfile
            {
                Name = "heavy",
                HalfExtents = new Vector3(0.5f, 0.42f, 0.6f),
                RingSamples = 5,
                FillFactor = 0.85f,
                ComDown = 0.2f,
                CanSink = true,
                SinkStartDepth = 2.6f,
                WindAccel = 0.12f
            };
        }

        public static FloatProfile Bottle()
        {
            return new FloatProfile
            {
                Name = "bottle",
                HalfExtents = new Vector3(0.12f, 0.16f, 0.12f),
                RingSamples = 3,
                FillFactor = 0.15f,
                WindAccel = 1.2f,
                WaterLinearDrag = 4.5f
            };
        }

        public static FloatProfile Log()
        {
            return new FloatProfile
            {
                Name = "log",
                HalfExtents = new Vector3(0.18f, 0.16f, 1.05f),
                RingSamples = 6,
                FillFactor = 0.92f,
                AlignTorque = 5f,
                SlopeSlide = 3.5f,
                WaterAngularDrag = 6f,
                ComDown = 0.05f
            };
        }

        public static List<string> PresetNames()
        {
            return new List<string> { "crate", "barrel", "debris", "heavy", "bottle", "log" };
        }

        public static FloatProfile ByName(string preset)
        {
            if (string.IsNullOrEmpty(preset)) return null;
            switch (preset.Trim().ToLowerInvariant())
            {
                case "crate": return Crate();
                case "barrel": return Barrel();
                case "debris": return Debris();
                case "heavy": case "heavycrate": return HeavyCrate();
                case "bottle": return Bottle();
                case "log": case "timber": return Log();
                default: return null;
            }
        }
    }
}
