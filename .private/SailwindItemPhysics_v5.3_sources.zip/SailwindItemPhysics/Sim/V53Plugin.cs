using BepInEx;
using HarmonyLib;
using UnityEngine;

namespace SailwindItemPhysics.Sim
{
    /// <summary>
    /// v5.3 — Standalone BepInEx plugin that patches the compiled SurfaceBodyDriver
    /// at runtime with ForceMode.Force physics. Loads AFTER SailwindItemPhysics.
    /// </summary>
    [BepInPlugin("com.sailwind.itemphysics.v53", "SailwindItemPhysics v5.3 Driver", "5.3.0")]
    [BepInDependency("com.sailwind.itemphysics", BepInDependency.DependencyFlags.HardDependency)]
    public class V53Plugin : BaseUnityPlugin
    {
        private Harmony _harmony;

        private void Awake()
        {
            _harmony = new Harmony("com.sailwind.itemphysics.v53");
            SurfaceBodyDriverPatch.Apply(_harmony);
            Logger.LogInfo("[V53] SurfaceBodyDriver patch applied — ForceMode.Force physics ACTIVE");
        }

        private void OnDestroy()
        {
            _harmony?.UnpatchSelf();
        }
    }
}
