using System;
using System.Collections.Generic;
using HarmonyLib;
using SailwindItemPhysics.Api;
using SailwindItemPhysics.Bridge;
using UnityEngine;

namespace SailwindItemPhysics.Sim
{
    internal static class SurfaceBodyDriverPatch
    {
        private static readonly Dictionary<int, V53State> _states = new Dictionary<int, V53State>();

        public static void Apply(Harmony harmony)
        {
            var t = AccessTools.TypeByName("SailwindItemPhysics.Sim.SurfaceBodyDriver");
            if (t == null) { Plugin.Log?.LogWarning("[V53] driver type not found"); return; }

            var awake = AccessTools.Method(t, "Awake");
            var start = AccessTools.Method(t, "Start");
            var fixedUp = AccessTools.Method(t, "FixedUpdate");
            var onEnable = AccessTools.Method(t, "OnEnable");
            int patched = 0;

            if (awake != null) { harmony.Patch(awake, prefix: new HarmonyMethod(typeof(SurfaceBodyDriverPatch), nameof(PreAwake))); patched++; }
            if (start != null) { harmony.Patch(start, prefix: new HarmonyMethod(typeof(SurfaceBodyDriverPatch), nameof(PreStart))); patched++; }
            if (fixedUp != null) { harmony.Patch(fixedUp, prefix: new HarmonyMethod(typeof(SurfaceBodyDriverPatch), nameof(PreFixedUpdate))); patched++; }
            if (onEnable != null) { harmony.Patch(onEnable, prefix: new HarmonyMethod(typeof(SurfaceBodyDriverPatch), nameof(PreEnable))); patched++; }

            Plugin.Log?.LogInfo($"[V53] {patched}/4 patches — ForceMode.Force ACTIVE");
        }

        private static V53State Get(GameObject go)
        {
            int id = go.GetInstanceID();
            if (!_states.TryGetValue(id, out var st)) { st = new V53State(); _states[id] = st; }
            return st;
        }

        private static bool PreAwake(object __instance)
        {
            var c = __instance as Component;
            if (c == null) return true;
            var st = Get(c.gameObject);
            st.Active = false;
            return false;
        }

        private static bool PreEnable(object __instance) { return false; }

        private static bool PreStart(object __instance)
        {
            var c = __instance as Component;
            if (c == null) return true;
            var st = Get(c.gameObject);
            if (st.Active) return false;

            st.Item = ItemAccess.GetItem(c);
            if (st.Item == null) return false;

            st.Rb = ItemAccess.GetRigidbody(st.Item);
            st.Twin = ItemAccess.GetTwin(st.Item);
            if (st.Rb == null || st.Twin == null) return false;

            st.Profile = AutoProfile(st.Item);
            st.Mass = st.Rb.mass = ItemAccess.EffectiveMass(st.Item, st.Rb.mass);
            MeasureBounds(st);
            BuildBlobs(st);
            st.Active = true;

            if (Cfg.Verbose)
                Plugin.Log?.LogInfo($"[V53] '{st.Item.name}' mass={st.Mass:F1} fill={st.Profile.FillFactor:F2} vol={st.DisplacedVol:F3}");
            return false;
        }

        private static bool PreFixedUpdate(object __instance)
        {
            var c = __instance as Component;
            if (c == null) return true;
            var st = Get(c.gameObject);
            if (!st.Active || st.Rb == null) return false;

            st.FrameCount++;
            int stride = LODStride(st);
            if (st.FrameCount % stride != 0) return false;

            if ((st.FrameCount % 10) == 0)
            {
                float m = ItemAccess.EffectiveMass(st.Item, st.Mass);
                if (Mathf.Abs(m - st.Mass) > 0.05f) st.Mass = st.Rb.mass = m;
            }

            st.DistToPlayer = DistToPlayer(st);

            if (st.DistToPlayer > Cfg.FreezeDistance)
            {
                if (!st.Frozen) { st.Rb.velocity = Vector3.zero; st.Rb.angularVelocity = Vector3.zero; st.Rb.Sleep(); st.Frozen = true; }
                return false;
            }
            if (st.Frozen && st.DistToPlayer < Cfg.WakeDistance) { st.Rb.WakeUp(); st.Frozen = false; }

            SampleSurface(st);
            Buoyancy(st);
            Drag(st);
            Posture(st);
            Wind(st);
            return false;
        }

        static void MeasureBounds(V53State st)
        {
            st.BoundsSize = Vector3.one * 0.3f;
            try { var col = st.Twin?.GetComponent<Collider>(); if (col) st.BoundsSize = col.bounds.size; }
            catch { }
            float vol = st.BoundsSize.x * st.BoundsSize.y * st.BoundsSize.z;
            st.DisplacedVol = vol * st.Profile.FillFactor;
            if (st.Profile.HalfExtents.magnitude < 0.01f) st.Profile.HalfExtents = st.BoundsSize * 0.5f;
        }

        static void BuildBlobs(V53State st)
        {
            int n = st.Profile.RingSamples;
            var pl = new List<Vector3>(); var al = new List<float>();
            Vector3 he = st.Profile.HalfExtents;
            pl.Add(Vector3.zero); al.Add(he.x * he.z);
            float step = Mathf.PI * 2f / n;
            for (int i = 0; i < n; i++)
            {
                float a = step * i;
                pl.Add(new Vector3(Mathf.Cos(a) * he.x, 0f, Mathf.Sin(a) * he.z));
                al.Add((he.x + he.z) * 0.5f * 0.4f / n);
            }
            st.BlobPositions = pl.ToArray(); st.BlobAreas = al.ToArray();
        }

        static FloatProfile AutoProfile(ShipItem item)
        {
            var p = FloatProfile.Crate();
            try
            {
                string t = item?.GetType().Name ?? "";
                string n = item?.name ?? "";
                if (t.Contains("Bottle")) p = FloatProfile.Bottle();
                else if (n.IndexOf("barrel", StringComparison.OrdinalIgnoreCase) >= 0) p = FloatProfile.Barrel();
                else if (item.mass > 30f) p = FloatProfile.HeavyCrate();
            }
            catch { }
            return p.Validate();
        }

        static int LODStride(V53State st)
        {
            if (st.DistToPlayer < st.Profile.NearDistance) return st.Profile.FixedStride;
            if (st.DistToPlayer < st.Profile.MidDistance) return st.Profile.MidStride;
            return st.Profile.FarStride;
        }

        static float DistToPlayer(V53State st)
        {
            try { if (Camera.main && st.Twin) return Vector3.Distance(st.Twin.transform.position, Camera.main.transform.position); }
            catch { }
            return 9999f;
        }

        static void SampleSurface(V53State st)
        {
            float rawY = st.Twin ? st.Twin.transform.position.y : 0f;
            try { var api = SurfaceBodyAPI.Service; if (api != null && st.Twin) { float sy; if (api.TryGetSurfaceY(st.Twin.transform.position, out sy)) rawY = sy; } }
            catch { }
            float rate = Cfg.WaveSurfaceSmoothSeconds > 0.001f ? 1f / Cfg.WaveSurfaceSmoothSeconds : 20f;
            float dt = Mathf.Max(Time.fixedDeltaTime * LODStride(st), 0.001f);
            float a = 1f - Mathf.Exp(-rate * dt);
            float prev = st.SmoothSurfaceY;
            st.SmoothSurfaceY = Mathf.Lerp(st.SmoothSurfaceY, rawY, a);
            st.SmoothSurfaceVelY = (st.SmoothSurfaceY - prev) / dt;
            if (Cfg.WaveNormalSmoothSeconds > 0.001f)
            {
                float na = 1f - Mathf.Exp(-(1f / Cfg.WaveNormalSmoothSeconds) * dt);
                st.SmoothNormal = Vector3.Slerp(st.SmoothNormal, Vector3.up, na).normalized;
            }
        }

        static void Buoyancy(V53State st)
        {
            float g = Physics.gravity.magnitude;
            float rho = Cfg.FloatWaterDensity;
            int wet = 0;
            Transform t = st.Twin ? st.Twin.transform : null;
            if (!t) return;

            for (int i = 0; i < st.BlobPositions.Length; i++)
            {
                Vector3 wp = t.TransformPoint(st.BlobPositions[i]);
                float depth = st.SmoothSurfaceY - wp.y;
                if (depth > 0f)
                {
                    wet++;
                    float bv = st.BlobAreas[i] * Mathf.Min(depth, st.Profile.HalfExtents.y * 2f);
                    float dm = bv * rho * st.Profile.FillFactor;
                    float f = dm * g;
                    float maxF = st.Mass * g * 8f;
                    if (f > maxF) f = maxF;
                    st.Rb.AddForceAtPosition(Vector3.up * f, wp, ForceMode.Force);
                }
            }
            if (wet > 0)
            {
                float rvy = st.Rb.velocity.y - st.SmoothSurfaceVelY;
                st.Rb.AddForce(Vector3.up * (-rvy * st.Profile.WaterLinearDrag * st.Mass), ForceMode.Force);
            }
        }

        static void Drag(V53State st)
        {
            if (!st.Twin) return;
            bool wet = false;
            for (int i = 0; i < st.BlobPositions.Length; i++)
                if (st.Twin.transform.TransformPoint(st.BlobPositions[i]).y < st.SmoothSurfaceY) { wet = true; break; }
            if (!wet) return;
            st.Rb.AddForce(-st.Rb.velocity * (st.Profile.WaterLinearDrag * st.Mass), ForceMode.Force);
            st.Rb.AddTorque(-st.Rb.angularVelocity * (st.Profile.WaterAngularDrag * st.Mass), ForceMode.Force);
        }

        static void Posture(V53State st)
        {
            if (!Cfg.WavePosturesEnabled || !st.Twin) return;
            float m = st.Mass;
            Vector3 up = st.Twin.transform.up;
            Vector3 tUp = st.SmoothNormal;
            Vector3 axis = Vector3.Cross(up, tUp).normalized;
            float ang = Vector3.Angle(up, tUp);
            if (ang > 0.1f && axis.sqrMagnitude > 0.01f)
                st.Rb.AddTorque(axis * (ang * Mathf.Deg2Rad * st.Profile.AlignTorque * m), ForceMode.Force);
            st.Rb.AddTorque(-st.Rb.angularVelocity * (st.Profile.WaterAngularDrag * m * 0.5f), ForceMode.Force);
            if (st.Profile.SlopeSlide > 0f)
            {
                Vector3 sd = Vector3.ProjectOnPlane(tUp, Vector3.up).normalized;
                if (sd.sqrMagnitude > 0.01f)
                    st.Rb.AddForce(sd * (Vector3.Angle(tUp, Vector3.up) * st.Profile.SlopeSlide * m), ForceMode.Force);
            }
        }

        static void Wind(V53State st)
        {
            if (st.Profile.WindAccel <= 0f) return;
            try { st.Rb.AddForce(Wind.currentWind * (st.Profile.WindAccel * st.Mass), ForceMode.Force); }
            catch { }
        }
    }

    public sealed class V53State
    {
        public ShipItem Item;
        public Rigidbody Rb;
        public Component Twin;
        public FloatProfile Profile;
        public bool Active, Frozen;

        public float Mass, DisplacedVol;
        public Vector3 BoundsSize;
        public Vector3[] BlobPositions;
        public float[] BlobAreas;
        public int FrameCount;
        public float DistToPlayer;
        public float SmoothSurfaceY, SmoothSurfaceVelY;
        public Vector3 SmoothNormal = Vector3.up;
    }
}
