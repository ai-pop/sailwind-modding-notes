using System;
using System.Collections.Generic;
using SailwindItemPhysics.Api;
using SailwindItemPhysics.Bridge;
using UnityEngine;

namespace SailwindItemPhysics.Sim
{
    /// <summary>
    /// v5.3 — Open-source buoyancy driver. Replaces DLL SurfaceBodyDriver.
    /// ForceMode.Force everywhere — mass WORKS natively through Unity.
    /// Archimedes: F = waterDensity * displacedVolume * g per blob.
    /// displacedVolume = colliderVolume * FillFactor.
    /// </summary>
    [DefaultExecutionOrder(500)]
    public sealed class SurfaceBodyDriver : MonoBehaviour
    {
        private ShipItem _item;
        private Rigidbody _rb;
        private Component _twin;
        private FloatProfile _profile;

        private Vector3[] _blobLocalPositions;
        private float[] _blobAreas;

        private bool _active;
        private float _mass;
        private float _displacedVolume;
        private Vector3 _boundsSize;
        private int _fixedFrameCounter;

        private float _smoothSurfaceY;
        private float _smoothSurfaceVelY;
        private Vector3 _smoothNormal = Vector3.up;

        private FloatPosture _posture = FloatPosture.Upright;
        private float _distanceToPlayer;
        private bool _frozen;

        private static ISurfaceProvider _surfaceProvider;

        public float Mass => _mass;
        public float DisplacedVolume => _displacedVolume;
        public bool IsActive => _active;

        // ============ lifecycle ============

        public void Attach(ShipItem item, FloatProfile profile)
        {
            if (_active) return;
            _item = item;
            _profile = profile != null ? profile.Clone().Validate() : AutoProfile(item);
            _twin = ItemAccess.GetTwin(item);
            _rb = ItemAccess.GetRigidbody(item);
            if (_rb == null || _twin == null) return;

            _mass = _rb.mass = ItemAccess.EffectiveMass(item, _rb.mass);
            MeasureBounds();
            BuildBlobs();
            _active = true;
            _frozen = false;

            if (Cfg.Verbose)
                Plugin.Log?.LogInfo($"[Driver] '{item.name}' mass={_mass:F1}kg vol={_displacedVolume:F3}m3 fill={_profile.FillFactor:F2}");
        }

        public void Detach()
        {
            _active = false;
            _item = null;
            _rb = null;
            _twin = null;
        }

        private void OnDestroy() { Detach(); }

        // ============ measurement ============

        private void MeasureBounds()
        {
            _boundsSize = Vector3.one * 0.3f;
            try
            {
                var col = _twin != null ? _twin.GetComponent<Collider>() : null;
                if (col != null) _boundsSize = col.bounds.size;
                else
                {
                    var rend = _item != null ? _item.GetComponentInChildren<Renderer>() : null;
                    if (rend != null) _boundsSize = rend.bounds.size;
                }
            }
            catch { }

            float boundsVolume = _boundsSize.x * _boundsSize.y * _boundsSize.z;
            _displacedVolume = boundsVolume * _profile.FillFactor;

            if (_profile.HalfExtents.magnitude < 0.01f)
                _profile.HalfExtents = _boundsSize * 0.5f;
        }

        // ============ blobs ============

        private void BuildBlobs()
        {
            int n = _profile.RingSamples;
            var list = new List<Vector3>();
            var areas = new List<float>();
            Vector3 he = _profile.HalfExtents;

            list.Add(Vector3.zero);
            areas.Add(he.x * he.z);

            float step = Mathf.PI * 2f / n;
            for (int i = 0; i < n; i++)
            {
                float angle = step * i;
                list.Add(new Vector3(Mathf.Cos(angle) * he.x, 0f, Mathf.Sin(angle) * he.z));
                areas.Add((he.x + he.z) * 0.5f * 0.4f / n);
            }

            _blobLocalPositions = list.ToArray();
            _blobAreas = areas.ToArray();
        }

        private FloatProfile AutoProfile(ShipItem item)
        {
            var p = FloatProfile.Crate();
            try
            {
                string t = item != null ? item.GetType().Name : "";
                if (t.Contains("Bottle")) p = FloatProfile.Bottle();
                else if (item.name.IndexOf("barrel", StringComparison.OrdinalIgnoreCase) >= 0) p = FloatProfile.Barrel();
                else if (item.mass > 30f) p = FloatProfile.HeavyCrate();
            }
            catch { }
            return p.Validate();
        }

        // ============ simulation ============

        private void FixedUpdate()
        {
            if (!_active || _rb == null) return;

            _fixedFrameCounter++;
            int stride = GetLODStride();
            if (_fixedFrameCounter % stride != 0) return;

            if ((_fixedFrameCounter % 10) == 0)
            {
                float newMass = ItemAccess.EffectiveMass(_item, _mass);
                if (Mathf.Abs(newMass - _mass) > 0.05f)
                    _mass = _rb.mass = newMass;
            }

            _distanceToPlayer = DistanceToPlayer();

            if (_distanceToPlayer > Cfg.FreezeDistance)
            {
                if (!_frozen) { _rb.velocity = Vector3.zero; _rb.angularVelocity = Vector3.zero; _rb.Sleep(); _frozen = true; }
                return;
            }
            if (_frozen && _distanceToPlayer < Cfg.WakeDistance) { _rb.WakeUp(); _frozen = false; }

            UpdateSurfaceSample();
            ApplyBuoyancy();
            ApplyDrag();
            ApplyPosture();
            ApplyWind();
        }

        private int GetLODStride()
        {
            if (_distanceToPlayer < _profile.NearDistance) return _profile.FixedStride;
            if (_distanceToPlayer < _profile.MidDistance) return _profile.MidStride;
            return _profile.FarStride;
        }

        private float DistanceToPlayer()
        {
            try { if (Camera.main != null) return Vector3.Distance(transform.position, Camera.main.transform.position); }
            catch { }
            return 9999f;
        }

        // ============ surface ============

        private void UpdateSurfaceSample()
        {
            if (_surfaceProvider == null) _surfaceProvider = ResolveSurfaceProvider();

            float rawY = transform.position.y;
            if (_surfaceProvider != null)
            {
                SurfaceSample s;
                if (_surfaceProvider.TryGetSample(transform.position, out s) && s.Valid)
                    rawY = s.Y;
            }

            float smoothRate = Cfg.WaveSurfaceSmoothSeconds > 0.001f ? 1f / Cfg.WaveSurfaceSmoothSeconds : 20f;
            float dt = Mathf.Max(Time.fixedDeltaTime * GetLODStride(), 0.001f);
            float a = 1f - Mathf.Exp(-smoothRate * dt);
            float prevY = _smoothSurfaceY;
            _smoothSurfaceY = Mathf.Lerp(_smoothSurfaceY, rawY, a);
            _smoothSurfaceVelY = (_smoothSurfaceY - prevY) / dt;

            if (Cfg.WaveNormalSmoothSeconds > 0.001f)
            {
                float na = 1f - Mathf.Exp(-(1f / Cfg.WaveNormalSmoothSeconds) * dt);
                Vector3 rawNormal = Vector3.up;
                if (_surfaceProvider != null)
                {
                    SurfaceSample s;
                    if (_surfaceProvider.TryGetSample(transform.position, out s) && s.Valid)
                        rawNormal = s.Normal;
                }
                _smoothNormal = Vector3.Slerp(_smoothNormal, rawNormal, na).normalized;
            }
        }

        private static ISurfaceProvider ResolveSurfaceProvider()
        {
            try
            {
                var t = Type.GetType("SailwindItemPhysics.Ocean.OceanSurface, SailwindItemPhysics");
                if (t != null)
                {
                    var get = t.GetMethod("GetProvider", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public);
                    if (get != null) return get.Invoke(null, null) as ISurfaceProvider;
                }
            }
            catch { }
            return null;
        }

        // ============ Archimedes buoyancy ============

        private void ApplyBuoyancy()
        {
            float g = Physics.gravity.magnitude;
            float rho = Cfg.FloatWaterDensity;
            int wetCount = 0;

            for (int i = 0; i < _blobLocalPositions.Length; i++)
            {
                Vector3 worldPos = transform.TransformPoint(_blobLocalPositions[i]);
                float depth = _smoothSurfaceY - worldPos.y;

                if (depth > 0f)
                {
                    wetCount++;
                    float blobVolume = _blobAreas[i] * Mathf.Min(depth, _profile.HalfExtents.y * 2f);
                    float displacedMass = blobVolume * rho * _profile.FillFactor;
                    float forceN = displacedMass * g;

                    float maxForce = _mass * g * 8f;
                    if (forceN > maxForce) forceN = maxForce;

                    _rb.AddForceAtPosition(Vector3.up * forceN, worldPos, ForceMode.Force);
                }
            }

            if (wetCount > 0)
            {
                float relVelY = _rb.velocity.y - _smoothSurfaceVelY;
                _rb.AddForce(Vector3.up * (-relVelY * _profile.WaterLinearDrag * _mass), ForceMode.Force);
            }
        }

        // ============ drag ============

        private void ApplyDrag()
        {
            bool anyWet = false;
            for (int i = 0; i < _blobLocalPositions.Length; i++)
            {
                if (transform.TransformPoint(_blobLocalPositions[i]).y < _smoothSurfaceY) { anyWet = true; break; }
            }
            if (!anyWet) return;

            _rb.AddForce(-_rb.velocity * (_profile.WaterLinearDrag * _mass), ForceMode.Force);
            _rb.AddTorque(-_rb.angularVelocity * (_profile.WaterAngularDrag * _mass), ForceMode.Force);
        }

        // ============ posture ============

        private void ApplyPosture()
        {
            if (_posture == FloatPosture.Free || !Cfg.WavePosturesEnabled) return;

            float mass = _mass;
            Vector3 up = transform.up;
            Vector3 targetUp = _smoothNormal;
            Vector3 axis = Vector3.Cross(up, targetUp).normalized;
            float angle = Vector3.Angle(up, targetUp);

            if (angle > 0.1f && axis.sqrMagnitude > 0.01f)
            {
                float torqueMag = angle * Mathf.Deg2Rad * _profile.AlignTorque * mass;
                _rb.AddTorque(axis * torqueMag, ForceMode.Force);
            }

            _rb.AddTorque(-_rb.angularVelocity * (_profile.WaterAngularDrag * mass * 0.5f), ForceMode.Force);

            if (_profile.SlopeSlide > 0f)
            {
                Vector3 slopeDir = Vector3.ProjectOnPlane(targetUp, Vector3.up).normalized;
                if (slopeDir.sqrMagnitude > 0.01f)
                {
                    _rb.AddForce(slopeDir * (Vector3.Angle(targetUp, Vector3.up) * _profile.SlopeSlide * mass), ForceMode.Force);
                }
            }
        }

        private void ApplyWind()
        {
            if (_profile.WindAccel <= 0f) return;
            try { _rb.AddForce(Wind.currentWind * (_profile.WindAccel * _mass), ForceMode.Force); }
            catch { }
        }
    }

    public interface ISurfaceProvider
    {
        bool TryGetSample(Vector3 worldPos, out SurfaceSample sample);
    }
}
