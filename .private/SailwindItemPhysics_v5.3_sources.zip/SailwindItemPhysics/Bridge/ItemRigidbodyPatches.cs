using System;
using HarmonyLib;
using UnityEngine;

namespace SailwindItemPhysics.Bridge
{
    /// <summary>
    /// Keep registered cargo bodies dynamic; manage floater OWNERSHIP (v4.7.3):
    /// vanilla Twin does not float by itself (game switches its floater off every
    /// frame, notes 33/43) — so we keep the Crest floater alive ONLY while the
    /// body is beyond our far LOD; near the player Archimedes owns the water and
    /// the floater must stay OFF (two buoyancy engines = item pushed ABOVE the
    /// surface — "water too dense / hovers cm over water" user report).
    /// Hot path: dictionary lookup only — never scan the world.
    /// v3: also patches ResetPos (pickup/place re-sync) and honours config gate.
    /// </summary>
    internal static class ItemRigidbodyPatches
    {
        public static void Apply(Harmony harmony)
        {
            if (!Cfg.EnableVanillaPatches)
            {
                Plugin.Log?.LogInfo("[Bridge] vanilla patches disabled by config");
                return;
            }

            var ir = AccessTools.TypeByName("ItemRigidbody");
            if (ir == null)
            {
                Plugin.Log?.LogWarning("[Bridge] ItemRigidbody type missing — vanilla will fight float");
                return;
            }

            int patched = 0;
            try
            {
                var toggle = AccessTools.Method(ir, "ToggleCollider", new[] { typeof(bool) });
                if (toggle != null)
                {
                    harmony.Patch(toggle,
                        postfix: new HarmonyMethod(typeof(ItemRigidbodyPatches), nameof(OnToggle)));
                    patched++;
                }

                var fixedUp = AccessTools.Method(ir, "FixedUpdate");
                if (fixedUp != null)
                {
                    harmony.Patch(fixedUp,
                        postfix: new HarmonyMethod(typeof(ItemRigidbodyPatches), nameof(OnFixed)));
                    patched++;
                }

                var reset = AccessTools.Method(ir, "ResetPos");
                if (reset != null)
                {
                    harmony.Patch(reset,
                        postfix: new HarmonyMethod(typeof(ItemRigidbodyPatches), nameof(OnResetPos)));
                    patched++;
                }

                Plugin.Log?.LogInfo("[Bridge] ItemRigidbody patches applied: " + patched + "/3");
            }
            catch (Exception ex)
            {
                Plugin.Log?.LogError("[Bridge] patch failed: " + ex);
            }
        }

        private static void OnToggle(object __instance)
        {
            ShipItem item;
            if (!BodyRegistry.TryGet(__instance, out item)) return;
            if (item == null || item.held != null) return;

            var c = __instance as Component;
            if (c != null)
                KeepFloaterIfFar(c);
        }

        /// <summary>v5.0.0: the vanilla Crest floater is gone FOR GOOD on
        /// managed bodies (user design — clean replacement end to end). Far
        /// bodies are parked frozen by the driver instead of being handed
        /// back to vanilla. Name kept from the 4.7.x era.</summary>
        private static void KeepFloaterIfFar(Component c)
        {
            ItemAccess.SetFloaterEnabled(c, false);
        }

        private static void OnFixed(object __instance)
        {
            ShipItem item;
            if (!BodyRegistry.TryGet(__instance, out item)) return;
            if (item == null || item.held != null) return;

            var c = __instance as Component;
            if (c == null) return;

            // only meddle when the item is FREE in the world — on boat / in box vanilla owns it
            if (ItemAccess.IsOnBoat(c) || ItemAccess.IsContained(c)) return;

            // v5.1.2 (verbatim research): vanilla freezes SETTLED mesh-collider
            // bodies itself — ItemRigidbody.FixedUpdate: meshCol && IsSleeping
            // && dynamicColTimer<=0 → isKinematic=true. We still tear that
            // freeze off free world-floaters (they belong to the live sim) —
            // but NOT off PARKED bodies: our far-LOD park is an intentional
            // kinematic freeze now; tearing it off here every frame was a
            // pointless auto-sleep↔unfreeze war per parked body.
            var rb = c.GetComponent<Rigidbody>();
            if (rb != null && rb.isKinematic &&
                !SailwindItemPhysics.Sim.SurfaceBodyDriver.IsParked(item))
            {
                ItemAccess.PrepareForWorldFloat(item);
                rb.isKinematic = false;
                try { rb.WakeUp(); } catch { /* ok */ }
            }

            if ((Time.frameCount & 7) == 0)
                KeepFloaterIfFar(c);
        }

        /// <summary>Pickup/place re-sync: drop stale driver state via service.</summary>
        private static void OnResetPos(object __instance)
        {
            ShipItem item;
            if (!BodyRegistry.TryGet(__instance, out item)) return;
            if (item == null) return;
            // driver notices the position jump itself (teleport guard) — nothing else needed,
            // but give the service a chance to surface the transition as an event
            Plugin.Svc?.NotifyWorldResync(item);
        }
    }
}
