using System.Collections.Generic;
using UnityEngine;

namespace SailwindItemPhysics.Bridge
{
    /// <summary>
    /// v4.7.4 — remembers WHERE the player released an item in the last few
    /// seconds. The vanilla "placed/stowed/anchor" release path (drop without
    /// the drop key, user log 4.7.3: 12 releases in a row went down this path)
    /// can nail the body mid-air — the twin then hangs frozen a couple of
    /// centimetres above the sea. The surface driver frees such nails ONLY
    /// for bodies at a recently-seen release point, so wall/dock decorations
    /// the player actually nailed are never touched.
    /// Position-based (not instance-based) on purpose: that path re-instantiates
    /// the item ('53 goat cheese(Clone)' booted fresh after every release), so
    /// instance IDs do not survive.
    /// </summary>
    internal static class RecentReleases
    {
        private struct Ev { public Vector3 P; public float T; }

        private static readonly List<Ev> _events = new List<Ev>();
        private const float Keep = 10f;
        private const float SqrRadius = 6.25f;   // 2.5 m around the release point

        internal static void Note(Vector3 pos)
        {
            float now = Time.unscaledTime;
            _events.Add(new Ev { P = pos, T = now });
            // lazy trim
            for (int i = _events.Count - 1; i >= 0; i--)
                if (now - _events[i].T > Keep) _events.RemoveAt(i);
        }

        internal static bool Recent(Vector3 pos, float window)
        {
            float now = Time.unscaledTime;
            for (int i = 0; i < _events.Count; i++)
            {
                var e = _events[i];
                if (now - e.T > window) continue;
                if ((e.P - pos).sqrMagnitude <= SqrRadius) return true;
            }
            return false;
        }
    }
}
