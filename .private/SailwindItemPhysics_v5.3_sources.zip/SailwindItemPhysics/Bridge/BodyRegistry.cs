using System.Collections.Generic;
using UnityEngine;

namespace SailwindItemPhysics.Bridge
{
    /// <summary>
    /// O(1) registry for Harmony hot paths. Only registered twins are touched.
    /// </summary>
    internal static class BodyRegistry
    {
        private static readonly Dictionary<int, ShipItem> Twin = new Dictionary<int, ShipItem>(32);
        private static readonly HashSet<int> Items = new HashSet<int>();

        public static int Count { get { return Items.Count; } }

        public static void Add(ShipItem item, Component twin)
        {
            if (item == null) return;
            Items.Add(item.GetInstanceID());
            if (twin != null)
                Twin[twin.GetInstanceID()] = item;
        }

        public static void Remove(ShipItem item)
        {
            if (item == null) return;
            Items.Remove(item.GetInstanceID());
            if (Twin.Count == 0) return;
            var dead = new List<int>(4);
            foreach (var kv in Twin)
            {
                if (kv.Value == null || kv.Value == item)
                    dead.Add(kv.Key);
            }
            for (int i = 0; i < dead.Count; i++)
                Twin.Remove(dead[i]);
        }

        public static bool TryGet(object twinInstance, out ShipItem item)
        {
            item = null;
            var c = twinInstance as Component;
            if (c == null) return false;
            return Twin.TryGetValue(c.GetInstanceID(), out item) && item != null;
        }

        public static bool Contains(ShipItem item)
        {
            return item != null && Items.Contains(item.GetInstanceID());
        }
    }
}
