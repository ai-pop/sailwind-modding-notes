using System;
using System.Reflection;   // FieldInfo (LookUI TextMesh caches)
using HarmonyLib;
using UnityEngine;

namespace SailwindItemPhysics.Bridge
{
    /// <summary>
    /// v5.1 — "how heavy is it" right in the vanilla hover UI (user order:
    /// "aim at a crate/barrel — there's info like the liquid amount; put the
    /// weight there").
    ///
    /// The game funnels ALL item look-text through
    /// <c>LookUI.ShowLookText(GoPointerButton)</c> (notes 08/10): each frame
    /// the hovered button's fields are recomputed (ShipItem.UpdateLookText —
    /// bottles write their fill, crates "name (amount)", mission items their
    /// destination) and then copied into the LookUI TextMeshes —
    /// button.lookText → <c>extraText</c> (the name block, ABOVE),
    /// button.description → <c>hintText</c> (the info block, BELOW).
    /// One postfix covers every one of the 35+ item subclasses.
    ///
    /// v5.1.1 fixes (user: "the weight OVERLAPS other info on barrels; make
    /// the text adapt so it's always clearly visible and distinct; and the
    /// mod is for Russians AND Americans — localize it"):
    ///
    /// 1. ADAPTIVE PLACEMENT — the weight must ride the item's OWN deepest
    ///    text block instead of hard-landing inside extraText (the barrel's
    ///    fill line lives in hintText at a FIXED offset under extraText; an
    ///    extra line in extraText was drawn straight through it):
    ///      - hintText already has info (barrel fill) → weight appended there,
    ///        AS A NEW LINE UNDER it;
    ///      - extraText is multi-line (mission items — vanilla itself stacks
    ///        that block) → weight joins that block;
    ///      - otherwise the empty hint slot under a single-line name is used —
    ///        the weight gets its own clean line, always below everything
    ///        vanilla shows for that item;
    ///      - no hintText at all → extraText (5.1.0 behaviour, worst case).
    ///    A strip-guard removes our previous suffix from EITHER mesh every
    ///    call, so frames can move the line around without ever stacking it.
    ///
    /// 2. DISTINCT STYLING — the line reads "(26 кг)" / "(26 kg)"; the
    ///    parentheses separate it visually from vanilla's bare-text lines
    ///    (fill percentages, "Nailed", amounts).
    ///
    /// 3. LOCALIZED — [UI] Language: Auto | en | ru (Auto follows the OS
    ///    locale). Everything defensive: if LookUI differs from the notes,
    ///    the mod silently keeps working without the hover weight.
    /// </summary>
    internal static class LookMassPatch
    {
        private static FieldInfo _extraText;
        private static FieldInfo _hintText;
        private static string _lastAppend = "";

        internal static void Apply(Harmony harmony)
        {
            if (!Cfg.ShowMassInLookText) return;
            try
            {
                var t = AccessTools.TypeByName("LookUI");
                if (t == null)
                {
                    Plugin.Log?.LogWarning("[LookMass] LookUI type not found — hover mass disabled");
                    return;
                }
                var m = AccessTools.Method(t, "ShowLookText");
                if (m == null)
                {
                    Plugin.Log?.LogWarning("[LookMass] LookUI.ShowLookText not found — hover mass disabled");
                    return;
                }
                _extraText = AccessTools.Field(t, "extraText");
                _hintText = AccessTools.Field(t, "hintText");
                if (_extraText == null && _hintText == null)
                {
                    Plugin.Log?.LogWarning("[LookMass] no LookUI text fields found — hover mass disabled");
                    return;
                }

                harmony.Patch(m, postfix: new HarmonyMethod(
                    typeof(LookMassPatch), "Postfix"));
                Plugin.Log?.LogInfo("[LookMass] hover mass ON (LookUI.ShowLookText postfix, lang=" +
                                    Cfg.UiLanguage +
                                    (_hintText != null ? ", adaptive layout" : ", extraText only") + ")");
            }
            catch (Exception ex)
            {
                Plugin.Log?.LogWarning("[LookMass] patch failed: " + ex.Message);
            }
        }

        private static void Postfix(object __0, object __instance)
        {
            try
            {
                TextMesh extra = null, hint = null;
                if (_extraText != null) extra = _extraText.GetValue(__instance) as TextMesh;
                if (_hintText != null) hint = _hintText.GetValue(__instance) as TextMesh;

                // strip our suffix from wherever it went last frame FIRST —
                // placement can legitimately move (description became visible,
                // target mesh replaced...) and the line must never stack
                StripIfEnds(extra);
                StripIfEnds(hint);
                _lastAppend = "";

                if (!Cfg.ShowMassInLookText) return;
                var item = __0 as ShipItem;
                if (item == null) return;

                float contents;
                float own = 0f;
                try { own = item.mass; } catch { /* ok */ }
                float mass = ItemAccess.EffectiveMass(item, own, out contents);
                if (mass <= 0.01f) return;

                string line = MassLine(mass, contents);

                // pick the item's OWN deepest text block (see class doc)
                string hintStr = hint != null ? hint.text : null;
                string extraStr = extra != null ? extra.text : null;
                TextMesh target;
                if (!string.IsNullOrEmpty(hintStr))
                    target = hint;                                   // weight under the fill/info line
                else if (!string.IsNullOrEmpty(extraStr) && extraStr.Contains("\n"))
                    target = extra;                                  // vanilla already stacks the name block
                else if (hint != null)
                    target = hint;                                   // empty hint slot under a one-line name
                else
                    target = extra;                                  // last resort
                if (target == null) return;

                string append = "\n" + line;
                target.text = (target.text ?? "") + append;
                _lastAppend = append;
            }
            catch { /* hover text must never throw — the game looks every frame */ }
        }

        private static void StripIfEnds(TextMesh mesh)
        {
            if (mesh == null || _lastAppend.Length == 0) return;
            var t = mesh.text;
            if (t != null && t.EndsWith(_lastAppend, StringComparison.Ordinal))
                mesh.text = t.Substring(0, t.Length - _lastAppend.Length);
        }

        /// <summary>The weight line, localized: "(26 кг)", "(26 kg)",
        /// with the contents split "(26 кг: 8 + 18)" / "(26 kg: 8 + 18)"
        /// when the breakdown is on and contents add weight.</summary>
        private static string MassLine(float mass, float contents)
        {
            string unit = Cfg.UiLanguage == "ru" ? "кг" : "kg";
            if (Cfg.MassBreakdown && contents > 0.05f)
                return "(" + Fmt(mass) + " " + unit + ": " +
                       Fmt(mass - contents) + " + " + Fmt(contents) + ")";
            return "(" + Fmt(mass) + " " + unit + ")";
        }

        private static string Fmt(float kg)
        {
            // whole numbers above 10 kg, one decimal below (a mug still reads
            // "0.6 kg"/"0,6 кг" instead of "1 kg")
            return kg < 10f ? kg.ToString("0.0#") : kg.ToString("0.#");
        }
    }
}
