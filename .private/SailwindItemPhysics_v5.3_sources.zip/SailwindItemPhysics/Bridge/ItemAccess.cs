using System;
using System.Reflection;
using UnityEngine;

namespace SailwindItemPhysics.Bridge
{
    /// <summary>
    /// Access ShipItem twin via public API when possible (note 44):
    /// item.itemRigidbodyC / GetItemRigidbody() / GetBody().
    /// Reflection only as fallback.
    /// </summary>
    internal static class ItemAccess
    {
        private const BindingFlags F =
            BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

        private static MethodInfo _getIr;
        private static MethodInfo _getBody;
        private static FieldInfo _irCField;
        private static FieldInfo _debugKin;
        private static FieldInfo _floater;
        private static FieldInfo _raise;
        private static FieldInfo _onBoat;
        private static FieldInfo _curBox;
        private static FieldInfo _curSlot;
        private static FieldInfo _outOfRange;
        private static FieldInfo _attached;
        private static bool _resolved;

        private static void Resolve(ShipItem sample)
        {
            if (_resolved) return;
            _resolved = true;

            if (sample != null)
            {
                var st = sample.GetType();
                _getIr = st.GetMethod("GetItemRigidbody",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                _irCField = st.GetField("itemRigidbodyC",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            }

            var irType = Find("ItemRigidbody");
            if (irType != null)
            {
                _getBody = irType.GetMethod("GetBody",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                _debugKin = irType.GetField("debugForceKinematic",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                _floater = irType.GetField("floater",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                    ?? irType.GetField("_floater",
                        BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                _onBoat = irType.GetField("onBoat", F);
                _curBox = irType.GetField("currentBox", F);
                _curSlot = irType.GetField("currentInventorySlot", F);
                _outOfRange = irType.GetField("outOfRange", F);
                _attached = irType.GetField("attached", F);
            }

            var sfo = Find("SimpleFloatingObject");
            if (sfo != null)
            {
                _raise = sfo.GetField("_raiseObject",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            }

            Plugin.Log?.LogInfo(
                $"[ItemAccess] GetItemRigidbody={_getIr != null} itemRigidbodyC={_irCField != null} " +
                $"GetBody={_getBody != null} debugKin={_debugKin != null}");
        }

        public static Component GetTwin(ShipItem item)
        {
            if (item == null) return null;
            Resolve(item);

            // Public field itemRigidbodyC
            if (_irCField != null)
            {
                try
                {
                    var v = _irCField.GetValue(item) as Component;
                    if (v != null) return v;
                }
                catch { /* ok */ }
            }

            // Public method GetItemRigidbody()
            if (_getIr != null)
            {
                try
                {
                    var v = _getIr.Invoke(item, null) as Component;
                    if (v != null) return v;
                }
                catch { /* ok */ }
            }

            // Fallback field names
            foreach (var n in new[] { "itemRigidbodyC", "itemRigidbody", "_itemRigidbody" })
            {
                var f = item.GetType().GetField(n, F);
                if (f == null) continue;
                try
                {
                    var v = f.GetValue(item);
                    if (v is Component c) return c;
                    if (v is Transform tr) return tr.GetComponent(Find("ItemRigidbody")) as Component ?? tr;
                }
                catch { /* ok */ }
            }

            var irt = Find("ItemRigidbody");
            if (irt != null)
                return item.GetComponentInChildren(irt, true);
            return null;
        }

        public static Rigidbody GetRigidbody(ShipItem item)
        {
            var twin = GetTwin(item);
            if (twin == null) return null;

            if (_getBody != null)
            {
                try
                {
                    var b = _getBody.Invoke(twin, null) as Rigidbody;
                    if (b != null) return b;
                }
                catch { /* ok */ }
            }

            return twin.GetComponent<Rigidbody>()
                   ?? twin.GetComponentInChildren<Rigidbody>(true);
        }

        public static ShipItem GetItem(object twinInstance)
        {
            var twin = twinInstance as Component;
            if (twin == null) return null;

            // GetShipItem()
            try
            {
                var m = twin.GetType().GetMethod("GetShipItem",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (m != null)
                {
                    var si = m.Invoke(twin, null) as ShipItem;
                    if (si != null) return si;
                }
            }
            catch { /* ok */ }

            foreach (var n in new[] { "item", "shipItem", "_item" })
            {
                var f = twin.GetType().GetField(n, F);
                if (f != null)
                {
                    try
                    {
                        var si = f.GetValue(twin) as ShipItem;
                        if (si != null) return si;
                    }
                    catch { /* ok */ }
                }
            }

            return twin.GetComponentInParent<ShipItem>();
        }

        public static void PrepareForWorldFloat(ShipItem item)
        {
            if (item == null) return;
            try { item.sold = true; } catch { /* ok */ }
            try { item.nailed = false; } catch { /* ok */ }

            var twin = GetTwin(item);
            if (twin != null)
            {
                if (_debugKin != null)
                {
                    try { _debugKin.SetValue(twin, false); } catch { /* ok */ }
                }
                // v5.3: CRITICAL FIX — clear attached flag.
                // Vanilla sets attached=true via wallAttachment init,
                // CrateInventory.InsertItem, HangableItem.ConnectJoint.
                // If we don't clear it, SurfaceBodyDriver sees IsAttached=true
                // and suspends the item permanently (the "frozen above water" bug).
                SetAttached(twin, false);

                // Also clear disableCol + inStove — these are crate-internal flags
                try
                {
                    var disableF = twin.GetType().GetField("disableCol", F);
                    if (disableF != null) disableF.SetValue(twin, false);
                }
                catch { /* ok */ }
                try
                {
                    var stoveF = twin.GetType().GetField("inStove", F);
                    if (stoveF != null) stoveF.SetValue(twin, false);
                }
                catch { /* ok */ }
            }

            // Ensure physics colliders enabled
            try
            {
                if (twin != null)
                {
                    foreach (var col in twin.GetComponentsInChildren<Collider>(true))
                    {
                        if (col != null && !col.isTrigger)
                            col.enabled = true;
                    }
                }
            }
            catch { /* ok */ }
        }

        public static void ForceDynamic(Rigidbody rb)
        {
            if (rb == null) return;
            rb.isKinematic = false;
            try
            {
                rb.detectCollisions = true;
                rb.WakeUp();
            }
            catch { /* ok */ }
        }

        /// <summary>v5.1.1 (user: "maybe some lock blocks rotation in water —
        /// remove it, items must rotate any way PHYSICS dictates"): nothing is
        /// allowed to lock a floating body's rotation — not vanilla's
        /// ItemRigidbody setup, not another mod's FreezeRotation. We reset
        /// constraints to None at configure + on the keep-alive cadence; the
        /// FLOAT CHARACTER (crate stands, barrel lies) is done by our own
        /// posture torques, everything else rotates strictly by physics.
        /// Returns true when an actual lock had to be broken (log-worthy).</summary>
        public static bool UnlockRotation(Rigidbody rb)
        {
            if (rb == null) return false;
            try
            {
                if (rb.constraints != RigidbodyConstraints.None)
                {
                    rb.constraints = RigidbodyConstraints.None;
                    return true;
                }
            }
            catch { /* ok */ }
            return false;
        }

        // ---------------- v4.7.2 effective mass (crate contents) ----------------

        private static System.Type _crateInvT;
        private static bool _crateInvProbed;
        private static bool _ciDiagDone;

        // note 62/64/65: vanilla UpdateMass() does rb.mass = item.mass +
        // containedPrefab.mass × amount — and those fields live on the
        // ShipItemCrate ITSELF (the 4.7.5 field probe proved CrateInventory
        // holds ONLY 'containedItems'). Vanilla NEVER recounts opened/loot
        // crates → we count everything ourselves, from every place contents
        // can live. 4.7.2's reading of amount/containedPrefab off the
        // CrateInventory component was reading an empty room (user: full
        // firewood crate stayed 5.0 kg and floated like a cork).
        public static float EffectiveMass(ShipItem item, float fallback)
        {
            float extra;
            return EffectiveMass(item, fallback, out extra);
        }

        public static float EffectiveMass(ShipItem item, float fallback, out float contentsExtra)
        {
            contentsExtra = 0f;
            float m = fallback;
            try { if (item != null && item.mass > 0.3f) m = item.mass; }
            catch { /* ok */ }

            if (item == null || !Cfg.FloatCrateContentsMass)
                return Mathf.Clamp(m, 0.3f, 2000f);

            Component ci = null;
            object prefabObj = null;
            float amount = 0f;
            bool sealedFull = false;

            try
            {
                string tn = item.GetType().Name;

                // --- sealed crate path (note 64/65 verbatim: fields ON the
                // ShipItemCrate): mass += containedPrefab.mass × amount ---
                prefabObj = ReadObj(item, "containedPrefab");
                amount = ReadNum(item, "amount");
                if (prefabObj != null && amount > 0.01f)
                {
                    float pm = PrefabMass(prefabObj);
                    if (pm > 0.05f)
                    {
                        contentsExtra += pm * amount;
                        sealedFull = true;
                    }
                }

                // --- vanilla per-subclass modifiers (note 65) ---
                if (tn == "ShipItemBottle")
                    contentsExtra += Mathf.Max(0f, ReadNum(item, "health"));
                else if (tn == "ShipItemTea" || tn == "ShipItemSalt")
                    contentsExtra += Mathf.Max(0f, ReadNum(item, "amount")) * 0.1f;

                // --- opened crate path: contents vanilla never recounted ---
                if (!sealedFull)
                {
                    ci = FindCrateInventory(item);
                    int listed = 0;
                    var list = ci != null
                        ? ReadObj(ci, "containedItems") as System.Collections.IEnumerable
                        : null;
                    if (list != null)
                    {
                        int guard = 0;
                        foreach (var e in list)
                        {
                            if (++guard > 400) break;         // paranoia cap
                            contentsExtra += PrefabMass(e);
                            listed++;
                        }
                    }

                    // fallback: contents physically parented UNDER the crate
                    // (4.7.5 field probe watched containedItems sit at 0)
                    if (listed == 0)
                    {
                        int guard = 0;
                        foreach (var child in item.GetComponentsInChildren<ShipItem>(true))
                        {
                            if (child == null || ReferenceEquals(child, item)) continue;
                            if (++guard > 400) break;
                            float cm = 0f;
                            try { cm = child.mass; } catch { /* ok */ }
                            if (cm > 0f) contentsExtra += cm;
                        }
                    }
                }
            }
            catch { /* best effort */ }

            if (contentsExtra <= 0.001f) ProbeContentsOnce(item, ci, prefabObj, amount);   // v4.7.4/4.7.6

            return Mathf.Clamp(m + contentsExtra, 0.3f, 2000f);
        }

        /// <summary>
        /// v4.7.4 — contents came out ZERO on something named like a crate:
        /// the note-62 field guesses miss the live schema (field log: '108
        /// crate of firewood' still 5.0 kg, zero 'contents +' lines). Dump the
        /// real component shape ONCE per session so names stop being folklore.
        /// </summary>
        private static void ProbeContentsOnce(ShipItem item, Component ci, object prefabObj, float amount)
        {
            if (_ciDiagDone || item == null || !Cfg.FloatCrateContentsMass) return;
            bool looksCrate;
            try { looksCrate = item.name.IndexOf("crate", System.StringComparison.OrdinalIgnoreCase) >= 0; }
            catch { return; }
            if (!looksCrate && ci == null && prefabObj == null) return;
            _ciDiagDone = true;
            try
            {
                var sb = new System.Text.StringBuilder(
                    "[ItemAccess] crate contents probe on '" + item.name + "': ");
                // v4.7.6: report the item-side readings too (sealed path lives
                // on ShipItemCrate itself — note 64/65)
                sb.Append("itemType=").Append(item.GetType().Name)
                  .Append(" amount=").Append(amount.ToString("0.##"))
                  .Append(" containedPrefab=")
                  .Append(prefabObj != null
                      ? "m=" + PrefabMass(prefabObj).ToString("0.0")
                      : "null")
                  .Append(" childShipItems=").Append(CountChildItems(item))
                  .Append(" | ");
                if (ci == null)
                {
                    sb.Append("NO CrateInventory component — candidates on item:");
                    foreach (var c in item.GetComponentsInChildren<Component>(true))
                    {
                        if (c == null) continue;
                        var nm = c.GetType().Name;
                        if (nm.IndexOf("crate", System.StringComparison.OrdinalIgnoreCase) >= 0 ||
                            nm.IndexOf("invent", System.StringComparison.OrdinalIgnoreCase) >= 0 ||
                            nm.IndexOf("contain", System.StringComparison.OrdinalIgnoreCase) >= 0)
                            sb.Append(' ').Append(c.GetType().FullName).Append(';');
                    }
                }
                else
                {
                    sb.Append("type=").Append(ci.GetType().FullName).Append(" fields:");
                    int n = 0;
                    foreach (var f in ci.GetType().GetFields(F))
                    {
                        if (++n > 24) { sb.Append(" …"); break; }
                        object v;
                        try { v = f.GetValue(ci); } catch { v = "?"; }
                        string vs = v == null ? "null"
                            : (v is System.Collections.ICollection) ? "count=" + ((System.Collections.ICollection)v).Count
                            : v.ToString();
                        if (vs.Length > 24) vs = vs.Substring(0, 24);
                        sb.Append(' ').Append(f.Name).Append('=').Append(vs).Append(';');
                    }
                }
                Plugin.Log?.LogWarning(sb.ToString());
            }
            catch { /* diag must never kill mass math */ }
        }

        private static Component FindCrateInventory(ShipItem item)
        {
            if (!_crateInvProbed)
            {
                _crateInvProbed = true;
                _crateInvT = Find("CrateInventory");
            }
            if (_crateInvT == null) return null;
            var ci = item.GetComponent(_crateInvT);
            if (ci == null) ci = item.GetComponentInChildren(_crateInvT, true);
            return ci;
        }

        private static int CountChildItems(ShipItem item)
        {
            int n = 0, guard = 0;
            try
            {
                foreach (var child in item.GetComponentsInChildren<ShipItem>(true))
                {
                    if (child == null || ReferenceEquals(child, item)) continue;
                    if (++guard > 400) break;
                    n++;
                }
            }
            catch { /* ok */ }
            return n;
        }

        private static float ReadNum(object o, string name)
        {
            var v = ReadObj(o, name);
            if (v is float) return (float)v;
            if (v is int) return (int)v;
            if (v is double) return (float)(double)v;
            if (v is long) return (long)v;
            return 0f;
        }

        private static float PrefabMass(object o)
        {
            if (o == null) return 0f;
            try
            {
                // containedPrefab is a GameObject (note 64) — unwrap first
                var go = o as GameObject;
                if (go != null)
                {
                    var si0 = go.GetComponent<ShipItem>();
                    if (si0 != null && si0.mass > 0f) return si0.mass;
                }
                var si = o as ShipItem;
                if (si != null && si.mass > 0f) return si.mass;

                var c = o as Component;
                if (c != null)
                {
                    var si2 = c.GetComponent<ShipItem>();
                    if (si2 != null && si2.mass > 0f) return si2.mass;
                }

                // wrapper types (Good etc.): dig one level of obvious containers
                foreach (var name in new[] { "item", "shipItem", "prefab", "gameObject" })
                {
                    var inner = ReadObj(o, name);
                    if (inner != null && !ReferenceEquals(inner, o))
                    {
                        float pm = PrefabMass(inner);
                        if (pm > 0f) return pm;
                    }
                }
                var fm = ReadObj(o, "mass");
                if (fm is float && (float)fm > 0f) return (float)fm;
            }
            catch { /* ok */ }
            return 0f;
        }

        private static object ReadObj(object o, string name)
        {
            if (o == null) return null;
            var t = o.GetType();
            var f = t.GetField(name, F);
            if (f != null) { try { return f.GetValue(o); } catch { return null; } }
            var p = t.GetProperty(name, F);
            if (p != null) { try { return p.GetValue(o, null); } catch { return null; } }
            return null;
        }

        private static int ReadInt(object o, string name)
        {
            var v = ReadObj(o, name);
            if (v is int) return (int)v;
            return 0;
        }

        /// <summary>Enable/disable the SimpleFloatingObject on the twin (v4.2.0:
        /// the physics hold kills it so the buoyancy spring can't fight the hold spring).</summary>
        public static void SetFloaterEnabled(Component twin, bool on)
        {
            if (twin == null) return;
            Resolve(null);

            Behaviour floater = null;
            if (_floater != null)
            {
                try { floater = _floater.GetValue(twin) as Behaviour; } catch { /* ok */ }
            }
            if (floater == null)
            {
                var sfo = Find("SimpleFloatingObject");
                if (sfo != null) floater = twin.GetComponent(sfo) as Behaviour;
            }
            if (floater != null && floater.enabled != on) floater.enabled = on;
        }

        public static void KeepFloaterAlive(Component twin, float raise)
        {
            if (twin == null) return;
            Resolve(null);

            Behaviour floater = null;
            if (_floater != null)
            {
                try { floater = _floater.GetValue(twin) as Behaviour; }
                catch { /* ok */ }
            }
            if (floater == null)
            {
                var sfo = Find("SimpleFloatingObject");
                if (sfo != null)
                    floater = twin.GetComponent(sfo) as Behaviour;
            }
            if (floater == null) return;

            if (!floater.enabled) floater.enabled = true;
            if (_raise != null)
            {
                try { _raise.SetValue(floater, raise); } catch { /* ok */ }
            }
        }

        // ============== v3: twin state introspection (suspension rules) ==============

        /// <summary>ItemRigidbody.onBoat; fallback — parent chain is not the floating world root.</summary>
        public static bool IsOnBoat(Component twin)
        {
            if (twin == null) return false;
            Resolve(null);

            if (_onBoat != null)
            {
                try
                {
                    object v = _onBoat.GetValue(twin);
                    if (v is bool && (bool)v) return true;
                    if (v is bool) return false; // authoritative field says no
                }
                catch { /* fall through to heuristic */ }
            }

            // heuristic: free-floating twins are parented to the floating world root;
            // anything else (boat walk col, port, hand) means something owns it
            try
            {
                var p = twin.transform.parent;
                if (p == null) return false;
                var world = FloatingOriginManager.instance != null
                    ? FloatingOriginManager.instance.transform
                    : null;
                if (world != null && p != world) return true;
            }
            catch { /* ok */ }
            return false;
        }

        /// <summary>Inside a crate / inventory slot → vanilla parks the body.</summary>
        public static bool IsContained(Component twin)
        {
            if (twin == null) return false;
            Resolve(null);
            try
            {
                if (_curBox != null && _curBox.GetValue(twin) != null) return true;
            }
            catch { /* ok */ }
            try
            {
                if (_curSlot != null && _curSlot.GetValue(twin) != null) return true;
            }
            catch { /* ok */ }
            return false;
        }

        /// <summary>Game distance-culling flag (>600 from camera) — observed, not written.</summary>
        public static bool IsOutOfRange(Component twin)
        {
            if (twin == null) return false;
            Resolve(null);
            try
            {
                if (_outOfRange != null)
                {
                    object v = _outOfRange.GetValue(twin);
                    if (v is bool) return (bool)v;
                }
            }
            catch { /* ok */ }
            return false;
        }

        /// <summary>v4.7.5 (note 56): ItemRigidbody.attached — kinematic lock
        /// from wallAttachment / HangableItem wall-snap: OnDrop near a wall
        /// snaps the twin to attachPos and freezes it. Over open water that is
        /// exactly the "hanging cm above the sea" artifact.</summary>
        public static bool IsAttached(Component twin)
        {
            if (twin == null) return false;
            Resolve(null);
            try
            {
                if (_attached != null)
                {
                    object v = _attached.GetValue(twin);
                    if (v is bool) return (bool)v;
                }
            }
            catch { /* ok */ }
            return false;
        }

        public static void SetAttached(Component twin, bool on)
        {
            if (twin == null) return;
            Resolve(null);
            try { if (_attached != null) _attached.SetValue(twin, on); } catch { /* ok */ }
        }

        /// <summary>v4.7.7 (E8 / crate-inventory note): TRUE when the item is
        /// INSIDE an opened crate — CrateInventory.InsertItem attaches it and
        /// LateUpdate locks its pose to the crate every frame; such items must
        /// be driver-suspended ('box') and never touched by the bogus-lock
        /// rescue (releasing an item into a crate happens right next to it —
        /// exactly the RecentReleases footprint, the one rescue false-positive
        /// that would tear goods out of storage). GetComponentInParent also
        /// matches SELF, so the crate itself is excluded explicitly.</summary>
        public static bool IsInCrate(ShipItem item)
        {
            if (item == null) return false;
            if (!_crateInvProbed)
            {
                _crateInvProbed = true;
                _crateInvT = Find("CrateInventory");
            }
            if (_crateInvT == null) return false;
            try
            {
                // walk the parent chain by hand (SELF excluded — the crate owns
                // its own CrateInventory but is not "inside" itself)
                var t = item.transform.parent;
                while (t != null)
                {
                    if (t.GetComponent(_crateInvT) != null) return true;
                    t = t.parent;
                }
            }
            catch { /* ok */ }
            return false;
        }

        // ============== type lookup ==============

        private static Type Find(string name)
        {
            foreach (var a in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    if (a.GetName().Name != "Assembly-CSharp") continue;
                    foreach (var t in a.GetTypes())
                        if (t.Name == name) return t;
                }
                catch { /* ok */ }
            }
            return null;
        }
    }
}
