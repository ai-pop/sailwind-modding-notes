using BepInEx.Configuration;
using UnityEngine;

namespace SailwindItemPhysics
{
    /// <summary>
    /// v5.3 — Clean physics config. Removed: FloatLiftCapG, FloatWetUpCap,
    /// DynamicsBoost, MassFeelStrength, WaveTiltFactor, FloatHullDensity (legacy).
    /// Mass works natively through ForceMode.Force. FillFactor controls buoyancy.
    /// </summary>
    internal static class Cfg
    {
        // ---- General ----
        public static bool Verbose { get; private set; }
        public static KeyCode OverlayKey { get; private set; }
        public static bool OverlayDefaultVisible { get; private set; }

        // ---- Ocean ----
        public static string OceanPreferred { get; private set; }
        public static float ManualSeaLevel { get; private set; }
        public static bool AutoRebind { get; private set; }

        // ---- Sim ----
        public static int MaxBodies { get; private set; }
        public static bool EnableVanillaPatches { get; private set; }
        public static float FarLodDistanceCap { get; private set; }
        public static float FreezeDistance { get; private set; }
        public static float WakeDistance { get; private set; }

        // ---- Float (physics) ----
        public static float FloatWaterDensity { get; private set; }
        public static bool FloatCrateContentsMass { get; private set; }
        public static float FloatDefaultFillFactor { get; private set; }
        public static bool WaveRocking { get; private set; }
        public static bool WavePosturesEnabled { get; private set; }
        public static float WaveSurfaceSmoothSeconds { get; private set; }
        public static float WaveNormalSmoothSeconds { get; private set; }

        // ---- Hold ----
        public static bool HoldEnabled { get; private set; }
        public static bool HoldSolidColliders { get; private set; }
        public static bool HoldVanillaOnBoat { get; private set; }
        public static float HoldSpringStiffness { get; private set; }
        public static float HoldSpringDamping { get; private set; }
        public static float HoldThrowSpeed { get; private set; }
        public static float HoldThrowBoost { get; private set; }
        public static float HoldThrowMaxSpeed { get; private set; }

        // ---- Correctness ----
        public static bool AutoCorrectEnabled { get; private set; }
        public static bool AutoSweepEvery20s { get; private set; }

        // ---- UI ----
        public static bool ShowMassInLookText { get; private set; }
        public static bool MassBreakdown { get; private set; }
        public static string UiLanguage { get; private set; }

        // ---- Splash ----
        public static bool SplashEnabled { get; private set; }
        public static float SplashIntensity { get; private set; }

        // ---- Config entries ----
        private static ConfigEntry<bool> _verbose, _overlayVisible, _patches, _autoRebind;
        private static ConfigEntry<bool> _autoCorrect, _autoSweep, _crateContents;
        private static ConfigEntry<bool> _holdEnabled, _holdSolidCols, _holdVanillaOnBoat;
        private static ConfigEntry<bool> _splashEnabled, _waveRocking, _wavePostures;
        private static ConfigEntry<bool> _showMass, _massBreakdown;
        private static ConfigEntry<KeyCode> _overlayKey;
        private static ConfigEntry<string> _oceanPreferred, _uiLang;
        private static ConfigEntry<float> _manualSeaLevel, _simDistanceCap, _freezeDist, _wakeDist;
        private static ConfigEntry<float> _waterDensity, _fillFactor;
        private static ConfigEntry<float> _throwSpeed, _throwBoost, _throwMax;
        private static ConfigEntry<float> _springStiff, _springDamp;
        private static ConfigEntry<float> _splashIntensity, _surfSmoothS, _normSmoothS;
        private static ConfigEntry<int> _maxBodies;

        public static void Load(ConfigFile config)
        {
            _verbose = config.Bind("General", "VerboseLogging", false, "Extra per-body state logs.");
            _overlayKey = config.Bind("General", "DebugOverlayKey", KeyCode.F10, "F10 overlay toggle.");
            _overlayVisible = config.Bind("General", "OverlayDefaultVisible", false, "Show overlay on start.");

            _oceanPreferred = config.Bind("Ocean", "PreferredSource", "Auto",
                "Auto | GameOcean | OceanHeightHelper | UnderwaterEffect | Manual.");
            _manualSeaLevel = config.Bind("Ocean", "ManualSeaLevel", -10000f,
                "Flat water Y override. -10000 = disabled.");
            _autoRebind = config.Bind("Ocean", "AutoRebindOnSceneChange", true,
                "Re-probe ocean after scene change.");

            _maxBodies = config.Bind("Sim", "MaxSimultaneousBodies", 64,
                "Hard cap. 4..512.");
            _patches = config.Bind("Sim", "EnableVanillaPatches", true,
                "Harmony patches for twin dynamics + floater ownership.");
            _simDistanceCap = config.Bind("Sim", "SimulationDistanceCap", 590f,
                "Max sim distance from player (game culls at 600).");
            _freezeDist = config.Bind("Sim", "ParkFreezeDistance", 300f,
                "Freeze bodies beyond this distance. 120..600.");
            _wakeDist = config.Bind("Sim", "ParkWakeDistance", 260f,
                "Wake bodies below this distance. <= FreezeDistance - 20.");

            // ---- v5.3 clean float physics ----

            _waterDensity = config.Bind("Float", "WaterDensityKgM3", 1000f,
                "Kg of water per cubic metre. 1000 = real seawater.");
            _fillFactor = config.Bind("Float", "DefaultFillFactor", 0.7f,
                "How much of the bounding-box is solid matter (0..1).\n" +
                "0.7 = wooden crate, 0.55 = barrel, 0.15 = empty bottle.\n" +
                "Controls displaced water volume and therefore how deep the item sits.");
            _crateContents = config.Bind("Float", "CrateContentsMass", true,
                "Count crate contents in floating mass.");

            // ---- v5.1 wave rocking / postures ----

            _waveRocking = config.Bind("Float", "WaveRocking", true,
                "Waves rock items instead of jittering them.");
            _wavePostures = config.Bind("Float", "WavePostures", true,
                "Per-item carry posture (upright vs rolling barrel vs free tumble).");
            _surfSmoothS = config.Bind("Float", "WaveSurfaceSmoothSeconds", 0.35f,
                "Surface height smoothing response time (s). 0..2.");
            _normSmoothS = config.Bind("Float", "WaveNormalSmoothSeconds", 0.9f,
                "Wave normal smoothing response time (s). 0.05..3.");

            // ---- hold ----

            _holdEnabled = config.Bind("Hold", "Enabled", true,
                "Master switch for physics hold.");
            _holdSolidCols = config.Bind("Hold", "SolidCollidersInHand", true,
                "Held item collides with world (solid body in hands).");
            _holdVanillaOnBoat = config.Bind("Hold", "VanillaOnBoat", true,
                "Vanilla grip while player is on a boat.");
            _springStiff = config.Bind("Hold", "SpringStiffness", 40f,
                "Hold spring stiffness (higher = snappier). 10..200.");
            _springDamp = config.Bind("Hold", "SpringDamping", 15f,
                "Hold spring damping (higher = less oscillation). 3..50.");
            _throwSpeed = config.Bind("Hold", "ThrowSpeed", 19f,
                "Base throw speed. 2..60.");
            _throwBoost = config.Bind("Hold", "ThrowMomentumBoost", 1.4f,
                "Multiplier on measured hand velocity. 0.5..3.");
            _throwMax = config.Bind("Hold", "ThrowMaxSpeed", 25f,
                "Speed cap for throw (m/s). 5..60.");

            // ---- correctness ----

            _autoCorrect = config.Bind("Correctness", "Enabled", true,
                "Global correctness layer switch.");
            _autoSweep = config.Bind("Correctness", "WorldSweepEvery20s", true,
                "Periodic sweep for dynamically added items.");

            // ---- UI ----

            _showMass = config.Bind("UI", "ShowMassInLookText", true,
                "Show item weight in vanilla hover text.");
            _massBreakdown = config.Bind("UI", "ShowMassBreakdown", true,
                "Show shell+contents split in weight.");
            _uiLang = config.Bind("UI", "Language", "Auto",
                "Auto | en | ru. Auto = OS locale.");

            // ---- splash ----

            _splashEnabled = config.Bind("Splash", "Enabled", true,
                "Procedural splash on water impact.");
            _splashIntensity = config.Bind("Splash", "Intensity", 1.0f,
                "Splash strength multiplier.");

            Sync();
        }

        private static void Sync()
        {
            Verbose = _verbose != null && _verbose.Value;
            OverlayKey = _overlayKey != null ? _overlayKey.Value : KeyCode.F10;
            OverlayDefaultVisible = _overlayVisible != null && _overlayVisible.Value;
            OceanPreferred = _oceanPreferred != null ? _oceanPreferred.Value : "Auto";
            ManualSeaLevel = _manualSeaLevel != null ? _manualSeaLevel.Value : -10000f;
            AutoRebind = _autoRebind == null || _autoRebind.Value;

            MaxBodies = _maxBodies != null ? Mathf.Clamp(_maxBodies.Value, 4, 512) : 64;
            EnableVanillaPatches = _patches == null || _patches.Value;
            FarLodDistanceCap = _simDistanceCap != null
                ? Mathf.Clamp(_simDistanceCap.Value, 100f, 600f) : 590f;
            FreezeDistance = _freezeDist != null
                ? Mathf.Clamp(_freezeDist.Value, 120f, 600f) : 300f;
            float wake = _wakeDist != null ? _wakeDist.Value : 260f;
            WakeDistance = Mathf.Clamp(wake, 60f, Mathf.Max(60f, FreezeDistance - 20f));

            FloatWaterDensity = _waterDensity != null
                ? Mathf.Clamp(_waterDensity.Value, 100f, 2000f) : 1000f;
            FloatDefaultFillFactor = _fillFactor != null
                ? Mathf.Clamp(_fillFactor.Value, 0.05f, 1.5f) : 0.7f;
            FloatCrateContentsMass = _crateContents == null || _crateContents.Value;

            WaveRocking = _waveRocking == null || _waveRocking.Value;
            WavePosturesEnabled = _wavePostures == null || _wavePostures.Value;
            WaveSurfaceSmoothSeconds = _surfSmoothS != null
                ? Mathf.Clamp(_surfSmoothS.Value, 0f, 2f) : 0.35f;
            WaveNormalSmoothSeconds = _normSmoothS != null
                ? Mathf.Clamp(_normSmoothS.Value, 0.05f, 3f) : 0.9f;

            HoldEnabled = _holdEnabled == null || _holdEnabled.Value;
            HoldSolidColliders = _holdSolidCols == null || _holdSolidCols.Value;
            HoldVanillaOnBoat = _holdVanillaOnBoat == null || _holdVanillaOnBoat.Value;
            HoldSpringStiffness = _springStiff != null
                ? Mathf.Clamp(_springStiff.Value, 10f, 200f) : 40f;
            HoldSpringDamping = _springDamp != null
                ? Mathf.Clamp(_springDamp.Value, 3f, 50f) : 15f;
            HoldThrowSpeed = _throwSpeed != null ? Mathf.Clamp(_throwSpeed.Value, 2f, 60f) : 19f;
            HoldThrowBoost = _throwBoost != null ? Mathf.Clamp(_throwBoost.Value, 0.5f, 3f) : 1.4f;
            HoldThrowMaxSpeed = _throwMax != null ? Mathf.Clamp(_throwMax.Value, 5f, 60f) : 25f;

            AutoCorrectEnabled = _autoCorrect == null || _autoCorrect.Value;
            AutoSweepEvery20s = _autoSweep == null || _autoSweep.Value;

            ShowMassInLookText = _showMass == null || _showMass.Value;
            MassBreakdown = _massBreakdown == null || _massBreakdown.Value;
            UiLanguage = ResolveUiLanguage(_uiLang != null ? _uiLang.Value : "Auto");

            SplashEnabled = _splashEnabled == null || _splashEnabled.Value;
            SplashIntensity = _splashIntensity != null
                ? Mathf.Clamp(_splashIntensity.Value, 0.1f, 5f) : 1f;
        }

        private static string ResolveUiLanguage(string raw)
        {
            if (raw != null)
            {
                var r = raw.Trim().ToLowerInvariant();
                if (r == "ru" || r == "en") return r;
            }
            try
            {
                var c = System.Globalization.CultureInfo.CurrentCulture;
                if (c != null && c.TwoLetterISOLanguageName == "ru") return "ru";
            }
            catch { }
            return "en";
        }
    }
}
