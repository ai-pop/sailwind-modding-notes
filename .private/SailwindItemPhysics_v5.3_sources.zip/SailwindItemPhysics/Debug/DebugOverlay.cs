using System.Collections.Generic;
using SailwindItemPhysics.Api;
using SailwindItemPhysics.Ocean;
using SailwindItemPhysics.Sim;
using UnityEngine;

namespace SailwindItemPhysics.Debugging
{
    /// <summary>
    /// F9 diagnostics overlay: ocean provider chain, live bodies, one-click actions.
    /// Pure IMGUI, styles allocated fresh per draw (note 47: never mutate shared styles).
    /// </summary>
    internal sealed class DebugOverlay : MonoBehaviour
    {
        private SurfaceBodyService _svc;
        private bool _visible;
        private Rect _win = new Rect(20f, 60f, 560f, 470f);
        private Vector2 _scroll;
        private float _nextInfoRefresh;
        private List<SurfaceBodyInfo> _rows = new List<SurfaceBodyInfo>();
        private List<string> _providers = new List<string>();
        private string _status = "";

        public void Bind(SurfaceBodyService svc, bool startVisible)
        {
            _svc = svc;
            _visible = startVisible;
        }

        public bool Visible
        {
            get { return _visible; }
            set { _visible = value; }
        }

        private void Update()
        {
            if (Input.GetKeyDown(Cfg.OverlayKey))
            {
                _visible = !_visible;
                if (_visible) RefreshData(true);
            }
        }

        private void RefreshData(bool force)
        {
            if (!force && Time.unscaledTime < _nextInfoRefresh) return;
            _nextInfoRefresh = Time.unscaledTime + 0.5f;

            try { _providers = OceanSurface.ProviderReport(); }
            catch { _providers = new List<string> { "(provider report failed)" }; }

            try
            {
                _rows = _svc != null
                    ? _svc.BuildInfoRows(14)
                    : new List<SurfaceBodyInfo>();
            }
            catch { _rows = new List<SurfaceBodyInfo>(); }
        }

        private void OnGUI()
        {
            if (!_visible) return;
            RefreshData(false);

            var winStyle = new GUIStyle(GUI.skin.window);
            _win = GUI.Window(0x1A7B, _win, DrawWindow, "SailwindItemPhysics v" +
                Plugin.PluginVersion + "  [" + Cfg.OverlayKey + "]", winStyle);
        }

        private void DrawWindow(int id)
        {
            var label = new GUIStyle(GUI.skin.label) { richText = true, fontSize = 12, wordWrap = false };
            var head = new GUIStyle(GUI.skin.label) { richText = true, fontSize = 12, fontStyle = FontStyle.Bold };
            var btn = new GUIStyle(GUI.skin.button) { fontSize = 12 };

            GUILayout.BeginVertical();

            // ---- ocean ----
            GUILayout.Label("<b>Ocean</b>", head);
            string sea = float.IsNaN(OceanSurface.SeaLevelNow)
                ? "NaN"
                : OceanSurface.SeaLevelNow.ToString("0.00");
            GUILayout.Label(
                (OceanSurface.IsLive ? "<color=#7fe07f>LIVE</color> " : "<color=#e0c04f>ESTIMATE</color> ") +
                "source=" + OceanSurface.SourceName + "   sea≈" + sea, label);
            _scroll = GUILayout.BeginScrollView(_scroll, GUILayout.Height(70f));
            foreach (var p in _providers) GUILayout.Label(p, label);
            GUILayout.EndScrollView();

            GUILayout.Space(4f);

            // ---- bodies ----
            int active = _svc != null ? _svc.ActiveCount : 0;
            GUILayout.Label("<b>Bodies</b>  attached=" + active +
                            " / cap " + Cfg.MaxBodies, head);
            GUILayout.Label("name                state      kg    wet   subm   dist", label);
            foreach (var r in _rows)
            {
                string nm = r.Item != null ? r.Item.name : "?";
                if (nm.Length > 18) nm = nm.Substring(0, 18);
                string st = r.State == SurfaceBodyState.Suspended && r.Reason.Length > 0
                    ? r.Reason
                    : r.State.ToString();
                if (st.Length > 9) st = st.Substring(0, 9);
                GUILayout.Label(string.Format(
                        "{0,-19} {1,-9} {2,5:0} {3,5:0.00} {4,6:0.00} {5,6:0}m",
                        nm, st, r.Mass, r.Wetness, r.Submersion, r.DistanceToPlayer),
                    label);
            }
            if (_rows.Count == 0)
                GUILayout.Label("<i>(no attached bodies — spawn loot or attach via API)</i>", label);

            GUILayout.Space(4f);

            // ---- correctness layer (v4) ----
            GUILayout.Label("<b>Correctness</b>", head);
            string heldLine = "hold: —";
            try
            {
                var held = _svc != null ? _svc.CurrentHeldItem : null;
                string tkey = SailwindItemPhysics.Correct.DropKeyResolver.ThrowKey.ToString();
                if (held != null)
                {
                    heldLine = "hold: " + held.name + "  (" + tkey + " release = momentum throw, wheel = rotate)";
                }
                else
                {
                    var imit = SailwindItemPhysics.Correct.GoPointerPatches.LastHeldItem;
                    if (imit != null && !SailwindItemPhysics.Cfg.HoldPhysicsInHands)
                        heldLine = "hold: " + imit.name +
                                   "  (imitation, " + tkey + " release = momentum throw, wheel = rotate)";
                    else if (SailwindItemPhysics.Correct.BoatGate.PlayerOnBoat)
                        heldLine = "hold: vanilla/imitation (on boat)";
                }
            }
            catch { /* ok */ }
            GUILayout.Label("tracked=" + (_svc != null ? _svc.TrackedItemCount : 0) +
                            "   " + heldLine, label);

            GUILayout.Space(4f);

            // ---- actions ----
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Rebind ocean", btn))
            {
                OceanSurface.ForceRebind();
                _status = "rebind requested";
            }
            if (GUILayout.Button("Dump diagnostics", btn))
            {
                OceanSurface.DumpDiagnostics(true);
                _status = "dumped to LogOutput.log";
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Pulse nearest ↑", btn))
            {
                float d = 0f;
                ShipItem item = null;
                if (_svc != null) item = _svc.FindNearestAttached(out d);
                if (item != null)
                {
                    _svc.Pulse(item, Vector3.up * 3.5f);
                    _status = "pulsed '" + item.name + "' @ " + d.ToString("0") + "m";
                }
                else _status = "no bodies to pulse";
            }
            if (GUILayout.Button("Throw held", btn))
            {
                float spd = _svc != null ? _svc.ThrowHeld(Cfg.HoldThrowSpeed) : 0f;
                _status = spd > 0.1f ? "thrown @ " + spd.ToString("0.0") + " m/s" : "nothing held";
            }
            if (GUILayout.Button("Dump item catalog → csv", btn))
            {
                SailwindItemPhysics.DebugTools.ItemCatalogDumper.Dump("overlay");
                _status = "catalog dumped (see log/path)";
            }
            if (GUILayout.Button("Test splash", btn))
            {
                Vector3 at = AimPoint(6f);
                if (_svc != null) _svc.SpawnSplash(at, 4f);
                _status = "splash @ " + at.x.ToString("0") + "," + at.z.ToString("0");
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Verbose: " + (Cfg.Verbose ? "ON" : "off"), btn))
            {
                _status = "edit VerboseLogging in com.sailwind.itemphysics.cfg";
            }
            GUILayout.EndHorizontal();

            if (_status.Length > 0) GUILayout.Label("<i>" + _status + "</i>", label);

            GUILayout.Label("<i>est bodies ride fallback surface — set [Ocean] ManualSeaLevel to force flat water</i>", label);
            GUILayout.EndVertical();

            GUI.DragWindow();
        }

        private static Vector3 AimPoint(float dist)
        {
            try
            {
                var cam = Camera.main;
                if (cam != null)
                    return cam.transform.position + cam.transform.forward * dist;
            }
            catch { /* ok */ }
            return Vector3.zero;
        }
    }
}
